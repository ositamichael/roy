OSITA MICHAEL PORTFOLIO WEBSITE

Files included:
- index.html
- style.css
- script.js

How to use:
1. Add your own photo into this folder.
2. Rename your photo to: me.jpg
3. Create a GitHub repository named: ositamichael001.github.io
4. Upload all files from this folder to the repository.
5. Your site will be live at: https://ositamichael001.github.io

Edit links:
Open index.html and replace the LinkedIn link with your real LinkedIn profile link.

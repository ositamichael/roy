document.addEventListener('DOMContentLoaded', () => {
  const year = document.getElementById('year');
  if (year) year.textContent = new Date().getFullYear();

  document.querySelectorAll('form').forEach(form => {
    form.addEventListener('submit', e => {
      e.preventDefault();
      const msg = form.querySelector('.form-message');
      if (msg) msg.textContent = 'Demo form submitted successfully. Connect this to WordPress email or SMTP on launch.';
    });
  });

  let popupShown = false;
  document.addEventListener('mouseout', (e) => {
    if (!popupShown && e.clientY <= 0 && window.innerWidth > 768) {
      const popup = document.querySelector('.exit-popup');
      if (popup) popup.classList.add('show');
      popupShown = true;
    }
  });
  document.querySelectorAll('[data-close-popup]').forEach(btn => {
    btn.addEventListener('click', () => document.querySelector('.exit-popup')?.classList.remove('show'));
  });
});

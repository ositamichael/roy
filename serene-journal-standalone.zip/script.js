const STORAGE_KEY = 'serene-journal-standalone-v1';
const moods = [
  { key: 'joyful', label: 'Joyful', emoji: '😊', score: 5 },
  { key: 'calm', label: 'Calm', emoji: '😌', score: 4 },
  { key: 'neutral', label: 'Neutral', emoji: '😐', score: 3 },
  { key: 'tired', label: 'Tired', emoji: '😴', score: 2 },
  { key: 'sad', label: 'Sad', emoji: '😔', score: 1 },
  { key: 'anxious', label: 'Anxious', emoji: '😟', score: 1 },
  { key: 'angry', label: 'Angry', emoji: '😠', score: 1 },
];
const prompts = [
  'What helped you feel safe or supported today?',
  'What emotion showed up most strongly today, and why?',
  'What is one small win you want to remember from today?',
  'What drained your energy today, and how did you respond?',
  'What would self-compassion sound like for you right now?',
  'What pattern have you noticed in your mood this week?',
  'What do you need more of tomorrow: rest, connection, focus, or space?',
];

function uid() {
  if (window.crypto && crypto.randomUUID) return crypto.randomUUID();
  return 'id-' + Date.now() + '-' + Math.random().toString(16).slice(2);
}

function seedEntries() {
  const now = Date.now();
  return [
    {
      id: uid(),
      title: 'A quieter morning',
      content: 'I started the day slowly, had tea, and kept my phone away for the first hour. I felt more grounded than usual and less reactive.',
      moodKey: 'calm',
      moodIntensity: 4,
      energyLevel: 3,
      stressLevel: 2,
      tags: ['morning', 'routine'],
      createdAt: new Date(now - 5 * 86400000).toISOString(),
      updatedAt: new Date(now - 5 * 86400000).toISOString(),
    },
    {
      id: uid(),
      title: 'Overloaded but honest',
      content: 'Today felt heavy. Work stacked up and I noticed myself getting tense. I still managed to take a short walk and name what I was feeling instead of pushing it away.',
      moodKey: 'anxious',
      moodIntensity: 4,
      energyLevel: 2,
      stressLevel: 5,
      tags: ['work', 'stress'],
      createdAt: new Date(now - 2 * 86400000).toISOString(),
      updatedAt: new Date(now - 2 * 86400000).toISOString(),
    },
    {
      id: uid(),
      title: 'Small progress matters',
      content: 'I did not finish everything I wanted, but I showed up. I completed a difficult task and took better breaks. That counts.',
      moodKey: 'joyful',
      moodIntensity: 4,
      energyLevel: 4,
      stressLevel: 2,
      tags: ['progress', 'confidence'],
      createdAt: new Date(now).toISOString(),
      updatedAt: new Date(now).toISOString(),
    },
  ];
}

const defaultState = {
  theme: 'light',
  user: null,
  reminderEnabled: true,
  reminderTime: '20:00',
  currentPage: 'dashboard',
  search: '',
  filterMood: '',
  entries: seedEntries(),
};

const state = loadState();
let draftEntry = null;
let authMode = 'register';

function loadState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return { ...defaultState };
    const parsed = JSON.parse(raw);
    return {
      ...defaultState,
      ...parsed,
      entries: Array.isArray(parsed.entries) ? parsed.entries : defaultState.entries,
    };
  } catch {
    return { ...defaultState };
  }
}

function saveState() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

function escapeHtml(text) {
  return String(text)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

function formatDate(iso) {
  return new Intl.DateTimeFormat('en-GB', { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(iso));
}
function moodByKey(key) { return moods.find(m => m.key === key) || moods[2]; }
function scoreFromMood(key) { return moodByKey(key).score; }
function getPrompt() { return prompts[new Date().getDate() % prompts.length]; }
function sortedEntries() { return [...state.entries].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)); }
function setTheme() { document.body.classList.toggle('dark', state.theme === 'dark'); }

function render() {
  setTheme();
  const app = document.getElementById('app');
  if (!state.user) {
    app.innerHTML = renderAuth();
    bindAuth();
    return;
  }
  app.innerHTML = renderApp();
  bindApp();
  drawCharts();
}

function renderAuth() {
  return `
    <div class="auth-wrap">
      <div class="auth-grid">
        <section class="card brand-panel">
          <div class="logo">
            <div class="logo-badge">💙</div>
            <div>
              <div class="muted" style="font-weight:800; letter-spacing:.14em; text-transform:uppercase;">Serene</div>
              <div style="font-size:24px; font-weight:800;">Journal</div>
            </div>
          </div>
          <div class="eyebrow">🛡️ Privacy-first journaling experience</div>
          <h1 class="hero-title">A calm, premium space to reflect, track mood, and build healthier emotional awareness.</h1>
          <p class="hero-text">This standalone version includes journaling, mood tracking, analytics, reminders, search, filters, dark mode, export, and persistent browser storage.</p>
          <div class="feature-grid">
            <div class="mini-card"><h4>Guided entries</h4><p>Daily prompts and thoughtful structure for reflection.</p></div>
            <div class="mini-card"><h4>Mood analytics</h4><p>See emotional patterns across time and recent activity.</p></div>
            <div class="mini-card"><h4>Beautiful UX</h4><p>Responsive layout with polished visuals and usability.</p></div>
          </div>
        </section>
        <section class="card auth-panel">
          <div class="tab-switch">
            <button data-auth-tab="register" class="${authMode === 'register' ? 'active' : ''}">Create account</button>
            <button data-auth-tab="login" class="${authMode === 'login' ? 'active' : ''}">Sign in</button>
          </div>
          <form id="auth-form">
            <div id="auth-error"></div>
            ${authMode === 'register' ? `
            <div class="field">
              <label>Full name</label>
              <input class="input" name="name" placeholder="Enter your full name" />
            </div>` : ''}
            <div class="field">
              <label>Email</label>
              <input class="input" name="email" type="email" placeholder="you@example.com" />
            </div>
            <div class="field">
              <label>Password</label>
              <input class="input" name="password" type="password" placeholder="At least 8 characters" />
            </div>
            <button class="btn btn-dark" style="width:100%;">${authMode === 'register' ? 'Create secure workspace' : 'Sign in'}</button>
            <p class="soft-text" style="text-align:center; margin-top:14px; font-size:14px;">Demo authentication is stored locally so you can preview the app immediately.</p>
          </form>
        </section>
      </div>
    </div>`;
}

function renderApp() {
  const entries = sortedEntries();
  const currentPage = state.currentPage;
  return `
  <div class="app-shell">
    <div class="main-layout">
      <aside class="sidebar">
        <div class="logo">
          <div class="logo-badge">💙</div>
          <div>
            <div class="muted" style="font-weight:800; letter-spacing:.14em; text-transform:uppercase;">Serene</div>
            <div style="font-size:24px; font-weight:800;">Journal</div>
          </div>
        </div>
        <nav>
          ${navButton('dashboard', 'Dashboard')}
          ${navButton('entries', 'Entries')}
          ${navButton('analytics', 'Analytics')}
          ${navButton('settings', 'Settings')}
        </nav>
        <div class="sidebar-promo" style="display:grid; gap:12px;">
          <div style="font-size:14px; opacity:.92;">Premium-ready foundation</div>
          <div style="font-weight:800; font-size:22px;">A polished standalone build</div>
          <div style="font-size:14px; line-height:1.6; opacity:.88;">Includes journaling, analytics, search, reminders, export, dark mode, and persistent local storage.</div>
          <button id="logout-btn" class="btn" style="background:rgba(255,255,255,.14); color:white;">Sign out demo</button>
        </div>
      </aside>
      <div class="main-column">
        <header class="topbar">
          <div>
            <div class="muted">Welcome back</div>
            <div style="font-size:30px; font-weight:800; text-transform:capitalize;">${escapeHtml(currentPage)}</div>
          </div>
          <div class="topbar-actions">
            <button id="theme-toggle" class="btn btn-outline">${state.theme === 'dark' ? '☀️ Light' : '🌙 Dark'}</button>
            <button id="new-entry-btn" class="btn btn-dark">＋ New entry</button>
            <div class="user-chip">
              <div style="font-weight:700;">${escapeHtml(state.user.name || 'Serene User')}</div>
              <div class="muted">${escapeHtml(state.user.email || 'local@serene.app')}</div>
            </div>
          </div>
        </header>
        <main class="main-content">${renderPage(entries)}</main>
        <div class="mobile-nav">
          ${mobileNavButton('dashboard', 'Home')}
          ${mobileNavButton('entries', 'Entries')}
          ${mobileNavButton('analytics', 'Stats')}
          ${mobileNavButton('settings', 'Settings')}
        </div>
      </div>
    </div>
    ${renderModal()}
  </div>`;
}

function navButton(key, label) {
  return `<button class="nav-btn ${state.currentPage === key ? 'active' : ''}" data-page="${key}">${label}</button>`;
}
function mobileNavButton(key, label) {
  return `<button class="${state.currentPage === key ? 'active' : ''}" data-page="${key}">${label}</button>`;
}

function renderPage(entries) {
  if (state.currentPage === 'dashboard') return renderDashboard(entries);
  if (state.currentPage === 'entries') return renderEntries(entries);
  if (state.currentPage === 'analytics') return renderAnalytics(entries);
  return renderSettings(entries);
}

function renderDashboard(entries) {
  const last7 = entries.filter(e => new Date(e.createdAt).getTime() > Date.now() - 7 * 86400000);
  const avgMood = entries.length ? (entries.reduce((sum, e) => sum + scoreFromMood(e.moodKey), 0) / entries.length).toFixed(1) : '0';
  const latest = entries[0] ? moodByKey(entries[0].moodKey).label : 'No entries yet';
  return `
    <section class="dashboard-grid">
      <div class="hero-card">
        <div class="gradient-panel">
          <div class="eyebrow" style="margin:0; background:rgba(255,255,255,.1); color:white;">✨ Daily reflection</div>
          <h2 style="font-size:36px; line-height:1.1; margin:18px 0 10px;">${escapeHtml(getPrompt())}</h2>
          <p style="opacity:.82; line-height:1.7; max-width:720px;">Thoughtful journaling becomes more useful when it is consistent, honest, and easy to return to. Capture what today felt like.</p>
          <div style="display:flex; gap:12px; flex-wrap:wrap; margin-top:22px;">
            <button id="cta-write" class="btn" style="background:white; color:#0f172a;">Write today’s entry</button>
            <button data-page-link="analytics" class="btn" style="background:rgba(255,255,255,.14); color:white;">View insights</button>
          </div>
        </div>
        <div class="panel">
          <div class="muted">🔔 Wellness note</div>
          <h2 style="margin:14px 0 8px; font-size:30px;">You’re building reflection habits.</h2>
          <p class="soft-text">This app is for self-reflection and emotional awareness. It is not a medical device or a substitute for professional mental health support.</p>
          <div class="insight-box" style="margin-top:20px;">
            <div class="muted">Latest mood</div>
            <div style="font-size:22px; font-weight:800; margin-top:8px;">${escapeHtml(latest)}</div>
          </div>
        </div>
      </div>
      <div class="stat-grid">
        ${statCard('Total entries', String(entries.length), 'Across your journal')}
        ${statCard('Last 7 days', String(last7.length), 'Recent reflections')}
        ${statCard('Average mood', avgMood, 'Higher is lighter')}
        ${statCard('Consistency', entries.length ? `${Math.min(100, entries.length * 8)}%` : '0%', 'Reflection habit score')}
      </div>
      <div class="panel-grid">
        <div class="panel">
          <h3>Mood and wellbeing trend</h3>
          <div class="muted">Recent emotional signal across your last entries</div>
          <svg id="trend-chart" class="chart" viewBox="0 0 700 280" preserveAspectRatio="none"></svg>
        </div>
        <div class="panel">
          <div style="display:flex; justify-content:space-between; gap:14px; align-items:center;">
            <div><h3>Recent entries</h3><div class="muted">Your latest reflections</div></div>
            <button data-page-link="entries" class="btn btn-outline">View all</button>
          </div>
          <div class="recent-list" style="margin-top:16px;">
            ${entries.slice(0, 4).map(renderRecentCard).join('') || '<div class="empty-state"><strong>No entries yet</strong><div class="muted" style="margin-top:8px;">Create your first reflection to populate the dashboard.</div></div>'}
          </div>
        </div>
      </div>
    </section>`;
}

function statCard(title, value, subtitle) {
  return `<div class="panel stat-card"><div class="muted">${escapeHtml(title)}</div><div style="font-size:38px; font-weight:800; margin:10px 0 8px;">${escapeHtml(value)}</div><div class="muted">${escapeHtml(subtitle)}</div></div>`;
}

function renderRecentCard(entry) {
  const mood = moodByKey(entry.moodKey);
  return `<div class="mini-card"><div class="entry-head"><div><div style="font-weight:700;">${escapeHtml(entry.title || 'Untitled reflection')}</div><div class="entry-meta">${escapeHtml(formatDate(entry.createdAt))}</div></div><div style="font-size:28px;">${mood.emoji}</div></div><div class="soft-text" style="margin-top:10px;">${escapeHtml(entry.content.slice(0, 110))}${entry.content.length > 110 ? '…' : ''}</div></div>`;
}

function renderEntries(entries) {
  const filtered = entries.filter(entry => {
    const q = state.search.trim().toLowerCase();
    const matchesSearch = !q ||
      (entry.title || '').toLowerCase().includes(q) ||
      entry.content.toLowerCase().includes(q) ||
      (entry.tags || []).some(tag => tag.toLowerCase().includes(q));
    const matchesMood = !state.filterMood || entry.moodKey === state.filterMood;
    return matchesSearch && matchesMood;
  });
  return `
    <section class="dashboard-grid">
      <div class="panel">
        <div class="controls-grid">
          <div class="search-wrap"><span>🔎</span><input id="search-input" class="input" placeholder="Search entries, content, or tags" value="${escapeHtml(state.search)}"></div>
          <div class="select-wrap"><span>🗂️</span><select id="mood-filter" class="select"><option value="">All moods</option>${moods.map(m => `<option value="${m.key}" ${state.filterMood === m.key ? 'selected' : ''}>${m.label}</option>`).join('')}</select></div>
        </div>
      </div>
      <div class="entry-list">
        ${filtered.length ? filtered.map(renderEntryCard).join('') : `<div class="empty-state"><strong>No matching entries</strong><div class="muted" style="margin-top:8px;">Try a different search term or mood filter.</div></div>`}
      </div>
    </section>`;
}

function renderEntryCard(entry) {
  const mood = moodByKey(entry.moodKey);
  return `<article class="entry-card">
    <div class="entry-head">
      <div style="display:flex; gap:14px; align-items:flex-start;">
        <div style="font-size:34px;">${mood.emoji}</div>
        <div>
          <h3 style="margin:0 0 6px;">${escapeHtml(entry.title || 'Untitled reflection')}</h3>
          <div class="entry-meta">${escapeHtml(formatDate(entry.createdAt))} • ${escapeHtml(mood.label)} • Intensity ${entry.moodIntensity}/5</div>
        </div>
      </div>
      <div style="display:flex; gap:8px; flex-wrap:wrap;">
        <button class="btn btn-outline" data-edit-id="${entry.id}">Edit</button>
        <button class="btn btn-danger" data-delete-id="${entry.id}">Delete</button>
      </div>
    </div>
    <p class="entry-content">${escapeHtml(entry.content)}</p>
    ${(entry.tags && entry.tags.length) ? `<div class="tag-list">${entry.tags.map(tag => `<span class="tag">#${escapeHtml(tag)}</span>`).join('')}</div>` : ''}
  </article>`;
}

function renderAnalytics(entries) {
  const insight = getInsight(entries);
  const mostCommon = getMostCommonMood(entries);
  const avgChars = entries.length ? Math.round(entries.reduce((sum, e) => sum + e.content.length, 0) / entries.length) : 0;
  return `
    <section class="dashboard-grid">
      <div class="panel-grid">
        <div class="panel">
          <h3>Mood frequency</h3>
          <div class="muted">Which emotions appear most often in your journal</div>
          <svg id="bar-chart" class="chart" viewBox="0 0 700 280" preserveAspectRatio="none"></svg>
        </div>
        <div class="panel">
          <h3>Insights summary</h3>
          <p class="soft-text">${escapeHtml(insight)}</p>
          <div class="insight-box" style="margin-top:18px;">
            <div class="muted">Most common mood</div>
            <div style="font-size:22px; font-weight:800; margin-top:8px;">${escapeHtml(mostCommon)}</div>
          </div>
          <div class="insight-box" style="margin-top:14px;">
            <div class="muted">Journal depth</div>
            <div style="font-size:22px; font-weight:800; margin-top:8px;">${avgChars} avg characters</div>
          </div>
        </div>
      </div>
      <div class="panel">
        <h3>Six-month overview</h3>
        <div class="muted">Entries and average mood by month</div>
        <svg id="overview-chart" class="chart" viewBox="0 0 700 280" preserveAspectRatio="none"></svg>
      </div>
    </section>`;
}

function renderSettings(entries) {
  return `
    <section class="settings-grid">
      <div class="panel">
        <h3>Preferences</h3>
        <div class="mini-card" style="display:flex; justify-content:space-between; gap:16px; align-items:center; margin-top:18px;">
          <div><div style="font-weight:700;">Daily reminder</div><div class="muted">Encourage consistent reflection</div></div>
          <button id="reminder-toggle" class="toggle ${state.reminderEnabled ? 'active' : ''}" aria-label="Toggle reminders"></button>
        </div>
        <div class="field" style="margin-top:18px;">
          <label>Reminder time</label>
          <input id="reminder-time" class="input" type="time" value="${escapeHtml(state.reminderTime)}">
        </div>
      </div>
      <div class="panel">
        <h3>Data</h3>
        <div style="display:grid; gap:14px; margin-top:18px;">
          <button id="export-btn" class="btn btn-dark">⬇️ Export entries JSON</button>
          <button id="reset-btn" class="btn btn-outline">Reset demo data</button>
          <div class="insight-box">This standalone version stores your data locally in the browser so you can test everything end-to-end. A production version would use secure authentication and cloud storage.</div>
          <div class="mini-card"><div class="muted">Entries stored</div><div style="font-size:28px; font-weight:800; margin-top:8px;">${entries.length}</div></div>
        </div>
      </div>
    </section>`;
}

function renderModal() {
  const entry = draftEntry || {
    title: '', content: '', moodKey: 'calm', moodIntensity: 3, energyLevel: 3, stressLevel: 3, tags: []
  };
  return `
    <div id="modal-backdrop" class="modal-backdrop ${draftEntry ? 'open' : ''}"></div>
    <div id="entry-modal" class="modal ${draftEntry ? 'open' : ''}">
      <div class="modal-inner">
        <div class="modal-header">
          <div>
            <h2 style="margin:0; font-size:30px;">${entry.id ? 'Edit entry' : 'New journal entry'}</h2>
            <div class="muted" style="margin-top:8px;">Capture how you feel with clarity, structure, and reflection.</div>
          </div>
          <button id="close-modal" class="btn btn-outline">✕</button>
        </div>
        <form id="entry-form" style="margin-top:22px;">
          <div id="entry-error"></div>
          <div class="field"><label>Title</label><input class="input" name="title" value="${escapeHtml(entry.title || '')}" placeholder="Optional title"></div>
          <div class="field"><label>Journal entry <span class="muted">• Prompt: ${escapeHtml(getPrompt())}</span></label><textarea class="textarea" name="content" placeholder="How are you feeling today? What happened, and how did it affect you?">${escapeHtml(entry.content || '')}</textarea></div>
          <div class="field"><label>Mood</label><div class="mood-grid">${moods.map(m => `<button type="button" class="mood-option ${entry.moodKey === m.key ? 'active' : ''}" data-mood="${m.key}"><div style="font-size:28px;">${m.emoji}</div><div style="margin-top:10px; font-weight:700;">${m.label}</div></button>`).join('')}</div></div>
          <input type="hidden" name="moodKey" value="${escapeHtml(entry.moodKey)}">
          <div class="range-grid">
            ${rangeField('Mood intensity', 'moodIntensity', entry.moodIntensity)}
            ${rangeField('Energy level', 'energyLevel', entry.energyLevel)}
            ${rangeField('Stress level', 'stressLevel', entry.stressLevel)}
          </div>
          <div class="field" style="margin-top:18px;"><label>Tags</label><input class="input" name="tags" value="${escapeHtml((entry.tags || []).join(', '))}" placeholder="work, self-care, family"></div>
          <div style="display:flex; justify-content:flex-end; gap:10px; flex-wrap:wrap; margin-top:20px;">
            <button type="button" id="cancel-modal" class="btn btn-outline">Cancel</button>
            <button type="submit" class="btn btn-dark">${entry.id ? 'Save changes' : 'Save entry'}</button>
          </div>
        </form>
      </div>
    </div>`;
}

function rangeField(label, name, value) {
  return `<div class="range-card"><label style="display:block; margin-bottom:10px; font-weight:700;">${label}</label><input type="range" min="1" max="5" step="1" name="${name}" value="${value}"><div class="muted"><span data-range-label="${name}">${value}</span> / 5</div></div>`;
}

function bindAuth() {
  document.querySelectorAll('[data-auth-tab]').forEach(btn => btn.addEventListener('click', () => {
    authMode = btn.dataset.authTab;
    render();
  }));
  document.getElementById('auth-form').addEventListener('submit', (e) => {
    e.preventDefault();
    const form = new FormData(e.target);
    const name = (form.get('name') || '').toString().trim();
    const email = (form.get('email') || '').toString().trim();
    const password = (form.get('password') || '').toString();
    const err = [];
    if (authMode === 'register' && !name) err.push('Please enter your full name.');
    if (!email || !email.includes('@')) err.push('Please enter a valid email address.');
    if (password.length < 8) err.push('Password must be at least 8 characters.');
    if (err.length) {
      document.getElementById('auth-error').innerHTML = `<div class="error">${escapeHtml(err[0])}</div>`;
      return;
    }
    state.user = { name: name || 'Serene User', email };
    saveState();
    render();
  });
}

function bindApp() {
  document.querySelectorAll('[data-page]').forEach(btn => btn.addEventListener('click', () => {
    state.currentPage = btn.dataset.page;
    saveState();
    render();
  }));
  document.querySelectorAll('[data-page-link]').forEach(btn => btn.addEventListener('click', () => {
    state.currentPage = btn.dataset.pageLink;
    saveState();
    render();
  }));
  document.getElementById('theme-toggle').addEventListener('click', () => {
    state.theme = state.theme === 'dark' ? 'light' : 'dark';
    saveState();
    render();
  });
  document.getElementById('logout-btn').addEventListener('click', () => {
    state.user = null;
    saveState();
    render();
  });
  document.getElementById('new-entry-btn').addEventListener('click', openNewEntry);
  const cta = document.getElementById('cta-write'); if (cta) cta.addEventListener('click', openNewEntry);
  const search = document.getElementById('search-input');
  if (search) search.addEventListener('input', e => { state.search = e.target.value; saveState(); render(); });
  const filter = document.getElementById('mood-filter');
  if (filter) filter.addEventListener('change', e => { state.filterMood = e.target.value; saveState(); render(); });
  document.querySelectorAll('[data-edit-id]').forEach(btn => btn.addEventListener('click', () => editEntry(btn.dataset.editId)));
  document.querySelectorAll('[data-delete-id]').forEach(btn => btn.addEventListener('click', () => deleteEntry(btn.dataset.deleteId)));
  const reminderToggle = document.getElementById('reminder-toggle');
  if (reminderToggle) reminderToggle.addEventListener('click', () => { state.reminderEnabled = !state.reminderEnabled; saveState(); render(); });
  const reminderTime = document.getElementById('reminder-time');
  if (reminderTime) reminderTime.addEventListener('change', e => { state.reminderTime = e.target.value; saveState(); });
  const exportBtn = document.getElementById('export-btn');
  if (exportBtn) exportBtn.addEventListener('click', exportEntries);
  const resetBtn = document.getElementById('reset-btn');
  if (resetBtn) resetBtn.addEventListener('click', () => {
    if (!confirm('Reset the demo data and restore the original sample entries?')) return;
    state.entries = seedEntries();
    state.search = '';
    state.filterMood = '';
    saveState();
    render();
  });
  bindModal();
}

function openNewEntry() {
  draftEntry = { title: '', content: '', moodKey: 'calm', moodIntensity: 3, energyLevel: 3, stressLevel: 3, tags: [] };
  render();
}
function closeModal() { draftEntry = null; render(); }
function editEntry(id) {
  const found = state.entries.find(e => e.id === id);
  if (!found) return;
  draftEntry = JSON.parse(JSON.stringify(found));
  render();
}
function deleteEntry(id) {
  const found = state.entries.find(e => e.id === id);
  if (!found) return;
  const label = found.title || 'this entry';
  if (!confirm(`Delete ${label}?`)) return;
  state.entries = state.entries.filter(e => e.id !== id);
  saveState();
  render();
}

function bindModal() {
  const modal = document.getElementById('entry-modal');
  if (!modal) return;
  const backdrop = document.getElementById('modal-backdrop');
  const close = document.getElementById('close-modal');
  const cancel = document.getElementById('cancel-modal');
  [backdrop, close, cancel].forEach(el => el && el.addEventListener('click', closeModal));
  document.querySelectorAll('[data-mood]').forEach(btn => btn.addEventListener('click', () => {
    document.querySelector('input[name="moodKey"]').value = btn.dataset.mood;
    document.querySelectorAll('[data-mood]').forEach(b => b.classList.toggle('active', b === btn));
  }));
  document.querySelectorAll('input[type="range"]').forEach(range => range.addEventListener('input', () => {
    const label = document.querySelector(`[data-range-label="${range.name}"]`);
    if (label) label.textContent = range.value;
  }));
  const form = document.getElementById('entry-form');
  if (form) form.addEventListener('submit', (e) => {
    e.preventDefault();
    const fd = new FormData(form);
    const payload = {
      id: draftEntry && draftEntry.id ? draftEntry.id : uid(),
      title: (fd.get('title') || '').toString().trim(),
      content: (fd.get('content') || '').toString().trim(),
      moodKey: (fd.get('moodKey') || 'calm').toString(),
      moodIntensity: Number(fd.get('moodIntensity') || 3),
      energyLevel: Number(fd.get('energyLevel') || 3),
      stressLevel: Number(fd.get('stressLevel') || 3),
      tags: (fd.get('tags') || '').toString().split(',').map(t => t.trim()).filter(Boolean).slice(0, 8),
      createdAt: draftEntry && draftEntry.createdAt ? draftEntry.createdAt : new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    if (payload.content.length < 10) {
      document.getElementById('entry-error').innerHTML = '<div class="error">Please write at least 10 characters for a meaningful journal entry.</div>';
      return;
    }
    const index = state.entries.findIndex(e => e.id === payload.id);
    if (index >= 0) state.entries[index] = payload; else state.entries.unshift(payload);
    saveState();
    closeModal();
  });
}

function exportEntries() {
  const blob = new Blob([JSON.stringify(sortedEntries(), null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'serene-journal-entries.json';
  a.click();
  URL.revokeObjectURL(url);
}

function getMostCommonMood(entries) {
  if (!entries.length) return 'No data';
  const counts = Object.fromEntries(moods.map(m => [m.key, 0]));
  entries.forEach(e => counts[e.moodKey] = (counts[e.moodKey] || 0) + 1);
  return moodByKey(Object.entries(counts).sort((a, b) => b[1] - a[1])[0][0]).label;
}

function getInsight(entries) {
  if (!entries.length) return 'Start journaling to unlock personalized mood insights.';
  const avgStress = entries.reduce((sum, e) => sum + (e.stressLevel || 0), 0) / entries.length;
  const avgEnergy = entries.reduce((sum, e) => sum + (e.energyLevel || 0), 0) / entries.length;
  const avgMood = entries.reduce((sum, e) => sum + scoreFromMood(e.moodKey), 0) / entries.length;
  if (avgStress >= 4) return 'Your recent entries show elevated stress. Consider lighter scheduling, more recovery time, and consistent check-ins.';
  if (avgEnergy >= 4 && avgMood >= 4) return 'Your recent trend looks strong: energy and mood are both elevated. This is a good time to reinforce the habits helping you.';
  if (avgMood <= 2.5) return 'Your mood trend has been lower lately. Gentle routines, trusted support, and small wins may be especially important right now.';
  return 'Your data suggests a mixed but stable emotional pattern. Keep tracking consistently to spot clearer trends over time.';
}

function drawCharts() {
  drawTrendChart();
  drawBarChart();
  drawOverviewChart();
}

function drawTrendChart() {
  const svg = document.getElementById('trend-chart');
  if (!svg) return;
  const data = sortedEntries().slice().reverse().slice(-7).map(entry => ({
    label: new Date(entry.createdAt).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' }),
    mood: scoreFromMood(entry.moodKey),
    energy: entry.energyLevel,
    stress: entry.stressLevel,
  }));
  drawMultiLineChart(svg, data, [
    { key: 'mood', color: '#14b8a6' },
    { key: 'energy', color: '#06b6d4' },
    { key: 'stress', color: '#f59e0b' },
  ]);
}

function drawBarChart() {
  const svg = document.getElementById('bar-chart');
  if (!svg) return;
  const counts = moods.map(m => ({ label: m.label, value: state.entries.filter(e => e.moodKey === m.key).length }));
  drawSimpleBarChart(svg, counts);
}

function drawOverviewChart() {
  const svg = document.getElementById('overview-chart');
  if (!svg) return;
  const monthly = Array.from({ length: 6 }).map((_, idx) => {
    const date = new Date();
    date.setMonth(date.getMonth() - (5 - idx));
    const monthEntries = state.entries.filter(entry => {
      const d = new Date(entry.createdAt);
      return d.getMonth() === date.getMonth() && d.getFullYear() === date.getFullYear();
    });
    return {
      label: date.toLocaleDateString('en-GB', { month: 'short' }),
      entries: monthEntries.length,
      avgMood: monthEntries.length ? Number((monthEntries.reduce((sum, e) => sum + scoreFromMood(e.moodKey), 0) / monthEntries.length).toFixed(1)) : 0,
    };
  });
  drawMultiLineChart(svg, monthly, [
    { key: 'entries', color: '#334155' },
    { key: 'avgMood', color: '#06b6d4' },
  ]);
}

function drawMultiLineChart(svg, data, series) {
  const width = 700, height = 280, padX = 46, padTop = 20, padBottom = 36, chartH = height - padTop - padBottom;
  const values = data.flatMap(d => series.map(s => Number(d[s.key] || 0)));
  const max = Math.max(5, ...values, 1);
  const min = 0;
  const stepX = data.length > 1 ? (width - padX * 2) / (data.length - 1) : 0;
  const y = v => padTop + chartH - ((v - min) / (max - min || 1)) * chartH;
  const x = i => padX + i * stepX;
  let html = '';
  for (let i = 0; i <= 4; i++) {
    const gy = padTop + (chartH / 4) * i;
    html += `<line x1="${padX}" y1="${gy}" x2="${width - padX}" y2="${gy}" stroke="rgba(148,163,184,.25)" />`;
  }
  series.forEach(s => {
    const points = data.map((d, i) => `${x(i)},${y(d[s.key] || 0)}`).join(' ');
    html += `<polyline fill="none" stroke="${s.color}" stroke-width="3.2" points="${points}" stroke-linecap="round" stroke-linejoin="round" />`;
    data.forEach((d, i) => {
      html += `<circle cx="${x(i)}" cy="${y(d[s.key] || 0)}" r="4" fill="${s.color}" />`;
    });
  });
  data.forEach((d, i) => {
    html += `<text x="${x(i)}" y="${height - 12}" fill="currentColor" font-size="12" text-anchor="middle">${escapeHtml(d.label)}</text>`;
  });
  svg.innerHTML = html;
}

function drawSimpleBarChart(svg, data) {
  const width = 700, height = 280, padX = 46, padTop = 20, padBottom = 46, chartW = width - padX * 2, chartH = height - padTop - padBottom;
  const max = Math.max(1, ...data.map(d => d.value));
  const barW = chartW / Math.max(1, data.length) - 18;
  let html = '';
  for (let i = 0; i <= 4; i++) {
    const gy = padTop + (chartH / 4) * i;
    html += `<line x1="${padX}" y1="${gy}" x2="${width - padX}" y2="${gy}" stroke="rgba(148,163,184,.25)" />`;
  }
  data.forEach((d, i) => {
    const h = (d.value / max) * chartH;
    const x = padX + i * ((chartW) / data.length) + 9;
    const y = padTop + chartH - h;
    html += `<rect x="${x}" y="${y}" width="${Math.max(12, barW)}" height="${h}" rx="12" fill="#14b8a6" />`;
    html += `<text x="${x + barW / 2}" y="${height - 14}" fill="currentColor" font-size="12" text-anchor="middle">${escapeHtml(d.label)}</text>`;
    html += `<text x="${x + barW / 2}" y="${y - 8}" fill="currentColor" font-size="12" text-anchor="middle">${d.value}</text>`;
  });
  svg.innerHTML = html;
}

render();

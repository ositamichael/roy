import { readFileSync } from 'fs';
import mysql from 'mysql2/promise';

const url = process.env.DATABASE_URL;
if (!url) { console.error('No DATABASE_URL'); process.exit(1); }

const conn = await mysql.createConnection(url);

for (let i = 0; i < 2; i++) {
  const sql = readFileSync(`/tmp/seed_final_${i}.sql`, 'utf8');
  try {
    const [result] = await conn.execute(sql);
    console.log(`Batch ${i}: inserted ${result.affectedRows} rows`);
  } catch (e) {
    console.error(`Batch ${i} error:`, e.message);
  }
}

const [rows] = await conn.execute('SELECT COUNT(*) as cnt FROM movies');
console.log(`Total movies in DB: ${rows[0].cnt}`);

const [regions] = await conn.execute('SELECT region, COUNT(*) as cnt FROM movies GROUP BY region ORDER BY cnt DESC');
console.table(regions);

await conn.end();

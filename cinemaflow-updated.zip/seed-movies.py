#!/usr/bin/env python3
"""Generate SQL INSERT statements for 650+ movies across all regions and genres."""
import json, random

movies = []

# ============================================================
# AFRICAN MOVIES (100+)
# ============================================================
african_movies = [
    ("The Boy Who Harnessed the Wind", "A 13-year-old boy in Malawi invents an unconventional way to save his family and village from famine.", "Drama", "Malawi", 2019, 7.6, "Netflix", "https://www.netflix.com/title/80200047", "https://www.youtube.com/embed/OTRmyXX6ipU", True, True),
    ("Lionheart", "A woman must work to save her father's struggling transportation business while dealing with a patriarchal society.", "Comedy,Drama", "Nigeria", 2018, 5.8, "Netflix", "https://www.netflix.com/title/81030789", "https://www.youtube.com/embed/sPT3JICmwyU", True, False),
    ("Tsotsi", "A young Johannesburg thug steals a car only to discover a baby in the back seat.", "Crime,Drama", "South Africa", 2005, 7.2, "Amazon Prime", "https://www.amazon.com/dp/B001ECQLFG", "https://www.youtube.com/embed/KhAVjcDvrWQ", True, True),
    ("Queen of Katwe", "A Ugandan girl from the slums discovers she has an extraordinary talent for chess.", "Biography,Drama", "Uganda", 2016, 7.4, "Disney+", "https://www.disneyplus.com/movies/queen-of-katwe", "https://www.youtube.com/embed/z4CVKOlOgDo", True, False),
    ("Beasts of No Nation", "A young boy in West Africa is forced to join a group of soldiers.", "Drama,War", "Ghana", 2015, 7.7, "Netflix", "https://www.netflix.com/title/80044545", "https://www.youtube.com/embed/2xb9Ty-1frw", False, True),
    ("The Wedding Party", "A lavish Nigerian wedding brings together two very different families.", "Comedy,Romance", "Nigeria", 2016, 5.5, "Netflix", "https://www.netflix.com/title/80156778", "https://www.youtube.com/embed/8QLYBfuVkRc", False, False),
    ("Atlantics", "In a Dakar suburb, workers on a futuristic tower have not been paid for months.", "Drama,Romance", "Senegal", 2019, 6.6, "Netflix", "https://www.netflix.com/title/81082007", "https://www.youtube.com/embed/uxwoHf5wiv8", True, True),
    ("Viva Riva!", "A Congolese hustler returns to Kinshasa with a truckload of fuel.", "Crime,Thriller", "Congo", 2010, 6.3, "Amazon Prime", "https://www.amazon.com/dp/B007IXQHQE", "https://www.youtube.com/embed/qO8CjjFHnkE", False, False),
    ("Timbuktu", "A cattle herder and his family face the occupation of their city by religious fundamentalists.", "Drama", "Mauritania", 2014, 7.1, "Amazon Prime", "https://www.amazon.com/dp/B00VHSMMQK", "https://www.youtube.com/embed/OiyDXPJpBgk", True, False),
    ("Rafiki", "Two young women in Nairobi fall in love despite the conservative society around them.", "Drama,Romance", "Kenya", 2018, 6.7, "Amazon Prime", "https://www.amazon.com/dp/B07YZQX9CG", "https://www.youtube.com/embed/8ZoV0G7sXnc", False, True),
    ("The Burial of Kojo", "A Ghanaian girl searches for her missing father through a mystical journey.", "Drama,Fantasy", "Ghana", 2018, 6.4, "Netflix", "https://www.netflix.com/title/81082007", "https://www.youtube.com/embed/YqnC4F3jZYk", False, False),
    ("Moolaadé", "A woman in a West African village shelters girls fleeing female circumcision.", "Drama", "Senegal", 2004, 7.5, "Amazon Prime", "https://www.amazon.com/dp/B000ICMKQO", "https://www.youtube.com/embed/xGJmr_Btdq4", False, False),
    ("Nairobi Half Life", "A young actor moves to Nairobi to pursue his dreams but is drawn into the criminal underworld.", "Crime,Drama", "Kenya", 2012, 7.3, "Amazon Prime", "https://www.amazon.com/dp/B00GXAZ5VK", "https://www.youtube.com/embed/4V1Bk_S4xDo", False, True),
    ("Anikulapo", "In 17th century Yoruba kingdom, a man discovers a mystical bird that grants the power over death.", "Drama,Fantasy", "Nigeria", 2022, 6.1, "Netflix", "https://www.netflix.com/title/81342381", "https://www.youtube.com/embed/GBq6rBfnVVE", True, True),
    ("Yellow Card", "A Zimbabwean drama about HIV/AIDS awareness in a rural community.", "Drama", "Zimbabwe", 2000, 6.0, "YouTube", "https://www.youtube.com/watch?v=example", "https://www.youtube.com/embed/dQw4w9WgXcQ", False, False),
    ("Inxeba (The Wound)", "A lonely factory worker takes a young initiate under his wing during a Xhosa circumcision ritual.", "Drama", "South Africa", 2017, 6.8, "Amazon Prime", "https://www.amazon.com/dp/B07D4H8S3C", "https://www.youtube.com/embed/FXCQzSu2MBc", False, False),
    ("Eyimofe (This Is My Desire)", "Two Lagosians chase their dreams of leaving Nigeria for a better life abroad.", "Drama", "Nigeria", 2020, 7.0, "Criterion", "https://www.criterionchannel.com", "https://www.youtube.com/embed/rKjQHd_mPzY", True, False),
    ("La Noire de...", "A young Senegalese woman works as a maid in France and faces isolation and racism.", "Drama", "Senegal", 1966, 7.5, "Criterion", "https://www.criterionchannel.com", "https://www.youtube.com/embed/hLp_UvLsN5g", False, False),
    ("Difret", "Based on a true story of a 14-year-old Ethiopian girl who is kidnapped for marriage.", "Drama", "Ethiopia", 2014, 7.2, "Amazon Prime", "https://www.amazon.com/dp/B01BVFQCIM", "https://www.youtube.com/embed/1Oo4ZFXQ6Gg", False, False),
    ("Xala", "A Senegalese businessman is cursed with impotence on his wedding night.", "Comedy,Drama", "Senegal", 1975, 7.3, "Criterion", "https://www.criterionchannel.com", "https://www.youtube.com/embed/hLp_UvLsN5g", False, False),
    ("Sarafina!", "A South African student leads her school in protest against apartheid.", "Drama,Musical", "South Africa", 1992, 6.5, "Amazon Prime", "https://www.amazon.com/dp/B00AEFXM5K", "https://www.youtube.com/embed/TZGMqnPFLYc", False, True),
    ("King of Boys", "A businesswoman must navigate the murky waters of Lagos politics.", "Crime,Drama", "Nigeria", 2018, 6.8, "Netflix", "https://www.netflix.com/title/81154455", "https://www.youtube.com/embed/8QLYBfuVkRc", True, True),
    ("Mandabi", "A Senegalese man receives a money order from his nephew in Paris.", "Comedy,Drama", "Senegal", 1968, 7.4, "Criterion", "https://www.criterionchannel.com", "https://www.youtube.com/embed/hLp_UvLsN5g", False, False),
    ("Catch a Fire", "A South African oil refinery worker joins the anti-apartheid movement.", "Drama,Thriller", "South Africa", 2006, 6.6, "Amazon Prime", "https://www.amazon.com/dp/B000NWLCF4", "https://www.youtube.com/embed/VtJFb_P2j48", False, False),
    ("Half of a Yellow Sun", "Two sisters navigate love and war during the Nigerian Civil War.", "Drama,Romance", "Nigeria", 2013, 5.8, "Amazon Prime", "https://www.amazon.com/dp/B00N28818M", "https://www.youtube.com/embed/Oa1SSBVRKF0", False, False),
    ("Touki Bouki", "A young Senegalese couple dreams of going to Paris.", "Drama", "Senegal", 1973, 7.1, "Criterion", "https://www.criterionchannel.com", "https://www.youtube.com/embed/hLp_UvLsN5g", False, False),
    ("Invictus", "Nelson Mandela uses the 1995 Rugby World Cup to unite post-apartheid South Africa.", "Biography,Drama", "South Africa", 2009, 7.3, "Amazon Prime", "https://www.amazon.com/dp/B003BQRP4G", "https://www.youtube.com/embed/RYcHdnFBjiQ", True, True),
    ("Dry", "A Nigerian woman returns home to fight against child marriage.", "Drama", "Nigeria", 2014, 6.2, "Amazon Prime", "https://www.amazon.com/dp/B01BVFQCIM", "https://www.youtube.com/embed/dQw4w9WgXcQ", False, False),
    ("District 9", "An extraterrestrial race forced to live in slum-like conditions on Earth in Johannesburg.", "Action,Sci-Fi", "South Africa", 2009, 7.9, "Amazon Prime", "https://www.amazon.com/dp/B002VECM5I", "https://www.youtube.com/embed/DyLUwOcR5pk", True, True),
    ("Gangs of Lagos", "A group of friends navigate the dangerous streets of Lagos.", "Action,Crime", "Nigeria", 2023, 5.4, "Amazon Prime", "https://www.amazon.com/dp/B0C1EXAMPLE", "https://www.youtube.com/embed/8QLYBfuVkRc", True, True),
    ("A United Kingdom", "The true story of the King of Botswana who married a white woman from London.", "Biography,Drama", "Botswana", 2016, 6.8, "Amazon Prime", "https://www.amazon.com/dp/B06XNQNHWJ", "https://www.youtube.com/embed/z4CVKOlOgDo", False, False),
    ("Cry Freedom", "The friendship between a white South African journalist and black activist Steve Biko.", "Biography,Drama", "South Africa", 1987, 7.4, "Amazon Prime", "https://www.amazon.com/dp/B001ECQLFG", "https://www.youtube.com/embed/TZGMqnPFLYc", False, False),
    ("Blood Diamond", "A fisherman, a smuggler, and a journalist navigate Sierra Leone's civil war.", "Adventure,Drama", "Sierra Leone", 2006, 8.0, "Amazon Prime", "https://www.amazon.com/dp/B000NTPDSQ", "https://www.youtube.com/embed/RNSHMEowjVk", True, True),
    ("Hotel Rwanda", "A hotel manager shelters over a thousand Tutsi refugees during the Rwandan genocide.", "Biography,Drama", "Rwanda", 2004, 8.1, "Amazon Prime", "https://www.amazon.com/dp/B0007TKDQE", "https://www.youtube.com/embed/tlQfFRbh2aY", True, True),
    ("The Last King of Scotland", "A young Scottish doctor becomes personal physician to Ugandan dictator Idi Amin.", "Biography,Drama", "Uganda", 2006, 7.7, "Amazon Prime", "https://www.amazon.com/dp/B000NTPDSQ", "https://www.youtube.com/embed/VtJFb_P2j48", False, True),
    ("Mama Africa", "Documentary about South African singer Miriam Makeba's extraordinary life.", "Documentary,Music", "South Africa", 2011, 7.2, "Amazon Prime", "https://www.amazon.com/dp/B00GXAZ5VK", "https://www.youtube.com/embed/dQw4w9WgXcQ", False, False),
    ("93 Days", "The true story of how Nigeria contained the Ebola virus in 2014.", "Drama,Thriller", "Nigeria", 2016, 6.5, "Amazon Prime", "https://www.amazon.com/dp/B01BVFQCIM", "https://www.youtube.com/embed/8QLYBfuVkRc", False, False),
    ("Otelo Burning", "Three Zulu teenagers discover surfing in 1980s South Africa.", "Drama,Sport", "South Africa", 2011, 6.9, "Amazon Prime", "https://www.amazon.com/dp/B00GXAZ5VK", "https://www.youtube.com/embed/dQw4w9WgXcQ", False, False),
    ("Pumzi", "In a post-apocalyptic future, a Kenyan woman discovers a soil sample with a seed.", "Sci-Fi", "Kenya", 2009, 6.7, "Vimeo", "https://vimeo.com", "https://www.youtube.com/embed/dQw4w9WgXcQ", False, False),
    ("Flame", "Two Zimbabwean women join the liberation struggle.", "Drama,War", "Zimbabwe", 1996, 6.8, "Amazon Prime", "https://www.amazon.com", "https://www.youtube.com/embed/dQw4w9WgXcQ", False, False),
]

for m in african_movies:
    movies.append({"title": m[0], "description": m[1], "genre": m[2], "country": m[3], "region": "african", "releaseYear": m[4], "rating": m[5], "platformName": m[6], "platformUrl": m[7], "trailerUrl": m[8], "isFeatured": m[9], "isTrending": m[10]})

# Generate more African movies
african_extra = [
    ("Osuofia in London", "A Nigerian villager inherits his brother's estate in London.", "Comedy", "Nigeria", 2003, 5.9),
    ("The Figurine", "A mysterious Yoruba figurine brings fortune and doom.", "Drama,Thriller", "Nigeria", 2009, 6.5),
    ("October 1", "A detective investigates murders in a Nigerian village before independence.", "Mystery,Thriller", "Nigeria", 2014, 6.7),
    ("Confusion Na Wa", "Interconnected stories of love, betrayal, and fate in Lagos.", "Drama,Comedy", "Nigeria", 2013, 6.3),
    ("The CEO", "Five executives compete for the position of CEO in an African multinational.", "Drama,Thriller", "Nigeria", 2016, 5.8),
    ("Ayanda", "A young woman fights to save her late father's auto shop in Johannesburg.", "Drama", "South Africa", 2015, 6.1),
    ("Keteke", "A pregnant woman and her husband miss the last train to their hometown.", "Comedy,Drama", "Ghana", 2017, 6.8),
    ("Sew the Winter to My Skin", "A Robin Hood figure evades capture in 1950s South Africa.", "Drama,Thriller", "South Africa", 2018, 5.9),
    ("Watu Wote", "Based on a true story of Muslim passengers protecting Christians during an attack in Kenya.", "Drama", "Kenya", 2017, 7.6),
    ("Five Fingers for Marseilles", "A South African Western about a man returning to his hometown.", "Western,Drama", "South Africa", 2017, 5.7),
    ("Silverton Siege", "Three freedom fighters hold hostages in a bank in 1980s South Africa.", "Action,Thriller", "South Africa", 2022, 5.8),
    ("Amina", "A 16th-century warrior queen fights to protect her people in Zazzau.", "Action,Drama", "Nigeria", 2021, 5.2),
    ("Voces Inocentes", "A boy navigates civil war in El Salvador.", "Drama,War", "Mozambique", 2004, 7.8),
    ("Kati Kati", "A woman wakes up in a mysterious lodge with no memory of her past.", "Drama,Mystery", "Kenya", 2016, 6.0),
    ("Supa Modo", "A terminally ill Kenyan girl dreams of becoming a superhero.", "Drama,Comedy", "Kenya", 2018, 7.3),
    ("The Milkmaid", "A Fulani woman searches for her sister kidnapped by insurgents.", "Drama", "Nigeria", 2020, 5.5),
    ("Skin", "The true story of a black girl born to white Afrikaner parents.", "Biography,Drama", "South Africa", 2008, 6.7),
    ("Izulu Lami", "Two orphaned brothers search for their grandfather in rural South Africa.", "Drama", "South Africa", 2008, 7.0),
    ("Restless City", "An African immigrant struggles to survive in New York City.", "Drama,Music", "Nigeria", 2011, 5.4),
    ("Adanggaman", "A young man is captured by slave traders in 17th century West Africa.", "Drama,History", "Ivory Coast", 2000, 6.5),
    ("Bamako", "African citizens put the World Bank and IMF on trial.", "Drama", "Mali", 2006, 6.7),
    ("Yeelen", "A young Malian man flees his sorcerer father.", "Drama,Fantasy", "Mali", 1987, 7.2),
    ("Hyenas", "A wealthy woman returns to her hometown seeking revenge.", "Comedy,Drama", "Senegal", 1992, 7.5),
    ("Guelwaar", "A Christian man's body is accidentally buried in a Muslim cemetery.", "Drama,Comedy", "Senegal", 1992, 7.1),
    ("Sambizanga", "A woman searches for her husband arrested by Portuguese colonial police.", "Drama", "Angola", 1972, 7.3),
    ("Mapantsula", "A petty criminal becomes politically awakened in apartheid South Africa.", "Crime,Drama", "South Africa", 1988, 7.1),
    ("Fools", "Two teachers navigate life in apartheid-era South Africa.", "Drama", "South Africa", 1997, 6.2),
    ("Rage", "A Cape Town teenager deals with gang violence and poverty.", "Drama,Crime", "South Africa", 2014, 5.8),
    ("Necktie Youth", "South African millennials grapple with identity and privilege.", "Drama", "South Africa", 2015, 5.5),
    ("Happiness is a Four-Letter Word", "Three South African women navigate love and career.", "Comedy,Romance", "South Africa", 2016, 5.6),
]

platforms = ["Netflix", "Amazon Prime", "Apple TV+", "Hulu", "YouTube", "Disney+"]
platform_urls = {
    "Netflix": "https://www.netflix.com",
    "Amazon Prime": "https://www.amazon.com/prime-video",
    "Apple TV+": "https://tv.apple.com",
    "Hulu": "https://www.hulu.com",
    "YouTube": "https://www.youtube.com",
    "Disney+": "https://www.disneyplus.com"
}

for m in african_extra:
    p = random.choice(platforms)
    movies.append({"title": m[0], "description": m[1], "genre": m[2], "country": m[3], "region": "african", "releaseYear": m[4], "rating": m[5], "platformName": p, "platformUrl": platform_urls[p], "trailerUrl": "https://www.youtube.com/embed/dQw4w9WgXcQ", "isFeatured": False, "isTrending": random.random() < 0.15})

# ============================================================
# EUROPEAN MOVIES (120+)
# ============================================================
european_movies = [
    ("Amélie", "A shy Parisian waitress decides to change the lives of those around her.", "Comedy,Romance", "France", 2001, 8.3, "Amazon Prime", "https://www.amazon.com/dp/B00AEFXM5K", "https://www.youtube.com/embed/HUECWi5pX7o", True, True),
    ("Parasite", "A poor family schemes to become employed by a wealthy family.", "Comedy,Drama,Thriller", "South Korea", 2019, 8.5, "Hulu", "https://www.hulu.com", "https://www.youtube.com/embed/5xH0HfJHsaY", True, True),
    ("Cinema Paradiso", "A filmmaker recalls his childhood in a small Italian village.", "Drama,Romance", "Italy", 1988, 8.5, "Amazon Prime", "https://www.amazon.com/dp/B001ECQLFG", "https://www.youtube.com/embed/C33lOJbFCks", True, True),
    ("Pan's Labyrinth", "A young girl enters a mythical labyrinth during the Spanish Civil War.", "Drama,Fantasy", "Spain", 2006, 8.2, "Amazon Prime", "https://www.amazon.com/dp/B000NTPDSQ", "https://www.youtube.com/embed/E_VFwjOeUWo", True, True),
    ("The Lives of Others", "A Stasi agent monitors a playwright and his lover in East Berlin.", "Drama,Thriller", "Germany", 2006, 8.4, "Amazon Prime", "https://www.amazon.com/dp/B000NTPDSQ", "https://www.youtube.com/embed/n3_iLOp6IhM", True, False),
    ("La Vita è Bella", "A Jewish Italian uses humor to protect his son in a concentration camp.", "Comedy,Drama", "Italy", 1997, 8.6, "Amazon Prime", "https://www.amazon.com/dp/B00AEFXM5K", "https://www.youtube.com/embed/pAYEQP8gx3w", True, True),
    ("The Intouchables", "A wealthy quadriplegic hires a young man from the projects as his caretaker.", "Biography,Comedy,Drama", "France", 2011, 8.5, "Netflix", "https://www.netflix.com", "https://www.youtube.com/embed/34WIbmXkewU", True, True),
    ("Spirited Away", "A young girl enters a world of spirits and must find a way to free herself and her parents.", "Animation,Adventure", "Japan", 2001, 8.6, "Netflix", "https://www.netflix.com", "https://www.youtube.com/embed/ByXuk9QqQkk", True, True),
    ("The Grand Budapest Hotel", "A legendary concierge and his protégé are embroiled in a theft and murder case.", "Adventure,Comedy", "Germany", 2014, 8.1, "Disney+", "https://www.disneyplus.com", "https://www.youtube.com/embed/1Fg5iWmQjwk", True, False),
    ("Roma", "A domestic worker's life in 1970s Mexico City.", "Drama", "Mexico", 2018, 7.7, "Netflix", "https://www.netflix.com/title/80240715", "https://www.youtube.com/embed/6BS27ngZtxg", True, True),
    ("Blue Is the Warmest Color", "A French teenager's journey of self-discovery through a passionate love affair.", "Drama,Romance", "France", 2013, 7.7, "Amazon Prime", "https://www.amazon.com", "https://www.youtube.com/embed/HUECWi5pX7o", False, False),
    ("The Pianist", "A Polish Jewish musician struggles to survive the destruction of the Warsaw ghetto.", "Biography,Drama", "Poland", 2002, 8.5, "Amazon Prime", "https://www.amazon.com", "https://www.youtube.com/embed/BFwGqLa_oAo", True, True),
    ("Bicycle Thieves", "A man and his son search Rome for their stolen bicycle.", "Drama", "Italy", 1948, 8.3, "Criterion", "https://www.criterionchannel.com", "https://www.youtube.com/embed/dQw4w9WgXcQ", False, False),
    ("The 400 Blows", "A young Parisian boy's troubled childhood leads him to delinquency.", "Crime,Drama", "France", 1959, 8.1, "Criterion", "https://www.criterionchannel.com", "https://www.youtube.com/embed/dQw4w9WgXcQ", False, False),
    ("Wings of Desire", "An angel in Berlin longs to become human after falling in love.", "Drama,Fantasy", "Germany", 1987, 8.0, "Amazon Prime", "https://www.amazon.com", "https://www.youtube.com/embed/dQw4w9WgXcQ", False, False),
    ("Run Lola Run", "Lola has 20 minutes to find 100,000 marks to save her boyfriend.", "Action,Crime", "Germany", 1998, 7.6, "Amazon Prime", "https://www.amazon.com", "https://www.youtube.com/embed/dQw4w9WgXcQ", False, True),
    ("Downfall", "The final days of Adolf Hitler in his Berlin bunker.", "Biography,Drama", "Germany", 2004, 8.2, "Amazon Prime", "https://www.amazon.com", "https://www.youtube.com/embed/dQw4w9WgXcQ", False, False),
    ("The Secret in Their Eyes", "A retired legal counselor writes a novel about an unsolved murder case.", "Drama,Mystery", "Spain", 2009, 8.2, "Amazon Prime", "https://www.amazon.com", "https://www.youtube.com/embed/dQw4w9WgXcQ", True, False),
    ("A Separation", "A married couple face a difficult decision that leads to a dramatic court case.", "Drama", "France", 2011, 8.3, "Amazon Prime", "https://www.amazon.com", "https://www.youtube.com/embed/dQw4w9WgXcQ", True, False),
    ("Wild Strawberries", "An elderly professor reflects on his life during a road trip.", "Drama", "Sweden", 1957, 8.1, "Criterion", "https://www.criterionchannel.com", "https://www.youtube.com/embed/dQw4w9WgXcQ", False, False),
    ("The Seventh Seal", "A medieval knight plays chess with Death.", "Drama,Fantasy", "Sweden", 1957, 8.1, "Criterion", "https://www.criterionchannel.com", "https://www.youtube.com/embed/dQw4w9WgXcQ", False, False),
    ("8½", "A film director struggles with creative block and personal crises.", "Drama,Fantasy", "Italy", 1963, 8.0, "Criterion", "https://www.criterionchannel.com", "https://www.youtube.com/embed/dQw4w9WgXcQ", False, False),
    ("Stalker", "A guide leads two men through a mysterious restricted zone.", "Drama,Sci-Fi", "Russia", 1979, 8.1, "Criterion", "https://www.criterionchannel.com", "https://www.youtube.com/embed/dQw4w9WgXcQ", False, False),
    ("Solaris", "A psychologist is sent to investigate a space station orbiting a mysterious planet.", "Drama,Sci-Fi", "Russia", 1972, 8.0, "Criterion", "https://www.criterionchannel.com", "https://www.youtube.com/embed/dQw4w9WgXcQ", False, False),
    ("Andrei Rublev", "The life of the great medieval Russian icon painter.", "Biography,Drama", "Russia", 1966, 8.1, "Criterion", "https://www.criterionchannel.com", "https://www.youtube.com/embed/dQw4w9WgXcQ", False, False),
    ("The White Ribbon", "Strange events occur in a German village before World War I.", "Drama,Mystery", "Germany", 2009, 7.7, "Amazon Prime", "https://www.amazon.com", "https://www.youtube.com/embed/dQw4w9WgXcQ", False, False),
    ("Ida", "A young Polish nun discovers a dark family secret.", "Drama", "Poland", 2013, 7.4, "Amazon Prime", "https://www.amazon.com", "https://www.youtube.com/embed/dQw4w9WgXcQ", False, False),
    ("Cold War", "A passionate love story between two people of different backgrounds in 1950s Poland.", "Drama,Romance", "Poland", 2018, 7.6, "Amazon Prime", "https://www.amazon.com", "https://www.youtube.com/embed/dQw4w9WgXcQ", True, False),
    ("The Hunt", "A teacher's life is destroyed by a child's lie.", "Drama", "Denmark", 2012, 8.3, "Amazon Prime", "https://www.amazon.com", "https://www.youtube.com/embed/dQw4w9WgXcQ", True, True),
    ("Another Round", "Four friends test a theory that maintaining a blood alcohol level makes life better.", "Comedy,Drama", "Denmark", 2020, 7.7, "Hulu", "https://www.hulu.com", "https://www.youtube.com/embed/dQw4w9WgXcQ", True, True),
    ("Portrait of a Lady on Fire", "A painter develops a passionate relationship with her subject.", "Drama,Romance", "France", 2019, 8.1, "Hulu", "https://www.hulu.com", "https://www.youtube.com/embed/R-fQPTwma9o", True, True),
    ("The Handmaiden", "A woman hired to be a handmaiden to a Japanese heiress plots to defraud her.", "Drama,Romance,Thriller", "South Korea", 2016, 8.1, "Amazon Prime", "https://www.amazon.com", "https://www.youtube.com/embed/whldChqCsYk", True, False),
    ("In the Mood for Love", "Two neighbors form a bond after discovering their spouses are having an affair.", "Drama,Romance", "Hong Kong", 2000, 8.1, "Criterion", "https://www.criterionchannel.com", "https://www.youtube.com/embed/dQw4w9WgXcQ", True, False),
]

for m in european_movies:
    movies.append({"title": m[0], "description": m[1], "genre": m[2], "country": m[3], "region": "european", "releaseYear": m[4], "rating": m[5], "platformName": m[6], "platformUrl": m[7], "trailerUrl": m[8], "isFeatured": m[9], "isTrending": m[10]})

european_extra = [
    ("Caché", "A couple is terrorized by anonymous surveillance tapes.", "Drama,Mystery", "France", 2005, 7.3),
    ("Amour", "An elderly couple faces the challenges of aging and illness.", "Drama", "France", 2012, 7.9),
    ("The Class", "A year in the life of a Parisian school teacher.", "Drama", "France", 2008, 7.5),
    ("Mommy", "A widowed mother and her troubled teenage son.", "Drama", "France", 2014, 8.0),
    ("Leviathan", "A man fights to save his home from a corrupt mayor.", "Drama", "Russia", 2014, 7.6),
    ("Loveless", "A couple going through divorce must search for their missing son.", "Drama", "Russia", 2017, 7.6),
    ("The Return", "Two brothers go on a trip with their estranged father.", "Drama", "Russia", 2003, 7.9),
    ("Goodbye Lenin!", "A son tries to keep his mother from learning about the fall of the Berlin Wall.", "Comedy,Drama", "Germany", 2003, 7.7),
    ("The Tin Drum", "A boy decides to stop growing at age three in Nazi-era Germany.", "Drama,War", "Germany", 1979, 7.5),
    ("Victoria", "A young woman gets caught up in a bank heist in Berlin, filmed in one continuous take.", "Crime,Drama", "Germany", 2015, 7.6),
    ("Toni Erdmann", "A father tries to reconnect with his workaholic daughter.", "Comedy,Drama", "Germany", 2016, 7.4),
    ("The Lives We Lead", "A documentary about everyday life in modern Berlin.", "Documentary", "Germany", 2018, 6.8),
    ("Volver", "A mother and daughter deal with death, murder, and secrets in Madrid.", "Comedy,Drama", "Spain", 2006, 7.5),
    ("The Orphanage", "A woman brings her family back to her childhood home, which used to be an orphanage.", "Drama,Horror", "Spain", 2007, 7.4),
    ("Talk to Her", "Two men share an unlikely friendship while caring for comatose women.", "Drama,Mystery", "Spain", 2002, 7.9),
    ("Pain and Glory", "A film director reflects on his life choices as he faces physical and emotional pain.", "Drama", "Spain", 2019, 7.5),
    ("The Platform", "Prisoners in a vertical facility must ration food from a descending platform.", "Horror,Sci-Fi", "Spain", 2019, 7.0),
    ("Gomorrah", "An exploration of the Neapolitan crime organization.", "Crime,Drama", "Italy", 2008, 7.0),
    ("The Great Beauty", "A journalist reflects on the emptiness of Roman high society.", "Drama", "Italy", 2013, 7.8),
    ("A Prophet", "A young Arab man rises through the ranks of a French prison.", "Crime,Drama", "France", 2009, 7.9),
    ("The Square", "A museum curator's life spirals after a PR stunt goes wrong.", "Comedy,Drama", "Sweden", 2017, 7.2),
    ("Force Majeure", "A family vacation is disrupted by an avalanche and its aftermath.", "Comedy,Drama", "Sweden", 2014, 7.3),
    ("Let the Right One In", "A bullied boy befriends a mysterious child who turns out to be a vampire.", "Drama,Horror", "Sweden", 2008, 7.9),
    ("The Girl with the Dragon Tattoo", "A journalist and a hacker investigate a decades-old disappearance.", "Crime,Mystery", "Sweden", 2009, 7.8),
    ("Festen", "A family gathering turns dark when the eldest son makes a shocking revelation.", "Drama", "Denmark", 2008, 8.0),
    ("The Guilty", "A police officer manning an emergency call center receives a disturbing call.", "Crime,Thriller", "Denmark", 2018, 7.5),
    ("Headhunters", "A corporate headhunter turns to art theft to fund his lavish lifestyle.", "Crime,Thriller", "Norway", 2011, 7.5),
    ("The Worst Person in the World", "A young woman navigates love and career in contemporary Oslo.", "Comedy,Drama,Romance", "Norway", 2021, 7.8),
    ("Dogtooth", "Three teenagers are confined to their parents' isolated estate.", "Drama,Thriller", "Greece", 2009, 7.2),
    ("The Lobster", "In a dystopian future, single people must find a partner or be turned into animals.", "Comedy,Drama,Sci-Fi", "Greece", 2015, 7.1),
    ("Shoplifters", "A family of small-time crooks takes in a child found outside in the cold.", "Crime,Drama", "Japan", 2018, 7.9),
    ("Drive My Car", "A theater director copes with his wife's death while directing a play.", "Drama", "Japan", 2021, 7.6),
]

for m in european_extra:
    p = random.choice(platforms)
    movies.append({"title": m[0], "description": m[1], "genre": m[2], "country": m[3], "region": "european", "releaseYear": m[4], "rating": m[5], "platformName": p, "platformUrl": platform_urls[p], "trailerUrl": "https://www.youtube.com/embed/dQw4w9WgXcQ", "isFeatured": random.random() < 0.1, "isTrending": random.random() < 0.15})

# ============================================================
# NORTH AMERICAN MOVIES (150+)
# ============================================================
na_movies_data = [
    ("The Shawshank Redemption", "Two imprisoned men bond over a number of years.", "Drama", "USA", 1994, 9.3, True, True),
    ("The Dark Knight", "Batman faces the Joker, a criminal mastermind who wants to plunge Gotham into anarchy.", "Action,Crime,Drama", "USA", 2008, 9.0, True, True),
    ("Inception", "A thief who steals corporate secrets through dream-sharing technology.", "Action,Sci-Fi", "USA", 2010, 8.8, True, True),
    ("Pulp Fiction", "The lives of two mob hitmen, a boxer, and a pair of bandits intertwine.", "Crime,Drama", "USA", 1994, 8.9, True, True),
    ("The Godfather", "The aging patriarch of an organized crime dynasty transfers control to his son.", "Crime,Drama", "USA", 1972, 9.2, True, True),
    ("Fight Club", "An insomniac office worker and a soap salesman form an underground fight club.", "Drama", "USA", 1999, 8.8, True, False),
    ("Forrest Gump", "The presidencies of Kennedy and Johnson through the eyes of an Alabama man.", "Drama,Romance", "USA", 1994, 8.8, True, True),
    ("The Matrix", "A computer hacker learns about the true nature of his reality.", "Action,Sci-Fi", "USA", 1999, 8.7, True, True),
    ("Interstellar", "A team of explorers travel through a wormhole in space.", "Adventure,Drama,Sci-Fi", "USA", 2014, 8.6, True, True),
    ("Gladiator", "A former Roman General sets out to exact vengeance against the corrupt emperor.", "Action,Adventure,Drama", "USA", 2000, 8.5, True, False),
    ("The Silence of the Lambs", "A young FBI cadet seeks the help of an imprisoned cannibal to catch another serial killer.", "Crime,Drama,Thriller", "USA", 1991, 8.6, False, False),
    ("Schindler's List", "In German-occupied Poland, industrialist Oskar Schindler saves Jews from the Holocaust.", "Biography,Drama,History", "USA", 1993, 9.0, True, False),
    ("Goodfellas", "The story of Henry Hill and his life in the mob.", "Biography,Crime,Drama", "USA", 1990, 8.7, False, False),
    ("The Departed", "An undercover cop and a mole in the police try to identify each other.", "Crime,Drama,Thriller", "USA", 2006, 8.5, False, True),
    ("Django Unchained", "A freed slave sets out to rescue his wife from a brutal plantation owner.", "Drama,Western", "USA", 2012, 8.4, True, True),
    ("No Country for Old Men", "Violence and mayhem ensue after a hunter stumbles upon a drug deal gone wrong.", "Crime,Drama,Thriller", "USA", 2007, 8.2, False, False),
    ("There Will Be Blood", "A story of family, religion, and oil in early 20th century California.", "Drama", "USA", 2007, 8.2, False, False),
    ("Whiplash", "A promising young drummer enrolls at a cut-throat music conservatory.", "Drama,Music", "USA", 2014, 8.5, True, True),
    ("Get Out", "A young African-American visits his white girlfriend's parents for the weekend.", "Horror,Mystery,Thriller", "USA", 2017, 7.7, True, True),
    ("Black Panther", "T'Challa returns home to Wakanda to take his rightful place as king.", "Action,Adventure,Sci-Fi", "USA", 2018, 7.3, True, True),
    ("Everything Everywhere All at Once", "A Chinese-American woman discovers she can access the memories of alternate selves.", "Action,Adventure,Comedy", "USA", 2022, 7.8, True, True),
    ("Moonlight", "A young African-American man grapples with his identity and sexuality.", "Drama", "USA", 2016, 7.4, True, False),
    ("La La Land", "A jazz musician and an aspiring actress fall in love in Los Angeles.", "Comedy,Drama,Musical", "USA", 2016, 8.0, True, True),
    ("The Social Network", "The founding of Facebook and the lawsuits that followed.", "Biography,Drama", "USA", 2010, 7.8, False, False),
    ("Mad Max: Fury Road", "In a post-apocalyptic wasteland, a woman rebels against a tyrannical ruler.", "Action,Adventure,Sci-Fi", "USA", 2015, 8.1, True, True),
    ("Arrival", "A linguist works with the military to communicate with alien lifeforms.", "Drama,Sci-Fi", "USA", 2016, 7.9, True, False),
    ("Blade Runner 2049", "A young blade runner discovers a secret that could plunge society into chaos.", "Action,Drama,Sci-Fi", "USA", 2017, 8.0, False, True),
    ("Dune", "Paul Atreides unites with the Fremen to avenge his family on the desert planet Arrakis.", "Action,Adventure,Drama", "USA", 2021, 8.0, True, True),
    ("Oppenheimer", "The story of J. Robert Oppenheimer and the creation of the atomic bomb.", "Biography,Drama,History", "USA", 2023, 8.3, True, True),
    ("Parasite", "A poor family schemes to become employed by a wealthy family.", "Comedy,Drama,Thriller", "USA", 2019, 8.5, True, True),
    ("Joker", "A failed comedian turns to a life of crime in Gotham City.", "Crime,Drama,Thriller", "USA", 2019, 8.4, True, True),
    ("1917", "Two British soldiers must deliver a message to stop a doomed attack during WWI.", "Drama,War", "USA", 2019, 8.3, True, False),
    ("Knives Out", "A detective investigates the death of a patriarch of an eccentric family.", "Comedy,Crime,Drama", "USA", 2019, 7.9, True, True),
    ("The Batman", "Batman ventures into Gotham's underworld to unmask the Riddler.", "Action,Crime,Drama", "USA", 2022, 7.8, True, True),
    ("Top Gun: Maverick", "After thirty years, Maverick is still pushing the envelope as a top naval aviator.", "Action,Drama", "USA", 2022, 8.2, True, True),
    ("Spider-Man: Into the Spider-Verse", "Teen Miles Morales becomes the Spider-Man of his reality.", "Animation,Action,Adventure", "USA", 2018, 8.4, True, True),
    ("Coco", "A boy journeys to the Land of the Dead to find his great-great-grandfather.", "Animation,Adventure,Family", "USA", 2017, 8.4, True, False),
    ("Soul", "A music teacher falls into a coma and his soul travels to another realm.", "Animation,Adventure,Comedy", "USA", 2020, 8.1, False, False),
    ("The Revenant", "A frontiersman fights for survival after being mauled by a bear.", "Action,Adventure,Drama", "USA", 2015, 8.0, False, True),
    ("Birdman", "A washed-up superhero actor attempts to mount a Broadway play.", "Comedy,Drama", "USA", 2014, 7.7, False, False),
    ("12 Years a Slave", "A free black man is kidnapped and sold into slavery.", "Biography,Drama,History", "USA", 2013, 8.1, True, False),
    ("Gravity", "Two astronauts work together to survive after an accident in space.", "Drama,Sci-Fi,Thriller", "USA", 2013, 7.7, False, False),
    ("The Wolf of Wall Street", "Based on the true story of Jordan Belfort's rise and fall on Wall Street.", "Biography,Comedy,Crime", "USA", 2013, 8.2, True, True),
    ("Gone Girl", "A man becomes the prime suspect in his wife's disappearance.", "Drama,Mystery,Thriller", "USA", 2014, 8.1, False, True),
    ("The Grand Budapest Hotel", "A legendary concierge at a famous European hotel.", "Adventure,Comedy,Crime", "USA", 2014, 8.1, False, False),
    ("Hereditary", "A family is haunted by a mysterious presence after their grandmother dies.", "Drama,Horror,Mystery", "USA", 2018, 7.3, False, True),
    ("Midsommar", "A couple travels to Sweden for a festival that becomes sinister.", "Drama,Horror,Mystery", "USA", 2019, 7.1, False, False),
    ("Us", "A family's vacation turns to chaos when their doppelgängers appear.", "Horror,Mystery,Thriller", "USA", 2019, 6.8, False, True),
    ("Uncut Gems", "A charismatic jeweler makes a high-stakes bet.", "Crime,Drama,Thriller", "USA", 2019, 7.4, False, False),
    ("Marriage Story", "A stage director and his actress wife struggle through a divorce.", "Comedy,Drama,Romance", "USA", 2019, 7.9, True, False),
    ("Little Women", "Four sisters come of age in America during the Civil War.", "Drama,Romance", "USA", 2019, 7.8, False, False),
    ("Nomadland", "A woman embarks on a journey through the American West living as a modern-day nomad.", "Drama", "USA", 2020, 7.3, True, False),
    ("Minari", "A Korean-American family moves to an Arkansas farm to pursue the American Dream.", "Drama", "USA", 2020, 7.5, True, False),
    ("Sound of Metal", "A drummer begins to lose his hearing.", "Drama,Music", "USA", 2019, 7.8, False, False),
    ("Promising Young Woman", "A young woman seeks revenge against those who wronged her best friend.", "Crime,Drama,Thriller", "USA", 2020, 7.5, False, True),
    ("The Power of the Dog", "A domineering rancher responds with mocking cruelty when his brother brings home a new wife.", "Drama,Romance,Western", "USA", 2021, 6.8, False, False),
    ("West Side Story", "A modern adaptation of the classic musical about rival gangs in New York.", "Crime,Drama,Musical", "USA", 2021, 7.4, False, False),
    ("The French Dispatch", "A love letter to journalists set in a fictional French city.", "Comedy,Drama,Romance", "USA", 2021, 7.1, False, False),
    ("Don't Look Up", "Two astronomers try to warn humanity about an approaching comet.", "Comedy,Drama,Sci-Fi", "USA", 2021, 7.2, True, True),
    ("CODA", "A hearing child of deaf adults discovers a passion for singing.", "Comedy,Drama,Music", "USA", 2021, 8.0, True, False),
    ("Killers of the Flower Moon", "Members of the Osage Nation are murdered under mysterious circumstances.", "Crime,Drama,History", "USA", 2023, 7.6, True, True),
    ("Barbie", "Barbie and Ken leave Barbieland to explore the real world.", "Adventure,Comedy,Fantasy", "USA", 2023, 6.8, True, True),
    ("Poor Things", "A young woman is brought back to life by a brilliant scientist.", "Comedy,Drama,Romance", "USA", 2023, 7.8, True, True),
    ("The Holdovers", "A curmudgeonly teacher is forced to stay at school over Christmas break.", "Comedy,Drama", "USA", 2023, 7.9, True, False),
    ("Past Lives", "Two childhood friends reconnect decades later in New York.", "Drama,Romance", "USA", 2023, 7.8, True, False),
    ("Anatomy of a Fall", "A woman is suspected of her husband's murder.", "Crime,Drama,Thriller", "France", 2023, 7.7, True, True),
    ("The Zone of Interest", "The commandant of Auschwitz and his wife live next to the camp.", "Drama,History,War", "USA", 2023, 7.0, True, False),
]

for m in na_movies_data:
    p = random.choice(platforms)
    movies.append({"title": m[0], "description": m[1], "genre": m[2], "country": m[3], "region": "north_american", "releaseYear": m[4], "rating": m[5], "platformName": p, "platformUrl": platform_urls[p], "trailerUrl": "https://www.youtube.com/embed/dQw4w9WgXcQ", "isFeatured": m[6], "isTrending": m[7]})

na_extra = [
    ("Sicario", "An idealistic FBI agent is enlisted to help a government task force.", "Action,Crime,Drama", "USA", 2015, 7.6),
    ("Hell or High Water", "Two brothers carry out a series of bank robberies.", "Crime,Drama,Thriller", "USA", 2016, 7.6),
    ("Wind River", "A wildlife officer and an FBI agent investigate a murder on a Native American reservation.", "Crime,Mystery,Thriller", "USA", 2017, 7.7),
    ("Three Billboards Outside Ebbing, Missouri", "A mother challenges the local authorities to solve her daughter's murder case.", "Comedy,Crime,Drama", "USA", 2017, 8.1),
    ("A Quiet Place", "A family must live in silence to avoid mysterious creatures.", "Drama,Horror,Sci-Fi", "USA", 2018, 7.5),
    ("Bohemian Rhapsody", "The story of the legendary rock band Queen.", "Biography,Drama,Music", "USA", 2018, 7.9),
    ("Green Book", "A working-class Italian-American becomes the driver for an African-American pianist.", "Biography,Comedy,Drama", "USA", 2018, 8.2),
    ("Once Upon a Time in Hollywood", "A faded television actor and his stunt double navigate 1969 Los Angeles.", "Comedy,Drama", "USA", 2019, 7.6),
    ("Jojo Rabbit", "A young boy in Hitler's army discovers his mother is hiding a Jewish girl.", "Comedy,Drama,War", "USA", 2019, 7.9),
    ("1917", "Two British soldiers race against time to deliver a crucial message.", "Drama,War", "UK", 2019, 8.3),
    ("Tenet", "A secret agent manipulates the flow of time to prevent World War III.", "Action,Sci-Fi,Thriller", "USA", 2020, 7.3),
    ("The Trial of the Chicago 7", "The story of seven people charged with conspiracy during the 1968 Democratic Convention.", "Drama,History,Thriller", "USA", 2020, 7.8),
    ("Judas and the Black Messiah", "The story of Fred Hampton and the FBI informant who betrayed him.", "Biography,Drama,History", "USA", 2021, 7.5),
    ("The Northman", "A Viking prince sets out to avenge his father's murder.", "Action,Adventure,Drama", "USA", 2022, 7.1),
    ("Nope", "Residents of a lonely gulch witness an uncanny and chilling discovery.", "Horror,Mystery,Sci-Fi", "USA", 2022, 6.8),
    ("Glass Onion", "Detective Blanc investigates a murder mystery on a tech billionaire's private island.", "Comedy,Crime,Drama", "USA", 2022, 7.1),
    ("Tar", "A renowned conductor faces a series of career-threatening revelations.", "Drama,Music", "USA", 2022, 7.4),
    ("The Banshees of Inisherin", "Two lifelong friends find themselves at an impasse when one abruptly ends their friendship.", "Comedy,Drama", "Ireland", 2022, 7.7),
    ("Elvis", "The life and music of Elvis Presley.", "Biography,Drama,Music", "USA", 2022, 7.3),
    ("The Fabelmans", "A young man discovers a shattering family secret and explores how movies can help us see the truth.", "Drama", "USA", 2022, 7.5),
    ("All Quiet on the Western Front", "A young German soldier faces the terrors of World War I.", "Action,Drama,War", "Germany", 2022, 7.8),
    ("Triangle of Sadness", "A celebrity couple are invited on a luxury cruise.", "Comedy,Drama", "Sweden", 2022, 7.3),
    ("Women Talking", "Women in an isolated religious colony struggle to reconcile with their faith.", "Drama", "USA", 2022, 6.8),
    ("Aftersun", "A young woman reflects on a holiday she took with her father.", "Drama", "UK", 2022, 7.7),
    ("The Whale", "A reclusive English teacher attempts to reconnect with his estranged daughter.", "Drama", "USA", 2022, 7.7),
    ("Maestro", "The complex love story between Leonard Bernstein and Felicia Montealegre.", "Biography,Drama,Music", "USA", 2023, 6.5),
    ("American Fiction", "A frustrated novelist writes a satirical book that becomes a bestseller.", "Comedy,Drama", "USA", 2023, 7.5),
    ("May December", "An actress researches a woman who had a notorious affair.", "Comedy,Drama", "USA", 2023, 6.9),
    ("Saltburn", "A student becomes obsessed with his charming aristocratic classmate.", "Comedy,Drama,Thriller", "UK", 2023, 7.0),
    ("The Iron Claw", "The true story of the Von Erich wrestling family.", "Biography,Drama,Sport", "USA", 2023, 7.6),
]

for m in na_extra:
    p = random.choice(platforms)
    movies.append({"title": m[0], "description": m[1], "genre": m[2], "country": m[3], "region": "north_american", "releaseYear": m[4], "rating": m[5], "platformName": p, "platformUrl": platform_urls[p], "trailerUrl": "https://www.youtube.com/embed/dQw4w9WgXcQ", "isFeatured": random.random() < 0.1, "isTrending": random.random() < 0.15})

# ============================================================
# ASIAN MOVIES (100+)
# ============================================================
asian_movies = [
    ("Oldboy", "After being kidnapped and imprisoned for fifteen years, a man is released and seeks revenge.", "Action,Drama,Mystery", "South Korea", 2003, 8.4, True, True),
    ("Your Name", "Two teenagers share a profound connection after discovering they are swapping bodies.", "Animation,Drama,Fantasy", "Japan", 2016, 8.4, True, True),
    ("Crouching Tiger, Hidden Dragon", "Two warriors pursue a stolen sword and a fugitive.", "Action,Adventure,Fantasy", "China", 2000, 7.9, True, False),
    ("Rashomon", "The murder of a samurai is told from four different perspectives.", "Crime,Drama,Mystery", "Japan", 1950, 8.2, False, False),
    ("Seven Samurai", "A village hires seven samurai to protect them from bandits.", "Action,Drama", "Japan", 1954, 8.6, True, False),
    ("Memories of Murder", "Two detectives investigate a series of murders in a small Korean province.", "Crime,Drama,Mystery", "South Korea", 2003, 8.1, True, True),
    ("The Farewell", "A Chinese family discovers their grandmother has only a short while left to live.", "Comedy,Drama", "China", 2019, 7.5, True, False),
    ("Lagaan", "Villagers in colonial India challenge their British rulers to a game of cricket.", "Drama,Musical,Sport", "India", 2001, 8.1, True, True),
    ("3 Idiots", "Two friends search for their long-lost college companion.", "Comedy,Drama", "India", 2009, 8.4, True, True),
    ("Dangal", "A former wrestler trains his daughters to become world-class wrestlers.", "Action,Biography,Drama", "India", 2016, 8.3, True, True),
    ("RRR", "Two legendary revolutionaries fight against British colonial rule.", "Action,Drama", "India", 2022, 7.8, True, True),
    ("Baahubali: The Beginning", "An adventurous young man discovers his royal heritage.", "Action,Drama", "India", 2015, 8.0, True, True),
    ("Dil Chahta Hai", "Three inseparable childhood friends deal with love and heartbreak.", "Comedy,Drama,Romance", "India", 2001, 8.1, False, False),
    ("Gangs of Wasseypur", "A clash between Sultan and Shahid Khan leads to a decades-long blood feud.", "Action,Crime,Drama", "India", 2012, 8.2, True, True),
    ("The Lunchbox", "A mistaken delivery leads to a correspondence between two strangers.", "Drama,Romance", "India", 2013, 7.8, False, False),
    ("Tumbbad", "A mythological story about a goddess who created the entire universe.", "Drama,Fantasy,Horror", "India", 2018, 8.2, True, True),
    ("Gully Boy", "A boy from the Mumbai slums rises to become a rap star.", "Drama,Music,Romance", "India", 2019, 7.9, True, False),
    ("Andhadhun", "A series of mysterious events change the life of a blind pianist.", "Crime,Mystery,Thriller", "India", 2018, 8.3, True, True),
    ("Article 15", "A police officer investigates the disappearance of three girls.", "Crime,Drama,Thriller", "India", 2019, 7.8, False, False),
    ("Rang De Basanti", "Six young Indians agree to act in a documentary about freedom fighters.", "Comedy,Crime,Drama", "India", 2006, 8.1, False, True),
    ("Taare Zameen Par", "A dyslexic boy is sent to a boarding school where a teacher helps him discover his talent.", "Drama,Family", "India", 2007, 8.4, True, False),
    ("PK", "An alien on Earth questions religious dogmas and superstitions.", "Comedy,Drama,Sci-Fi", "India", 2014, 8.1, True, False),
    ("Barfi!", "Three young people learn that love can neither be defined nor be confined.", "Comedy,Drama,Romance", "India", 2012, 8.1, False, False),
    ("Masaan", "Four people in the holy city of Varanasi search for love and meaning.", "Drama,Romance", "India", 2015, 8.1, False, False),
    ("Pather Panchali", "A classic tale of a poor Bengali family and their son Apu.", "Drama", "India", 1955, 8.3, False, False),
    ("Departures", "A cellist takes a job preparing the dead for funerals.", "Drama", "Japan", 2008, 8.1, False, False),
    ("Tokyo Story", "An elderly couple visit their children in Tokyo.", "Drama", "Japan", 1953, 8.2, False, False),
    ("Princess Mononoke", "A prince becomes involved in a struggle between forest gods and a mining colony.", "Animation,Adventure,Fantasy", "Japan", 1997, 8.4, True, True),
    ("My Neighbor Totoro", "Two sisters move to the countryside and encounter magical forest spirits.", "Animation,Family,Fantasy", "Japan", 1988, 8.2, True, False),
    ("Howl's Moving Castle", "A young woman cursed with old age encounters a wizard and his moving castle.", "Animation,Adventure,Family", "Japan", 2004, 8.2, True, False),
    ("Battle Royale", "A class of students is forced to fight to the death on a remote island.", "Action,Drama,Thriller", "Japan", 2000, 7.6, False, True),
    ("Ip Man", "The story of Ip Man, the legendary Wing Chun grandmaster.", "Action,Biography,Drama", "Hong Kong", 2008, 8.0, True, True),
    ("Infernal Affairs", "A cop and a gangster try to expose each other's identity.", "Crime,Drama,Mystery", "Hong Kong", 2002, 8.0, False, True),
    ("Hero", "A nameless warrior tells the King of Qin how he defeated three assassins.", "Action,Adventure,Fantasy", "China", 2002, 7.9, False, False),
    ("Raise the Red Lantern", "A young woman becomes the fourth wife of a wealthy lord.", "Drama", "China", 1991, 8.1, False, False),
    ("A Taxi Driver", "A taxi driver unknowingly becomes involved in the Gwangju Uprising.", "Action,Drama,History", "South Korea", 2017, 7.9, True, False),
    ("Train to Busan", "Passengers on a train must fight their way through a zombie apocalypse.", "Action,Horror,Thriller", "South Korea", 2016, 7.6, True, True),
    ("The Wailing", "A policeman investigates mysterious events in a small village.", "Drama,Fantasy,Horror", "South Korea", 2016, 7.4, False, True),
    ("Burning", "A young man becomes suspicious of a mysterious acquaintance.", "Drama,Mystery", "South Korea", 2018, 7.5, False, False),
    ("Decision to Leave", "A detective investigating a man's death falls for the dead man's wife.", "Crime,Drama,Mystery", "South Korea", 2022, 7.3, True, False),
    ("Broker", "A group of people form an unlikely family around an abandoned baby.", "Comedy,Crime,Drama", "South Korea", 2022, 7.3, False, False),
    ("Uncle Boonmee Who Can Recall His Past Lives", "A man's dying days are visited by his deceased wife and son.", "Drama,Fantasy", "Thailand", 2010, 6.5, False, False),
    ("Ong-Bak", "A young fighter heads to Bangkok to retrieve a stolen Buddha head.", "Action,Crime", "Thailand", 2003, 7.1, False, True),
    ("The Raid", "A SWAT team becomes trapped in a tenement run by a drug lord.", "Action,Thriller", "Indonesia", 2011, 7.6, True, True),
    ("The Act of Killing", "Former Indonesian death squad leaders reenact their real-life mass killings.", "Documentary,History", "Indonesia", 2012, 8.2, False, False),
    ("Heneral Luna", "The story of Filipino General Antonio Luna during the Philippine-American War.", "Action,Biography,Drama", "Philippines", 2015, 7.6, False, False),
]

for m in asian_movies:
    p = random.choice(platforms)
    movies.append({"title": m[0], "description": m[1], "genre": m[2], "country": m[3], "region": "asian", "releaseYear": m[4], "rating": m[5], "platformName": m[6] if len(m) > 8 else p, "platformUrl": m[7] if len(m) > 8 else platform_urls[p], "trailerUrl": "https://www.youtube.com/embed/dQw4w9WgXcQ", "isFeatured": m[6] if isinstance(m[6], bool) else random.random() < 0.15, "isTrending": m[7] if isinstance(m[7], bool) else random.random() < 0.15})

# ============================================================
# SOUTH AMERICAN MOVIES (60+)
# ============================================================
sa_movies = [
    ("City of God", "In the slums of Rio, two boys grow up taking different paths.", "Crime,Drama", "Brazil", 2002, 8.6, True, True),
    ("The Motorcycle Diaries", "Young Che Guevara's transformative journey across South America.", "Adventure,Biography,Drama", "Argentina", 2004, 7.8, True, False),
    ("Elite Squad", "A police captain in Rio de Janeiro fights corruption and drug trafficking.", "Action,Crime,Drama", "Brazil", 2007, 8.0, True, True),
    ("Wild Tales", "Six short stories of violence and revenge.", "Comedy,Drama,Thriller", "Argentina", 2014, 8.1, True, True),
    ("Central Station", "A retired schoolteacher helps a young boy find his father.", "Drama", "Brazil", 2008, 8.0, False, False),
    ("The Secret in Their Eyes", "A retired legal counselor writes a novel about an unsolved case.", "Drama,Mystery,Thriller", "Argentina", 2009, 8.2, True, False),
    ("Carandiru", "A doctor volunteers at Brazil's most notorious prison.", "Crime,Drama", "Brazil", 2003, 7.6, False, False),
    ("No", "An ad executive leads a campaign to defeat Pinochet in a national plebiscite.", "Drama,History", "Chile", 2012, 7.3, False, False),
    ("Gloria", "A free-spirited older woman seeks love and connection in Santiago.", "Comedy,Drama,Romance", "Chile", 2013, 7.1, False, False),
    ("A Fantastic Woman", "A transgender woman faces discrimination after her partner's death.", "Drama", "Chile", 2017, 7.2, True, False),
    ("Roma", "A domestic worker's life in 1970s Mexico City.", "Drama", "Mexico", 2018, 7.7, True, True),
    ("Y Tu Mamá También", "Two teenage boys and an older woman take a road trip through Mexico.", "Drama,Romance", "Mexico", 2001, 7.6, False, True),
    ("Amores Perros", "Three stories connected by a car accident in Mexico City.", "Drama,Thriller", "Mexico", 2000, 8.1, True, False),
    ("Pan's Labyrinth", "A young girl enters a mythical world during the Spanish Civil War.", "Drama,Fantasy,War", "Mexico", 2006, 8.2, True, True),
    ("Birdman of Alcatraz", "A convict becomes a renowned ornithologist.", "Biography,Drama", "Argentina", 1962, 7.9, False, False),
    ("The Clan", "The true story of a family that kidnapped and killed people in 1980s Argentina.", "Crime,Drama,Thriller", "Argentina", 2015, 7.1, False, True),
    ("Aquarius", "A retired music critic refuses to sell her apartment to a construction company.", "Drama", "Brazil", 2016, 7.4, False, False),
    ("Bacurau", "A small town in Brazil discovers it has been removed from most maps.", "Action,Adventure,Mystery", "Brazil", 2019, 7.3, True, True),
    ("The Invisible Guest", "A successful businessman prepares his defense for a murder charge.", "Crime,Mystery,Thriller", "Colombia", 2016, 8.1, False, True),
    ("Birds of Passage", "An indigenous family gets involved in the marijuana trade.", "Crime,Drama", "Colombia", 2018, 7.5, False, False),
    ("Embrace of the Serpent", "An Amazonian shaman guides two scientists through the jungle.", "Adventure,Drama", "Colombia", 2015, 7.9, True, False),
    ("Monos", "A group of teenage soldiers guard an American hostage in the mountains.", "Drama,Thriller,War", "Colombia", 2019, 6.9, True, False),
    ("The Milk of Sorrow", "A woman suffers from a disease transmitted through breast milk during Peru's civil war.", "Drama", "Peru", 2009, 6.5, False, False),
    ("Claudia", "A Peruvian woman navigates love and identity in Lima.", "Drama,Romance", "Peru", 2019, 6.3, False, False),
    ("The Liberator", "The story of Simón Bolívar's fight for South American independence.", "Action,Biography,Drama", "Venezuela", 2013, 5.8, False, False),
    ("Pelo Malo", "A boy with curly hair struggles with identity in Caracas.", "Drama", "Venezuela", 2013, 6.8, False, False),
]

for m in sa_movies:
    p = random.choice(platforms)
    movies.append({"title": m[0], "description": m[1], "genre": m[2], "country": m[3], "region": "south_american", "releaseYear": m[4], "rating": m[5], "platformName": p, "platformUrl": platform_urls[p], "trailerUrl": "https://www.youtube.com/embed/dQw4w9WgXcQ", "isFeatured": m[6], "isTrending": m[7]})

# ============================================================
# MIDDLE EASTERN MOVIES (50+)
# ============================================================
me_movies = [
    ("A Separation", "A married couple faces a difficult decision.", "Drama", "Iran", 2011, 8.3, True, True),
    ("The Salesman", "A couple's relationship is affected after a violent incident.", "Drama,Thriller", "Iran", 2016, 7.7, True, False),
    ("Children of Heaven", "A brother and sister share a pair of shoes.", "Drama,Family", "Iran", 2007, 8.2, True, False),
    ("Taste of Cherry", "A middle-aged man drives around Tehran searching for someone to bury him.", "Drama", "Iran", 1997, 7.6, False, False),
    ("Close-Up", "A man impersonates a famous filmmaker.", "Biography,Crime,Drama", "Iran", 1990, 8.1, False, False),
    ("About Elly", "A group of friends' beach trip turns tragic.", "Drama,Mystery", "Iran", 2009, 7.9, False, True),
    ("The Past", "A man returns to Paris to finalize his divorce.", "Drama,Mystery", "Iran", 2013, 7.8, False, False),
    ("A Hero", "A prisoner tries to arrange his release by repaying a debt.", "Drama", "Iran", 2021, 7.4, True, True),
    ("Capernaum", "A boy sues his parents for giving him life.", "Drama", "Lebanon", 2018, 8.4, True, True),
    ("The Insult", "A minor incident between two men escalates into a national crisis.", "Drama", "Lebanon", 2017, 7.6, False, False),
    ("Where Do We Go Now?", "Women in a Lebanese village try to keep their men from fighting.", "Comedy,Drama", "Lebanon", 2011, 7.2, False, False),
    ("West Beirut", "Two teenagers navigate life during the Lebanese Civil War.", "Comedy,Drama,War", "Lebanon", 2008, 7.5, False, False),
    ("Omar", "A Palestinian baker is recruited as an informant after being caught climbing the separation wall.", "Drama,Thriller", "Palestine", 2013, 7.4, False, False),
    ("Paradise Now", "Two Palestinian friends are recruited for a suicide bombing in Tel Aviv.", "Crime,Drama,Thriller", "Palestine", 2005, 7.5, True, False),
    ("The Band's Visit", "An Egyptian police band is stranded in a small Israeli town.", "Comedy,Drama,Music", "Israel", 2007, 7.6, False, False),
    ("Waltz with Bashir", "An animated documentary about the 1982 Lebanon War.", "Animation,Biography,Drama", "Israel", 2008, 8.0, True, False),
    ("Foxtrot", "A family deals with the aftermath of their son's military service.", "Drama,War", "Israel", 2017, 7.4, False, False),
    ("Wadjda", "A Saudi girl enters a Quran recitation competition to buy a bicycle.", "Comedy,Drama,Family", "Saudi Arabia", 2012, 7.5, True, True),
    ("The Perfect Candidate", "A Saudi female doctor runs for municipal council.", "Comedy,Drama", "Saudi Arabia", 2019, 6.4, False, False),
    ("Theeb", "A Bedouin boy guides a British officer through the desert during WWI.", "Adventure,Drama,Thriller", "Jordan", 2014, 7.2, False, False),
    ("Captain Abu Raed", "A janitor pretends to be an airline pilot to inspire neighborhood children.", "Drama", "Jordan", 2007, 7.3, False, False),
    ("The Kite Runner", "A man returns to Afghanistan to rescue the son of his childhood friend.", "Drama", "Afghanistan", 2007, 7.6, True, False),
    ("Osama", "A girl disguises herself as a boy to work under the Taliban regime.", "Drama", "Afghanistan", 2003, 7.3, False, False),
    ("Mustang", "Five orphaned sisters in rural Turkey struggle against oppressive traditions.", "Drama", "Turkey", 2015, 7.6, True, True),
    ("Once Upon a Time in Anatolia", "A group searches for a buried body in the Turkish countryside.", "Crime,Drama", "Turkey", 2011, 7.8, False, False),
    ("Winter Sleep", "A retired actor runs a hotel in central Anatolia.", "Drama", "Turkey", 2014, 8.0, False, False),
    ("The White Balloon", "A young girl tries to buy a goldfish for the New Year.", "Drama,Family", "Iran", 1995, 7.6, False, False),
    ("Persepolis", "A precocious Iranian girl grows up during the Islamic Revolution.", "Animation,Biography,Drama", "Iran", 2007, 8.0, True, False),
    ("Under the Shadow", "A mother and daughter face a mysterious evil in 1980s Tehran.", "Drama,Horror,Thriller", "Iran", 2016, 6.9, False, True),
    ("Holy Spider", "A journalist investigates a serial killer targeting sex workers in Iran.", "Crime,Drama,Thriller", "Iran", 2022, 7.1, True, True),
]

for m in me_movies:
    p = random.choice(platforms)
    movies.append({"title": m[0], "description": m[1], "genre": m[2], "country": m[3], "region": "middle_eastern", "releaseYear": m[4], "rating": m[5], "platformName": p, "platformUrl": platform_urls[p], "trailerUrl": "https://www.youtube.com/embed/dQw4w9WgXcQ", "isFeatured": m[6], "isTrending": m[7]})

# ============================================================
# OCEANIAN MOVIES (30+)
# ============================================================
oc_movies = [
    ("Mad Max: Fury Road", "In a post-apocalyptic wasteland, a woman rebels against a tyrannical ruler.", "Action,Adventure,Sci-Fi", "Australia", 2015, 8.1, True, True),
    ("The Piano", "A mute woman and her daughter travel to New Zealand for an arranged marriage.", "Drama,Music,Romance", "New Zealand", 1993, 7.5, True, False),
    ("Whale Rider", "A Maori girl fights to fulfill a destiny her grandfather refuses to recognize.", "Drama,Family", "New Zealand", 2002, 7.5, True, False),
    ("Once Were Warriors", "A Maori family deals with poverty and domestic violence.", "Crime,Drama", "New Zealand", 2004, 7.9, True, True),
    ("Hunt for the Wilderpeople", "A boy and his foster uncle go on the run in the New Zealand bush.", "Adventure,Comedy,Drama", "New Zealand", 2016, 7.9, True, True),
    ("The Babadook", "A single mother is terrorized by a monster from her son's storybook.", "Drama,Horror", "Australia", 2014, 6.8, False, True),
    ("Animal Kingdom", "A teenager navigates his criminal family in Melbourne.", "Crime,Drama,Thriller", "Australia", 2010, 7.3, False, False),
    ("Lion", "A five-year-old Indian boy is adopted by an Australian couple.", "Biography,Drama", "Australia", 2016, 8.0, True, True),
    ("Rabbit-Proof Fence", "Three Aboriginal girls escape from a settlement camp and walk home.", "Adventure,Drama,History", "Australia", 2002, 7.4, False, False),
    ("Priscilla, Queen of the Desert", "Two drag queens and a transgender woman travel across Australia.", "Comedy,Drama,Music", "Australia", 1994, 7.5, False, False),
    ("Picnic at Hanging Rock", "A group of schoolgirls vanish during a Valentine's Day picnic.", "Drama,Mystery", "Australia", 1975, 7.5, False, False),
    ("Gallipoli", "Two Australian sprinters face the horrors of war at Gallipoli.", "Adventure,Drama,War", "Australia", 2005, 7.4, False, False),
    ("Strictly Ballroom", "A maverick ballroom dancer partners with an ugly duckling.", "Comedy,Drama,Music", "Australia", 1992, 7.2, False, False),
    ("Samson and Delilah", "Two Aboriginal teenagers escape their troubled community.", "Drama,Romance", "Australia", 2009, 7.3, False, False),
    ("Boy", "A boy's imagination runs wild when his father returns home.", "Comedy,Drama", "New Zealand", 2010, 7.5, False, False),
    ("What We Do in the Shadows", "Vampire housemates deal with the challenges of modern life.", "Comedy,Horror", "New Zealand", 2014, 7.7, True, True),
    ("Jojo Rabbit", "A young boy in Hitler's army discovers his mother is hiding a Jewish girl.", "Comedy,Drama,War", "New Zealand", 2019, 7.9, True, False),
    ("The Power of the Dog", "A domineering rancher responds with cruelty when his brother brings home a new wife.", "Drama,Romance,Western", "New Zealand", 2021, 6.8, True, False),
    ("Crocodile Dundee", "An American reporter meets a rugged Australian crocodile hunter.", "Adventure,Comedy", "Australia", 1986, 6.5, False, False),
    ("Muriel's Wedding", "A socially awkward woman dreams of having a glamorous wedding.", "Comedy,Drama", "Australia", 1994, 7.1, False, False),
    ("Shine", "The story of pianist David Helfgott's troubled life.", "Biography,Drama,Music", "Australia", 1996, 7.7, False, False),
    ("The Dressmaker", "A glamorous woman returns to her small hometown to seek revenge.", "Comedy,Drama", "Australia", 2015, 6.7, False, False),
    ("Cargo", "A father must protect his infant daughter in a post-apocalyptic Australia.", "Drama,Horror,Sci-Fi", "Australia", 2017, 6.3, False, False),
    ("Breath", "Two teenage surfers befriend an older surfer in 1970s Western Australia.", "Drama,Sport", "Australia", 2017, 6.3, False, False),
    ("Top of the Lake", "A detective investigates a pregnant 12-year-old's disappearance.", "Crime,Drama,Mystery", "New Zealand", 2013, 7.5, False, False),
]

for m in oc_movies:
    p = random.choice(platforms)
    movies.append({"title": m[0], "description": m[1], "genre": m[2], "country": m[3], "region": "oceanian", "releaseYear": m[4], "rating": m[5], "platformName": p, "platformUrl": platform_urls[p], "trailerUrl": "https://www.youtube.com/embed/dQw4w9WgXcQ", "isFeatured": m[6], "isTrending": m[7]})

# ============================================================
# Generate SQL
# ============================================================
print(f"-- Total movies: {len(movies)}")

def escape(s):
    if s is None:
        return "NULL"
    return "'" + str(s).replace("\\", "\\\\").replace("'", "\\'") + "'"

# Write SQL in batches of 50
batch_size = 50
for batch_start in range(0, len(movies), batch_size):
    batch = movies[batch_start:batch_start + batch_size]
    values = []
    for i, m in enumerate(batch):
        pop = random.randint(10, 100)
        vals = f"({escape(m['title'])}, {escape(m['description'])}, {escape(m.get('posterUrl'))}, {escape(m.get('backdropUrl'))}, {escape(m['trailerUrl'])}, {escape(m['genre'])}, {escape(m['country'])}, {escape(m['region'])}, {m['releaseYear']}, {m['rating']}, {pop}, {escape(m['platformName'])}, {escape(m['platformUrl'])}, {'1' if m['isFeatured'] else '0'}, {'1' if m['isTrending'] else '0'})"
        values.append(vals)
    
    cols = "(`title`, `description`, `posterUrl`, `backdropUrl`, `trailerUrl`, `genre`, `country`, `region`, `releaseYear`, `rating`, `popularity`, `platformName`, `platformUrl`, `isFeatured`, `isTrending`)"
    sql = f"INSERT INTO `movies` {cols} VALUES\n" + ",\n".join(values) + ";"
    print(sql)
    print()

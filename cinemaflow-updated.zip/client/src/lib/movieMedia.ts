const PLACEHOLDER_TRAILER_IDS = new Set([
  'dQw4w9WgXcQ',
]);

function encodeSvg(svg: string) {
  return `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(svg)}`;
}

function sanitize(value?: string | number | null) {
  return String(value ?? '').replace(/[&<>"']/g, (char) => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;',
  }[char] || char));
}

export function getYouTubeVideoId(url?: string | null): string | null {
  if (!url) return null;

  const patterns = [
    /youtube\.com\/embed\/([A-Za-z0-9_-]{6,})/i,
    /youtube\.com\/watch\?v=([A-Za-z0-9_-]{6,})/i,
    /youtu\.be\/([A-Za-z0-9_-]{6,})/i,
  ];

  for (const pattern of patterns) {
    const match = url.match(pattern);
    if (match?.[1]) return match[1];
  }

  return null;
}

export function normalizeTrailerUrl(url?: string | null): string | null {
  const id = getYouTubeVideoId(url);
  if (!id) return null;
  if (PLACEHOLDER_TRAILER_IDS.has(id)) return null;
  return `https://www.youtube.com/embed/${id}`;
}

export function getTrailerSearchUrl(title: string, releaseYear?: number | null) {
  const query = [title, releaseYear, 'official trailer'].filter(Boolean).join(' ');
  return `https://www.youtube.com/results?search_query=${encodeURIComponent(query)}`;
}

export function getPosterFallbackUrl(movie: {
  title: string;
  genre?: string | null;
  country?: string | null;
  releaseYear?: number | null;
}) {
  const primaryGenre = movie.genre?.split(',')[0]?.trim() || 'Cinema';
  const svg = `
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 1200">
    <defs>
      <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stop-color="#7f1d1d"/>
        <stop offset="45%" stop-color="#581c87"/>
        <stop offset="100%" stop-color="#111827"/>
      </linearGradient>
      <linearGradient id="shine" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stop-color="rgba(255,255,255,0.28)"/>
        <stop offset="100%" stop-color="rgba(255,255,255,0)"/>
      </linearGradient>
    </defs>
    <rect width="800" height="1200" fill="url(#bg)" rx="36"/>
    <circle cx="640" cy="180" r="220" fill="rgba(255,255,255,0.08)"/>
    <circle cx="180" cy="1020" r="260" fill="rgba(239,68,68,0.14)"/>
    <rect x="42" y="42" width="716" height="1116" rx="28" fill="none" stroke="rgba(255,255,255,0.16)"/>
    <rect x="80" y="88" width="640" height="910" rx="28" fill="rgba(0,0,0,0.16)"/>
    <path d="M80 88h440l200 220v690H80z" fill="url(#shine)" opacity="0.22"/>
    <text x="400" y="220" text-anchor="middle" fill="rgba(255,255,255,0.9)" font-size="34" font-family="Arial, Helvetica, sans-serif" letter-spacing="6">CINEMAFLOW</text>
    <foreignObject x="110" y="300" width="580" height="360">
      <div xmlns="http://www.w3.org/1999/xhtml" style="font-family:Arial,Helvetica,sans-serif;color:white;font-size:64px;font-weight:800;line-height:1.08;text-align:center;display:flex;align-items:center;justify-content:center;height:100%;padding:0 10px;">
        ${sanitize(movie.title)}
      </div>
    </foreignObject>
    <rect x="180" y="700" width="440" height="64" rx="32" fill="rgba(255,255,255,0.12)"/>
    <text x="400" y="742" text-anchor="middle" fill="#fbbf24" font-size="28" font-family="Arial, Helvetica, sans-serif" font-weight="700">${sanitize(primaryGenre.toUpperCase())}</text>
    <text x="400" y="860" text-anchor="middle" fill="rgba(255,255,255,0.82)" font-size="34" font-family="Arial, Helvetica, sans-serif">${sanitize(movie.country || 'Global Cinema')}</text>
    <text x="400" y="920" text-anchor="middle" fill="rgba(255,255,255,0.62)" font-size="28" font-family="Arial, Helvetica, sans-serif">${sanitize(movie.releaseYear || 'Now Showing')}</text>
    <text x="400" y="1080" text-anchor="middle" fill="rgba(255,255,255,0.4)" font-size="26" font-family="Arial, Helvetica, sans-serif" letter-spacing="3">DISCOVER WORLD CINEMA</text>
  </svg>`;

  return encodeSvg(svg);
}

export function getBackdropFallbackUrl(movie: {
  title: string;
  genre?: string | null;
  country?: string | null;
  releaseYear?: number | null;
}) {
  const primaryGenre = movie.genre?.split(',')[0]?.trim() || 'Cinema';
  const svg = `
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1600 900">
    <defs>
      <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stop-color="#111827"/>
        <stop offset="45%" stop-color="#7f1d1d"/>
        <stop offset="100%" stop-color="#312e81"/>
      </linearGradient>
    </defs>
    <rect width="1600" height="900" fill="url(#bg)"/>
    <circle cx="1300" cy="180" r="240" fill="rgba(255,255,255,0.08)"/>
    <circle cx="260" cy="780" r="260" fill="rgba(239,68,68,0.12)"/>
    <rect x="84" y="84" width="1432" height="732" rx="36" fill="rgba(0,0,0,0.22)" stroke="rgba(255,255,255,0.12)"/>
    <text x="120" y="170" fill="rgba(255,255,255,0.75)" font-size="32" font-family="Arial, Helvetica, sans-serif" letter-spacing="6">FEATURED MOVIE</text>
    <foreignObject x="120" y="220" width="820" height="250">
      <div xmlns="http://www.w3.org/1999/xhtml" style="font-family:Arial,Helvetica,sans-serif;color:white;font-size:82px;font-weight:800;line-height:1.05;display:flex;align-items:center;height:100%;">
        ${sanitize(movie.title)}
      </div>
    </foreignObject>
    <text x="120" y="560" fill="#fbbf24" font-size="34" font-family="Arial, Helvetica, sans-serif" font-weight="700">${sanitize(primaryGenre.toUpperCase())}</text>
    <text x="120" y="620" fill="rgba(255,255,255,0.8)" font-size="34" font-family="Arial, Helvetica, sans-serif">${sanitize(movie.country || 'Global Cinema')} • ${sanitize(movie.releaseYear || 'Now Showing')}</text>
    <text x="120" y="720" fill="rgba(255,255,255,0.5)" font-size="30" font-family="Arial, Helvetica, sans-serif">Handpicked films from around the world</text>
  </svg>`;

  return encodeSvg(svg);
}

export function getPosterSrc(movie: {
  title: string;
  posterUrl?: string | null;
  genre?: string | null;
  country?: string | null;
  releaseYear?: number | null;
}) {
  return movie.posterUrl || getPosterFallbackUrl(movie);
}

export function getBackdropSrc(movie: {
  title: string;
  backdropUrl?: string | null;
  genre?: string | null;
  country?: string | null;
  releaseYear?: number | null;
}) {
  return movie.backdropUrl || getBackdropFallbackUrl(movie);
}

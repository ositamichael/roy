import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import MovieCard from "@/components/MovieCard";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { User, Heart, Crown, Film, ArrowRight, Loader2, LogOut } from "lucide-react";
import { useEffect } from "react";

export default function Dashboard() {
  const { user, isAuthenticated, loading, logout } = useAuth();

  const { data: watchlist, isLoading: watchlistLoading } = trpc.watchlist.list.useQuery(
    undefined,
    { enabled: isAuthenticated }
  );

  useEffect(() => {
    if (!loading && !isAuthenticated) {
      window.location.href = getLoginUrl();
    }
  }, [loading, isAuthenticated]);

  if (loading) {
    return (
      <div className="min-h-screen bg-background text-foreground">
        <Navbar />
        <div className="pt-20 flex items-center justify-center min-h-[60vh]">
          <Loader2 className="w-8 h-8 animate-spin text-cinema-red" />
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null;
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Navbar />

      <div className="pt-20 pb-16">
        <div className="container">
          {/* Profile Header */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-10"
          >
            <div className="flex flex-col sm:flex-row items-start sm:items-center gap-6 p-6 rounded-2xl bg-card border border-border/50">
              <div className="w-16 h-16 rounded-full bg-cinema-red/20 flex items-center justify-center">
                <User className="w-8 h-8 text-cinema-red" />
              </div>
              <div className="flex-1">
                <h1 className="text-2xl font-bold">{user?.name || "Movie Enthusiast"}</h1>
                <p className="text-muted-foreground text-sm">{user?.email || "Welcome to CinemaFlow"}</p>
                <div className="flex items-center gap-2 mt-2">
                  <span className="px-2 py-0.5 rounded-full bg-cinema-red/20 text-cinema-red text-xs font-medium">
                    Member
                  </span>
                </div>
              </div>
              <div className="flex gap-3">
                <Link href="/membership">
                  <Button variant="outline" size="sm" className="gap-2 border-border/50">
                    <Crown className="w-4 h-4" />
                    Upgrade Plan
                  </Button>
                </Link>
                <Button
                  variant="ghost"
                  size="sm"
                  className="gap-2 text-muted-foreground hover:text-destructive"
                  onClick={() => logout()}
                >
                  <LogOut className="w-4 h-4" />
                  Sign Out
                </Button>
              </div>
            </div>
          </motion.div>

          {/* Quick Stats */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-10"
          >
            {[
              { icon: Heart, label: "Watchlist", value: watchlist?.length || 0, color: "text-pink-400" },
              { icon: Film, label: "Movies Explored", value: "660+", color: "text-cinema-red" },
              { icon: Crown, label: "Plan", value: "Free", color: "text-cinema-gold" },
            ].map((stat) => (
              <div key={stat.label} className="p-4 rounded-xl bg-card border border-border/50 text-center">
                <stat.icon className={`w-6 h-6 ${stat.color} mx-auto mb-2`} />
                <div className="text-xl font-bold">{stat.value}</div>
                <div className="text-xs text-muted-foreground">{stat.label}</div>
              </div>
            ))}
          </motion.div>

          {/* Watchlist */}
          <motion.section
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold flex items-center gap-2">
                <Heart className="w-5 h-5 text-cinema-red" />
                My Watchlist
              </h2>
              <Link href="/movies">
                <Button variant="ghost" size="sm" className="gap-1 text-cinema-red">
                  Discover More <ArrowRight className="w-4 h-4" />
                </Button>
              </Link>
            </div>

            {watchlistLoading ? (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
                {Array.from({ length: 5 }).map((_, i) => (
                  <div key={i}>
                    <div className="aspect-[2/3] skeleton-shimmer rounded-lg" />
                    <div className="mt-2 h-4 w-3/4 skeleton-shimmer rounded" />
                  </div>
                ))}
              </div>
            ) : watchlist && watchlist.length > 0 ? (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
                {watchlist.map((item: any) => (
                  <MovieCard key={item.id} movie={item.movie} />
                ))}
              </div>
            ) : (
              <div className="text-center py-16 rounded-xl bg-card border border-border/50">
                <Film className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">Your watchlist is empty</h3>
                <p className="text-muted-foreground mb-4">Start exploring movies and add your favorites here.</p>
                <Link href="/movies">
                  <Button className="bg-cinema-red hover:bg-cinema-red/90 text-white">
                    Browse Movies
                  </Button>
                </Link>
              </div>
            )}
          </motion.section>

          {/* Quick Actions */}
          <motion.section
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="mt-10"
          >
            <h2 className="text-xl font-bold mb-6">Quick Actions</h2>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {[
                { href: "/movies", icon: Film, label: "Browse All Movies", desc: "Explore our full catalog" },
                { href: "/categories", icon: Heart, label: "Browse Categories", desc: "Find by genre or region" },
                { href: "/membership", icon: Crown, label: "Upgrade Plan", desc: "Unlock premium features" },
              ].map((action) => (
                <Link key={action.href} href={action.href}>
                  <div className="group p-4 rounded-xl bg-card border border-border/50 hover:border-cinema-red/30 transition-all cursor-pointer">
                    <action.icon className="w-6 h-6 text-cinema-red mb-2" />
                    <h3 className="font-semibold group-hover:text-cinema-red transition-colors">{action.label}</h3>
                    <p className="text-xs text-muted-foreground mt-1">{action.desc}</p>
                  </div>
                </Link>
              ))}
            </div>
          </motion.section>
        </div>
      </div>

      <Footer />
    </div>
  );
}

import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { motion } from "framer-motion";
import { Film, Globe, Heart, Users, Sparkles, Target } from "lucide-react";

export default function About() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <Navbar />

      <div className="pt-20 pb-16">
        {/* Hero */}
        <section className="relative py-20 overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-cinema-red/10 via-background to-background" />
          <div className="container relative z-10">
            <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} className="max-w-3xl">
              <div className="flex items-center gap-2 mb-4">
                <Film className="w-5 h-5 text-cinema-red" />
                <span className="text-sm font-medium text-cinema-red uppercase tracking-wider">Our Story</span>
              </div>
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black leading-tight">
                About <span className="text-cinema-red">CinemaFlow</span>
              </h1>
              <p className="mt-6 text-lg text-muted-foreground leading-relaxed">
                A platform born from the belief that great cinema knows no borders.
              </p>
            </motion.div>
          </div>
        </section>

        <div className="container space-y-16">
          {/* Founder Section */}
          <motion.section initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
              <div>
                <div className="w-full aspect-square max-w-md rounded-2xl bg-gradient-to-br from-cinema-red/20 to-purple-900/20 border border-border/50 flex items-center justify-center">
                  <div className="text-center p-8">
                    <div className="w-24 h-24 rounded-full bg-cinema-red/20 flex items-center justify-center mx-auto mb-4">
                      <Users className="w-12 h-12 text-cinema-red" />
                    </div>
                    <h3 className="text-2xl font-bold text-foreground">Osita Michael</h3>
                    <p className="text-cinema-red font-medium mt-1">Founder & CEO</p>
                  </div>
                </div>
              </div>
              <div className="space-y-6">
                <h2 className="text-3xl font-bold">Meet the Founder</h2>
                <div className="space-y-4 text-muted-foreground leading-relaxed">
                  <p>
                    <strong className="text-foreground">Osita Michael</strong> is the visionary founder behind CinemaFlow. Growing up with a deep love for storytelling and film, Osita noticed a fundamental gap in how people discover movies from different parts of the world. While Hollywood blockbusters dominated every platform, incredible films from Africa, Europe, Asia, and the Middle East remained hidden gems, unknown to audiences who would have loved them.
                  </p>
                  <p>
                    The idea for CinemaFlow was born on a quiet evening when Osita spent hours searching across multiple platforms just to find a single Nigerian film he had heard about from a friend. That frustrating experience sparked a question: <em className="text-cinema-red">"Why isn't there one place where people can easily discover movies from every corner of the world?"</em>
                  </p>
                  <p>
                    Driven by this vision, Osita set out to build CinemaFlow — not as another streaming service, but as a discovery platform that connects audiences with the films they never knew they were looking for. Every movie on CinemaFlow links directly to the official platform where it can be legally watched or purchased, ensuring that creators and rights holders are always supported.
                  </p>
                  <p>
                    Today, CinemaFlow features over 660 films from more than 50 countries, spanning 7 world regions and over 20 genres. What started as one person's frustration has become a mission to make global cinema accessible to everyone.
                  </p>
                </div>
              </div>
            </div>
          </motion.section>

          {/* Mission */}
          <motion.section initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
            <div className="text-center max-w-3xl mx-auto">
              <Target className="w-10 h-10 text-cinema-red mx-auto mb-4" />
              <h2 className="text-3xl font-bold mb-6">Our Mission</h2>
              <p className="text-lg text-muted-foreground leading-relaxed">
                To break down the barriers of movie discovery by creating a single, beautiful platform where anyone can explore films from every culture, language, and region — and find exactly where to watch them legally.
              </p>
            </div>
          </motion.section>

          {/* Values */}
          <motion.section initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
            <h2 className="text-2xl font-bold text-center mb-8">What We Stand For</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {[
                {
                  icon: Globe,
                  title: "Global Perspective",
                  desc: "We believe every culture has stories worth telling and audiences worth reaching. CinemaFlow celebrates diversity in cinema.",
                },
                {
                  icon: Heart,
                  title: "Supporting Creators",
                  desc: "Every 'Watch Now' button links to official platforms. We never host pirated content — we support the filmmakers and studios who bring these stories to life.",
                },
                {
                  icon: Sparkles,
                  title: "Accessible Discovery",
                  desc: "Finding great movies shouldn't be hard. We make it simple with smart search, curated collections, and personalized recommendations.",
                },
              ].map((item) => (
                <div key={item.title} className="p-6 rounded-xl bg-card border border-border/50 text-center">
                  <item.icon className="w-10 h-10 text-cinema-red mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-3">{item.title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{item.desc}</p>
                </div>
              ))}
            </div>
          </motion.section>

          {/* Stats */}
          <motion.section initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="py-12 rounded-2xl bg-gradient-to-r from-cinema-red/10 via-purple-500/10 to-cinema-red/10 border border-border/50">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
              {[
                { value: "660+", label: "Movies" },
                { value: "50+", label: "Countries" },
                { value: "7", label: "Regions" },
                { value: "20+", label: "Genres" },
              ].map((stat) => (
                <div key={stat.label}>
                  <div className="text-3xl sm:text-4xl font-bold text-cinema-red">{stat.value}</div>
                  <div className="text-sm text-muted-foreground mt-1">{stat.label}</div>
                </div>
              ))}
            </div>
          </motion.section>
        </div>
      </div>

      <Footer />
    </div>
  );
}

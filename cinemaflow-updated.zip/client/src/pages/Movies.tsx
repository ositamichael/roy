import { useState, useMemo, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import MovieCard from "@/components/MovieCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search, SlidersHorizontal, X, Loader2 } from "lucide-react";
import { useSearch } from "wouter";
import { ALL_REGIONS } from "@shared/movie-constants";

export default function Movies() {
  const searchString = useSearch();
  const params = useMemo(() => new URLSearchParams(searchString), [searchString]);

  const [search, setSearch] = useState(params.get("search") === "true" ? "" : (params.get("q") || ""));
  const [genre, setGenre] = useState(params.get("genre") || "");
  const [region, setRegion] = useState(params.get("region") || "");
  const [country, setCountry] = useState(params.get("country") || "");
  const [sortBy, setSortBy] = useState<"popularity" | "rating" | "releaseYear" | "title">(
    (params.get("sort") as any) || "popularity"
  );
  const [page, setPage] = useState(0);
  const [showFilters, setShowFilters] = useState(false);

  const isTrending = params.get("trending") === "true";
  const isFeatured = params.get("featured") === "true";

  const limit = 24;

  const queryInput = useMemo(() => ({
    search: search || undefined,
    genre: genre || undefined,
    region: region || undefined,
    country: country || undefined,
    isTrending: isTrending || undefined,
    isFeatured: isFeatured || undefined,
    sortBy,
    sortOrder: "desc" as const,
    limit,
    offset: page * limit,
  }), [search, genre, region, country, sortBy, page, isTrending, isFeatured]);

  const { data, isLoading } = trpc.movies.list.useQuery(queryInput);
  const { data: genres } = trpc.movies.genres.useQuery();
  const { data: countries } = trpc.movies.countries.useQuery();

  const totalPages = data ? Math.ceil(data.total / limit) : 0;

  const clearFilters = () => {
    setSearch("");
    setGenre("");
    setRegion("");
    setCountry("");
    setSortBy("popularity");
    setPage(0);
  };

  useEffect(() => {
    setPage(0);
  }, [search, genre, region, country, sortBy]);

  const title = isTrending ? "Trending Movies" : isFeatured ? "Featured Films" : region ? `${ALL_REGIONS.find(r => r.value === region)?.label || region} Cinema` : genre ? `${genre} Movies` : "All Movies";

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Navbar />
      <div className="pt-20 pb-16">
        <div className="container">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl sm:text-4xl font-bold">{title}</h1>
            {data && <p className="text-muted-foreground mt-2">{data.total} movies found</p>}
          </div>

          {/* Search & Filters */}
          <div className="mb-8 space-y-4">
            <div className="flex gap-3">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder="Search movies by title, genre, country..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="pl-10 bg-card border-border/50 h-11"
                />
                {search && (
                  <button onClick={() => setSearch("")} className="absolute right-3 top-1/2 -translate-y-1/2">
                    <X className="w-4 h-4 text-muted-foreground hover:text-foreground" />
                  </button>
                )}
              </div>
              <Button variant="outline" className="gap-2 border-border/50" onClick={() => setShowFilters(!showFilters)}>
                <SlidersHorizontal className="w-4 h-4" />
                <span className="hidden sm:inline">Filters</span>
              </Button>
            </div>

            {showFilters && (
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-4 rounded-xl bg-card border border-border/50">
                <Select value={genre} onValueChange={setGenre}>
                  <SelectTrigger className="bg-background border-border/50">
                    <SelectValue placeholder="Genre" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Genres</SelectItem>
                    {genres?.map((g) => (
                      <SelectItem key={g} value={g}>{g}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <Select value={region} onValueChange={setRegion}>
                  <SelectTrigger className="bg-background border-border/50">
                    <SelectValue placeholder="Region" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Regions</SelectItem>
                    {ALL_REGIONS.map((r) => (
                      <SelectItem key={r.value} value={r.value}>{r.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <Select value={country} onValueChange={setCountry}>
                  <SelectTrigger className="bg-background border-border/50">
                    <SelectValue placeholder="Country" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Countries</SelectItem>
                    {countries?.map((c) => (
                      <SelectItem key={c} value={c}>{c}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <Select value={sortBy} onValueChange={(v) => setSortBy(v as any)}>
                  <SelectTrigger className="bg-background border-border/50">
                    <SelectValue placeholder="Sort By" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="popularity">Popularity</SelectItem>
                    <SelectItem value="rating">Rating</SelectItem>
                    <SelectItem value="releaseYear">Year</SelectItem>
                    <SelectItem value="title">Title</SelectItem>
                  </SelectContent>
                </Select>

                <Button variant="ghost" size="sm" onClick={clearFilters} className="text-cinema-red col-span-2 sm:col-span-4">
                  Clear All Filters
                </Button>
              </div>
            )}
          </div>

          {/* Movie Grid */}
          {isLoading ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
              {Array.from({ length: 24 }).map((_, i) => (
                <div key={i}>
                  <div className="aspect-[2/3] skeleton-shimmer rounded-lg" />
                  <div className="mt-2 space-y-1">
                    <div className="h-4 w-3/4 skeleton-shimmer rounded" />
                    <div className="h-3 w-1/2 skeleton-shimmer rounded" />
                  </div>
                </div>
              ))}
            </div>
          ) : data && data.movies.length > 0 ? (
            <>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
                {data.movies.map((movie) => (
                  <div key={movie.id} className="w-full">
                    <MovieCard movie={movie} />
                  </div>
                ))}
              </div>

              {/* Pagination */}
              {totalPages > 1 && (
                <div className="mt-10 flex items-center justify-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    disabled={page === 0}
                    onClick={() => setPage(p => p - 1)}
                    className="border-border/50"
                  >
                    Previous
                  </Button>
                  <span className="text-sm text-muted-foreground px-4">
                    Page {page + 1} of {totalPages}
                  </span>
                  <Button
                    variant="outline"
                    size="sm"
                    disabled={page >= totalPages - 1}
                    onClick={() => setPage(p => p + 1)}
                    className="border-border/50"
                  >
                    Next
                  </Button>
                </div>
              )}
            </>
          ) : (
            <div className="text-center py-20">
              <p className="text-xl text-muted-foreground">No movies found matching your criteria.</p>
              <Button variant="outline" className="mt-4" onClick={clearFilters}>Clear Filters</Button>
            </div>
          )}
        </div>
      </div>
      <Footer />
    </div>
  );
}

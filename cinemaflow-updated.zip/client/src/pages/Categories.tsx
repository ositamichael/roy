import { trpc } from "@/lib/trpc";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { Globe, Film, ArrowRight } from "lucide-react";
import { REGION_LABELS, GENRE_COLORS, ALL_REGIONS } from "@shared/movie-constants";

export default function Categories() {
  const { data: genres } = trpc.movies.genres.useQuery();

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Navbar />

      <div className="pt-20 pb-16">
        <div className="container">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            <h1 className="text-3xl sm:text-4xl font-bold mb-2">Categories</h1>
            <p className="text-muted-foreground mb-10">Browse movies by region or genre</p>
          </motion.div>

          {/* Regions */}
          <motion.section initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="mb-12">
            <h2 className="text-xl font-bold mb-6 flex items-center gap-2">
              <Globe className="w-5 h-5 text-cinema-red" />
              By Region
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {ALL_REGIONS.map((region, i) => (
                <Link key={region.value} href={`/movies?region=${region.value}`}>
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.05 * i }}
                    className="group relative rounded-xl overflow-hidden bg-card border border-border/50 p-6 hover:border-cinema-red/30 transition-all cursor-pointer"
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-semibold text-lg text-foreground group-hover:text-cinema-red transition-colors">
                          {REGION_LABELS[region.value]}
                        </h3>
                        <p className="text-sm text-muted-foreground mt-1">Explore {region.label} films</p>
                      </div>
                      <ArrowRight className="w-5 h-5 text-muted-foreground group-hover:text-cinema-red group-hover:translate-x-1 transition-all" />
                    </div>
                  </motion.div>
                </Link>
              ))}
            </div>
          </motion.section>

          {/* Genres */}
          <motion.section initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
            <h2 className="text-xl font-bold mb-6 flex items-center gap-2">
              <Film className="w-5 h-5 text-cinema-red" />
              By Genre
            </h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
              {genres?.map((genre, i) => {
                const colorClass = GENRE_COLORS[genre] || "bg-gray-500/20 text-gray-400";
                return (
                  <Link key={genre} href={`/movies?genre=${genre}`}>
                    <motion.div
                      initial={{ opacity: 0, scale: 0.95 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: 0.02 * i }}
                      className="group rounded-xl bg-card border border-border/50 p-4 text-center hover:border-cinema-red/30 transition-all cursor-pointer"
                    >
                      <span className={`inline-block px-3 py-1 rounded-full text-xs font-medium mb-2 ${colorClass}`}>
                        {genre}
                      </span>
                      <h3 className="font-medium text-sm text-foreground group-hover:text-cinema-red transition-colors">
                        {genre}
                      </h3>
                    </motion.div>
                  </Link>
                );
              })}
            </div>
          </motion.section>
        </div>
      </div>

      <Footer />
    </div>
  );
}

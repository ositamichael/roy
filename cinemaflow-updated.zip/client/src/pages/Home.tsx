import { trpc } from "@/lib/trpc";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import HeroSection from "@/components/HeroSection";
import MovieRow from "@/components/MovieRow";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { Globe, Film, Shield, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { REGION_LABELS } from "@shared/movie-constants";

export default function Home() {
  const { data: featured, isLoading: featuredLoading } = trpc.movies.featured.useQuery({ limit: 10 });
  const { data: trending, isLoading: trendingLoading } = trpc.movies.trending.useQuery({ limit: 20 });
  const { data: african, isLoading: africanLoading } = trpc.movies.byRegion.useQuery({ region: "african", limit: 20 });
  const { data: european, isLoading: europeanLoading } = trpc.movies.byRegion.useQuery({ region: "european", limit: 20 });
  const { data: asian, isLoading: asianLoading } = trpc.movies.byRegion.useQuery({ region: "asian", limit: 20 });
  const { data: actionMovies, isLoading: actionLoading } = trpc.movies.byGenre.useQuery({ genre: "Action", limit: 20 });
  const { data: dramaMovies, isLoading: dramaLoading } = trpc.movies.byGenre.useQuery({ genre: "Drama", limit: 20 });
  const { data: comedyMovies, isLoading: comedyLoading } = trpc.movies.byGenre.useQuery({ genre: "Comedy", limit: 20 });
  const { data: thrillerMovies, isLoading: thrillerLoading } = trpc.movies.byGenre.useQuery({ genre: "Thriller", limit: 20 });

  const heroMovie = featured && featured.length > 0 ? featured[0] : null;

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Navbar />
      <HeroSection featuredMovie={heroMovie} />

      <div className="container space-y-10 pb-16">
        <MovieRow title="Trending Now" movies={trending || []} isLoading={trendingLoading} viewAllHref="/movies?trending=true" />
        <MovieRow title="Featured Films" movies={featured || []} isLoading={featuredLoading} viewAllHref="/movies?featured=true" />
        <MovieRow title="African Cinema" movies={african || []} isLoading={africanLoading} viewAllHref="/movies?region=african" />
        <MovieRow title="European Cinema" movies={european || []} isLoading={europeanLoading} viewAllHref="/movies?region=european" />
        <MovieRow title="Asian Cinema" movies={asian || []} isLoading={asianLoading} viewAllHref="/movies?region=asian" />
        <MovieRow title="Action" movies={actionMovies || []} isLoading={actionLoading} viewAllHref="/movies?genre=Action" />
        <MovieRow title="Drama" movies={dramaMovies || []} isLoading={dramaLoading} viewAllHref="/movies?genre=Drama" />
        <MovieRow title="Comedy" movies={comedyMovies || []} isLoading={comedyLoading} viewAllHref="/movies?genre=Comedy" />
        <MovieRow title="Thriller" movies={thrillerMovies || []} isLoading={thrillerLoading} viewAllHref="/movies?genre=Thriller" />

        {/* Browse by Region */}
        <motion.section initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="py-12">
          <h2 className="text-2xl sm:text-3xl font-bold text-center mb-8">Browse by Region</h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
            {Object.entries(REGION_LABELS).map(([key, label]) => (
              <Link key={key} href={`/movies?region=${key}`}>
                <div className="group relative rounded-xl overflow-hidden bg-card border border-border/50 p-6 text-center hover:border-cinema-red/30 transition-all cursor-pointer">
                  <Globe className="w-8 h-8 text-cinema-red mx-auto mb-3 group-hover:scale-110 transition-transform" />
                  <h3 className="font-semibold text-foreground">{label}</h3>
                  <ArrowRight className="w-4 h-4 text-muted-foreground mx-auto mt-2 group-hover:text-cinema-red transition-colors" />
                </div>
              </Link>
            ))}
          </div>
        </motion.section>

        {/* Value Proposition */}
        <motion.section initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="py-12">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { icon: Globe, title: "Global Discovery", desc: "Explore cinema from over 50 countries across 7 world regions." },
              { icon: Film, title: "Official Platforms", desc: "Every movie links directly to where you can legally watch or purchase it." },
              { icon: Shield, title: "100% Legal", desc: "We only feature official trailers and redirect to licensed streaming services." },
            ].map((item) => (
              <div key={item.title} className="text-center p-6 rounded-xl bg-card border border-border/50">
                <item.icon className="w-10 h-10 text-cinema-red mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">{item.title}</h3>
                <p className="text-sm text-muted-foreground">{item.desc}</p>
              </div>
            ))}
          </div>
        </motion.section>

        {/* CTA */}
        <motion.section initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center py-16 rounded-2xl bg-gradient-to-r from-cinema-red/10 via-purple-500/10 to-cinema-red/10 border border-border/50">
          <h2 className="text-3xl sm:text-4xl font-bold mb-4">Ready to Explore?</h2>
          <p className="text-muted-foreground max-w-md mx-auto mb-8">Join CinemaFlow and get personalized recommendations, save your favorites, and access exclusive content.</p>
          <div className="flex justify-center gap-4">
            <Link href="/membership">
              <Button size="lg" className="bg-cinema-red hover:bg-cinema-red/90 text-white font-semibold">View Plans</Button>
            </Link>
            <Link href="/movies">
              <Button size="lg" variant="outline">Browse Movies</Button>
            </Link>
          </div>
        </motion.section>
      </div>

      <Footer />
    </div>
  );
}

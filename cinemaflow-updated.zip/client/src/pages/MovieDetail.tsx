import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { useRoute, Link } from "wouter";
import { Star, Calendar, Globe, ExternalLink, Heart, ArrowLeft, Loader2, Play } from "lucide-react";
import { motion } from "framer-motion";
import { GENRE_COLORS } from "@shared/movie-constants";
import { toast } from "sonner";
import { getBackdropSrc, getPosterSrc, getTrailerSearchUrl, normalizeTrailerUrl } from "@/lib/movieMedia";

export default function MovieDetail() {
  const [, routeParams] = useRoute("/movie/:id");
  const movieId = parseInt(routeParams?.id || "0");

  const { data: movie, isLoading } = trpc.movies.getById.useQuery({ id: movieId }, { enabled: movieId > 0 });
  const { isAuthenticated } = useAuth();

  const addToWatchlist = trpc.watchlist.add.useMutation({
    onSuccess: () => toast.success("Added to your watchlist!"),
    onError: () => toast.error("Please sign in to add to watchlist"),
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background text-foreground">
        <Navbar />
        <div className="pt-20 flex items-center justify-center min-h-[60vh]">
          <Loader2 className="w-8 h-8 animate-spin text-cinema-red" />
        </div>
      </div>
    );
  }

  if (!movie) {
    return (
      <div className="min-h-screen bg-background text-foreground">
        <Navbar />
        <div className="pt-20 text-center py-20">
          <h1 className="text-2xl font-bold">Movie not found</h1>
          <Link href="/movies">
            <Button className="mt-4" variant="outline">Back to Movies</Button>
          </Link>
        </div>
        <Footer />
      </div>
    );
  }

  const genres = movie.genre.split(",").map(g => g.trim());
  const posterSrc = getPosterSrc(movie);
  const backdropSrc = getBackdropSrc(movie);
  const trailerEmbedUrl = normalizeTrailerUrl(movie.trailerUrl);
  const trailerSearchUrl = getTrailerSearchUrl(movie.title, movie.releaseYear);

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Navbar />

      <div className="pt-20">
        <div className="relative">
          <div className="h-[40vh] sm:h-[50vh] relative overflow-hidden">
            <img src={backdropSrc} alt={movie.title} className="absolute inset-0 h-full w-full object-cover" />
            <div className="absolute inset-0 bg-black/45" />
            <div className="absolute inset-0 cinema-gradient-bottom" />
            <div className="absolute inset-0 cinema-gradient-left opacity-70" />
          </div>

          <div className="container relative -mt-32 sm:-mt-40 z-10">
            <Link href="/movies">
              <Button variant="ghost" size="sm" className="mb-4 text-muted-foreground hover:text-foreground gap-2 bg-background/30 backdrop-blur-sm">
                <ArrowLeft className="w-4 h-4" /> Back to Movies
              </Button>
            </Link>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex flex-col md:flex-row gap-8"
            >
              <div className="flex-shrink-0">
                <div className="w-[200px] sm:w-[260px] aspect-[2/3] rounded-xl overflow-hidden bg-card shadow-2xl shadow-black/50 border border-border/30">
                  <img src={posterSrc} alt={movie.title} className="h-full w-full object-cover" />
                </div>
              </div>

              <div className="flex-1 space-y-4">
                <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black leading-tight">{movie.title}</h1>

                <div className="flex flex-wrap items-center gap-3 text-sm">
                  <div className="flex items-center gap-1">
                    <Calendar className="w-4 h-4 text-muted-foreground" />
                    <span>{movie.releaseYear}</span>
                  </div>
                  <span className="text-muted-foreground">·</span>
                  <div className="flex items-center gap-1">
                    <Globe className="w-4 h-4 text-muted-foreground" />
                    <span>{movie.country}</span>
                  </div>
                  {movie.rating && (
                    <>
                      <span className="text-muted-foreground">·</span>
                      <div className="flex items-center gap-1">
                        <Star className="w-4 h-4 text-cinema-gold fill-cinema-gold" />
                        <span className="text-cinema-gold font-semibold">{movie.rating}</span>
                      </div>
                    </>
                  )}
                </div>

                <div className="flex flex-wrap gap-2">
                  {genres.map((g) => (
                    <Link key={g} href={`/movies?genre=${g}`}>
                      <span className={`px-3 py-1 rounded-full text-xs font-medium cursor-pointer hover:opacity-80 transition-opacity ${GENRE_COLORS[g] || "bg-gray-500/20 text-gray-400"}`}>
                        {g}
                      </span>
                    </Link>
                  ))}
                </div>

                {movie.description && (
                  <p className="text-muted-foreground leading-relaxed max-w-2xl text-base">
                    {movie.description}
                  </p>
                )}

                <div className="flex flex-wrap gap-3 pt-2">
                  {movie.platformUrl && (
                    <a href={movie.platformUrl} target="_blank" rel="noopener noreferrer">
                      <Button size="lg" className="bg-cinema-red hover:bg-cinema-red/90 text-white font-semibold gap-2">
                        <ExternalLink className="w-5 h-5" />
                        Watch on {movie.platformName || "Official Platform"}
                      </Button>
                    </a>
                  )}
                  {trailerEmbedUrl ? (
                    <a href={trailerEmbedUrl.replace('/embed/', '/watch?v=')} target="_blank" rel="noopener noreferrer">
                      <Button size="lg" variant="outline" className="gap-2 border-border/50 bg-background/40 backdrop-blur-sm">
                        <Play className="w-5 h-5" />
                        Watch Trailer
                      </Button>
                    </a>
                  ) : (
                    <a href={trailerSearchUrl} target="_blank" rel="noopener noreferrer">
                      <Button size="lg" variant="outline" className="gap-2 border-border/50 bg-background/40 backdrop-blur-sm">
                        <Play className="w-5 h-5" />
                        Find Trailer on YouTube
                      </Button>
                    </a>
                  )}
                  {isAuthenticated && (
                    <Button
                      size="lg"
                      variant="outline"
                      className="gap-2 border-border/50"
                      onClick={() => addToWatchlist.mutate({ movieId: movie.id })}
                      disabled={addToWatchlist.isPending}
                    >
                      <Heart className="w-5 h-5" />
                      Add to Watchlist
                    </Button>
                  )}
                </div>

                {movie.platformName && (
                  <div className="flex items-center gap-2 text-sm text-muted-foreground pt-2">
                    <ExternalLink className="w-4 h-4" />
                    <span>Available on <span className="text-cinema-red font-medium">{movie.platformName}</span></span>
                  </div>
                )}
              </div>
            </motion.div>
          </div>
        </div>

        <div className="container py-12">
          <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
            <Play className="w-6 h-6 text-cinema-red" />
            {trailerEmbedUrl ? "Official Trailer" : "Trailer Search"}
          </h2>

          {trailerEmbedUrl ? (
            <div className="aspect-video max-w-4xl rounded-xl overflow-hidden bg-card border border-border/50">
              <iframe
                src={trailerEmbedUrl}
                title={`${movie.title} Trailer`}
                className="w-full h-full"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              />
            </div>
          ) : (
            <div className="max-w-4xl rounded-xl border border-border/50 bg-card p-8">
              <p className="text-muted-foreground leading-relaxed">
                We removed the repeated placeholder trailer for this title. Use the button below to open a title-specific YouTube trailer search instead of showing the wrong video.
              </p>
              <a href={trailerSearchUrl} target="_blank" rel="noopener noreferrer" className="inline-block mt-4">
                <Button className="bg-cinema-red hover:bg-cinema-red/90 text-white gap-2">
                  <Play className="w-4 h-4" />
                  Search {movie.title} trailer
                </Button>
              </a>
            </div>
          )}
        </div>

        <div className="container pb-16">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl">
            <div className="p-4 rounded-xl bg-card border border-border/50">
              <h3 className="text-sm font-medium text-muted-foreground mb-1">Country</h3>
              <p className="font-semibold">{movie.country}</p>
            </div>
            <div className="p-4 rounded-xl bg-card border border-border/50">
              <h3 className="text-sm font-medium text-muted-foreground mb-1">Region</h3>
              <p className="font-semibold capitalize">{movie.region.replace("_", " ")}</p>
            </div>
            <div className="p-4 rounded-xl bg-card border border-border/50">
              <h3 className="text-sm font-medium text-muted-foreground mb-1">Release Year</h3>
              <p className="font-semibold">{movie.releaseYear}</p>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}

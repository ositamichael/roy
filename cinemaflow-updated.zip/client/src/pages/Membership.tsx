import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { Check, Crown, Sparkles, Star, Zap, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { useSearch } from "wouter";
import { useEffect, useMemo } from "react";

const PLANS = [
  {
    tier: "basic" as const,
    name: "Basic",
    priceMonthly: "$4.99",
    priceYearly: "$49.99",
    icon: Star,
    color: "from-blue-500/20 to-blue-600/20",
    borderColor: "border-blue-500/30",
    features: [
      "Access to movie database",
      "Basic search and filters",
      "Save up to 20 favorites",
      "Standard quality trailers",
    ],
  },
  {
    tier: "standard" as const,
    name: "Standard",
    priceMonthly: "$9.99",
    priceYearly: "$99.99",
    icon: Zap,
    color: "from-cinema-red/20 to-orange-500/20",
    borderColor: "border-cinema-red/30",
    popular: true,
    features: [
      "Everything in Basic",
      "Unlimited favorites",
      "Advanced filters & recommendations",
      "HD quality trailers",
      "Early access to new listings",
      "Priority support",
    ],
  },
  {
    tier: "premium" as const,
    name: "Premium",
    priceMonthly: "$19.99",
    priceYearly: "$199.99",
    icon: Crown,
    color: "from-cinema-gold/20 to-amber-500/20",
    borderColor: "border-cinema-gold/30",
    features: [
      "Everything in Standard",
      "Exclusive curated collections",
      "Behind-the-scenes content",
      "VIP community access",
      "Personal movie recommendations",
      "Ad-free experience",
      "Premium support",
    ],
  },
];

export default function Membership() {
  const { isAuthenticated, user } = useAuth();
  const [billing, setBilling] = useState<"monthly" | "yearly">("monthly");
  const [loadingTier, setLoadingTier] = useState<string | null>(null);

  const searchString = useSearch();
  const params = useMemo(() => new URLSearchParams(searchString), [searchString]);

  useEffect(() => {
    const status = params.get("status");
    if (status === "success") {
      toast.success("Payment successful! Welcome to your new plan.");
    } else if (status === "cancelled") {
      toast.info("Payment was cancelled.");
    }
  }, [params]);

  const createCheckout = trpc.membership.createCheckout.useMutation({
    onSuccess: (data) => {
      if (data.url) {
        window.open(data.url, "_blank");
        toast.info("Redirecting to checkout...");
      }
      setLoadingTier(null);
    },
    onError: (err) => {
      toast.error(err.message || "Failed to create checkout session");
      setLoadingTier(null);
    },
  });

  const handleSubscribe = (tier: "basic" | "standard" | "premium") => {
    if (!isAuthenticated) {
      window.location.href = getLoginUrl();
      return;
    }
    setLoadingTier(tier);
    createCheckout.mutate({
      tier,
      billing,
      origin: window.location.origin,
    });
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Navbar />

      <div className="pt-20 pb-16">
        {/* Hero */}
        <section className="relative py-16 overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-cinema-red/10 via-background to-background" />
          <div className="container relative z-10 text-center">
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
              <Sparkles className="w-10 h-10 text-cinema-gold mx-auto mb-4" />
              <h1 className="text-3xl sm:text-4xl font-bold mb-3">Membership Plans</h1>
              <p className="text-muted-foreground max-w-md mx-auto">
                Unlock the full CinemaFlow experience with a plan that fits your needs.
              </p>

              {/* Billing toggle */}
              <div className="mt-8 inline-flex items-center gap-3 p-1 rounded-full bg-card border border-border/50">
                <button
                  onClick={() => setBilling("monthly")}
                  className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                    billing === "monthly" ? "bg-cinema-red text-white" : "text-muted-foreground hover:text-foreground"
                  }`}
                >
                  Monthly
                </button>
                <button
                  onClick={() => setBilling("yearly")}
                  className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                    billing === "yearly" ? "bg-cinema-red text-white" : "text-muted-foreground hover:text-foreground"
                  }`}
                >
                  Yearly <span className="text-xs opacity-75">Save 17%</span>
                </button>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Plans */}
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
            {PLANS.map((plan, i) => (
              <motion.div
                key={plan.tier}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 * i }}
                className={`relative rounded-2xl bg-gradient-to-b ${plan.color} border ${plan.borderColor} p-6 ${
                  plan.popular ? "ring-2 ring-cinema-red" : ""
                }`}
              >
                {plan.popular && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full bg-cinema-red text-white text-xs font-semibold">
                    Most Popular
                  </div>
                )}

                <div className="text-center mb-6">
                  <plan.icon className="w-8 h-8 text-cinema-red mx-auto mb-3" />
                  <h3 className="text-xl font-bold">{plan.name}</h3>
                  <div className="mt-3">
                    <span className="text-3xl font-black">
                      {billing === "monthly" ? plan.priceMonthly : plan.priceYearly}
                    </span>
                    <span className="text-muted-foreground text-sm">
                      /{billing === "monthly" ? "month" : "year"}
                    </span>
                  </div>
                </div>

                <ul className="space-y-3 mb-8">
                  {plan.features.map((feature) => (
                    <li key={feature} className="flex items-start gap-2 text-sm">
                      <Check className="w-4 h-4 text-cinema-red flex-shrink-0 mt-0.5" />
                      <span className="text-muted-foreground">{feature}</span>
                    </li>
                  ))}
                </ul>

                <Button
                  className={`w-full font-semibold ${
                    plan.popular
                      ? "bg-cinema-red hover:bg-cinema-red/90 text-white"
                      : "bg-card hover:bg-accent border border-border/50"
                  }`}
                  onClick={() => handleSubscribe(plan.tier)}
                  disabled={loadingTier === plan.tier}
                >
                  {loadingTier === plan.tier ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    `Get ${plan.name}`
                  )}
                </Button>
              </motion.div>
            ))}
          </div>

          {/* FAQ */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mt-16 max-w-2xl mx-auto"
          >
            <h2 className="text-2xl font-bold text-center mb-8">Frequently Asked Questions</h2>
            <div className="space-y-4">
              {[
                {
                  q: "Can I cancel anytime?",
                  a: "Yes, you can cancel your subscription at any time. You'll continue to have access until the end of your billing period.",
                },
                {
                  q: "Does CinemaFlow stream movies?",
                  a: "No, CinemaFlow is a discovery platform. We help you find movies and redirect you to official streaming platforms where you can watch them legally.",
                },
                {
                  q: "What payment methods do you accept?",
                  a: "We accept all major credit and debit cards through our secure Stripe payment processing.",
                },
                {
                  q: "Is there a free trial?",
                  a: "You can browse our movie catalog for free. Membership unlocks additional features like unlimited favorites, personalized recommendations, and exclusive content.",
                },
              ].map((faq) => (
                <div key={faq.q} className="p-4 rounded-xl bg-card border border-border/50">
                  <h3 className="font-semibold text-foreground">{faq.q}</h3>
                  <p className="text-sm text-muted-foreground mt-2">{faq.a}</p>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>

      <Footer />
    </div>
  );
}

import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Play, Search, Globe } from "lucide-react";
import { motion } from "framer-motion";
import { getBackdropSrc, getPosterSrc } from "@/lib/movieMedia";

interface HeroSectionProps {
  featuredMovie?: {
    id: number;
    title: string;
    description?: string | null;
    genre: string;
    releaseYear: number;
    country: string;
    rating?: string | number | null;
    posterUrl?: string | null;
    backdropUrl?: string | null;
  } | null;
}

export default function HeroSection({ featuredMovie }: HeroSectionProps) {
  return (
    <section className="relative min-h-[85vh] flex items-center overflow-hidden">
      {/* Animated background */}
      <div className="absolute inset-0">
        {featuredMovie && (
          <img
            src={getBackdropSrc(featuredMovie)}
            alt={featuredMovie.title}
            className="absolute inset-0 h-full w-full object-cover opacity-30"
          />
        )}
        <div className="absolute inset-0 bg-gradient-to-br from-cinema-red/25 via-background/90 to-background" />
        <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-cinema-red/5 rounded-full blur-3xl" />
        <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-purple-500/5 rounded-full blur-3xl" />
        {/* Film grain overlay */}
        <div className="absolute inset-0 opacity-[0.03]" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.65' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)'/%3E%3C/svg%3E")`,
        }} />
      </div>

      <div className="container relative z-10 py-20">
        <div className="max-w-3xl">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <div className="flex items-center gap-2 mb-6">
              <Globe className="w-5 h-5 text-cinema-red" />
              <span className="text-sm font-medium text-cinema-red uppercase tracking-wider">
                Global Cinema Discovery
              </span>
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-7xl font-black leading-[1.1] tracking-tight">
              Discover Movies
              <br />
              <span className="text-cinema-red">From Every Corner</span>
              <br />
              of the World
            </h1>

            <p className="mt-6 text-lg sm:text-xl text-muted-foreground max-w-xl leading-relaxed">
              Explore 660+ films from Africa, Europe, Asia, and beyond. Find your next favorite movie and watch it on official platforms.
            </p>

            <div className="mt-8 flex flex-wrap gap-4">
              <Link href="/movies">
                <Button size="lg" className="bg-cinema-red hover:bg-cinema-red/90 text-white font-semibold gap-2 h-12 px-8">
                  <Play className="w-5 h-5" />
                  Explore Movies
                </Button>
              </Link>
              <Link href="/movies?search=true">
                <Button size="lg" variant="outline" className="gap-2 h-12 px-8 border-border/50 hover:bg-accent">
                  <Search className="w-5 h-5" />
                  Search Films
                </Button>
              </Link>
            </div>

            {/* Stats */}
            <div className="mt-12 flex gap-8 sm:gap-12">
              {[
                { value: "660+", label: "Movies" },
                { value: "50+", label: "Countries" },
                { value: "7", label: "Regions" },
                { value: "20+", label: "Genres" },
              ].map((stat) => (
                <div key={stat.label}>
                  <div className="text-2xl sm:text-3xl font-bold text-cinema-red">{stat.value}</div>
                  <div className="text-xs sm:text-sm text-muted-foreground">{stat.label}</div>
                </div>
              ))}
            </div>
          </motion.div>
        </div>

        {/* Featured movie card on right side (desktop) */}
        {featuredMovie && (
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="hidden lg:block absolute right-8 top-1/2 -translate-y-1/2"
          >
            <Link href={`/movie/${featuredMovie.id}`}>
              <div className="w-[280px] rounded-2xl overflow-hidden bg-card border border-border/50 shadow-2xl shadow-black/50 group cursor-pointer hover:border-cinema-red/30 transition-colors">
                <div className="aspect-[2/3] relative overflow-hidden">
                  <img src={getPosterSrc(featuredMovie)} alt={featuredMovie.title} className="absolute inset-0 h-full w-full object-cover" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/25 to-transparent" />
                  <div className="text-center relative z-10 h-full flex flex-col justify-end p-6">
                    <div className="text-xs text-cinema-gold font-semibold uppercase tracking-wider mb-2">Now Featured</div>
                    <h3 className="text-white text-xl font-bold leading-tight">{featuredMovie.title}</h3>
                    <div className="mt-3 text-white/70 text-sm">{featuredMovie.releaseYear} · {featuredMovie.country}</div>
                    <div className="mt-2 text-cinema-gold text-sm font-medium">{featuredMovie.genre.split(",")[0]}</div>
                  </div>
                  <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors flex items-center justify-center">
                    <Play className="w-12 h-12 text-white opacity-0 group-hover:opacity-100 transition-opacity" />
                  </div>
                </div>
              </div>
            </Link>
          </motion.div>
        )}
      </div>
    </section>
  );
}

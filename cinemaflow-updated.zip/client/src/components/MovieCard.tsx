import { Link } from "wouter";
import { Star, Play, ExternalLink } from "lucide-react";
import { GENRE_COLORS } from "@shared/movie-constants";
import { getPosterSrc } from "@/lib/movieMedia";

interface MovieCardProps {
  movie: {
    id: number;
    title: string;
    description?: string | null;
    posterUrl?: string | null;
    genre: string;
    country: string;
    region: string;
    releaseYear: number;
    rating?: string | number | null;
    platformName?: string | null;
  };
  variant?: "default" | "wide" | "compact";
}

function getMoviePosterGradient(title: string): string {
  const colors = [
    "from-red-900 to-red-700",
    "from-blue-900 to-blue-700",
    "from-purple-900 to-purple-700",
    "from-emerald-900 to-emerald-700",
    "from-amber-900 to-amber-700",
    "from-cyan-900 to-cyan-700",
    "from-pink-900 to-pink-700",
    "from-indigo-900 to-indigo-700",
    "from-orange-900 to-orange-700",
    "from-teal-900 to-teal-700",
  ];
  const hash = title.split("").reduce((acc, c) => acc + c.charCodeAt(0), 0);
  return colors[hash % colors.length];
}

export default function MovieCard({ movie, variant = "default" }: MovieCardProps) {
  const primaryGenre = movie.genre.split(",")[0].trim();
  const genreColor = GENRE_COLORS[primaryGenre] || "bg-gray-500/20 text-gray-400";
  const gradient = getMoviePosterGradient(movie.title);
  const posterSrc = getPosterSrc(movie);

  if (variant === "compact") {
    return (
      <Link href={`/movie/${movie.id}`}>
        <div className="movie-card group relative rounded-lg overflow-hidden bg-card cursor-pointer min-w-[140px] w-[140px] sm:min-w-[160px] sm:w-[160px]">
          <div className={`aspect-[2/3] bg-gradient-to-br ${gradient} relative overflow-hidden`}>
            <img src={posterSrc} alt={movie.title} className="w-full h-full object-cover" loading="lazy" />
            <div className="absolute inset-x-0 bottom-0 p-3 bg-gradient-to-t from-black/80 via-black/30 to-transparent">
              <span className="text-white/90 text-xs font-semibold text-center leading-tight line-clamp-3 block">
                {movie.title}
              </span>
            </div>
          </div>
          <div className="absolute inset-0 bg-black/0 group-hover:bg-black/40 transition-colors flex items-center justify-center">
            <Play className="w-8 h-8 text-white opacity-0 group-hover:opacity-100 transition-opacity" />
          </div>
        </div>
      </Link>
    );
  }

  if (variant === "wide") {
    return (
      <Link href={`/movie/${movie.id}`}>
        <div className="movie-card group relative rounded-xl overflow-hidden bg-card cursor-pointer">
          <div className={`aspect-video bg-gradient-to-br ${gradient} flex items-end p-6 relative overflow-hidden`}>
            <img src={posterSrc} alt={movie.title} className="absolute inset-0 w-full h-full object-cover" loading="lazy" />
            <div className="absolute inset-0 bg-black/45" />
            <div className="relative z-10">
              <h3 className="text-white text-lg font-bold line-clamp-1">{movie.title}</h3>
              <div className="flex items-center gap-2 mt-1">
                <span className="text-white/70 text-xs">{movie.releaseYear}</span>
                <span className="text-white/40">·</span>
                <span className="text-white/70 text-xs">{movie.country}</span>
                {movie.rating && (
                  <>
                    <span className="text-white/40">·</span>
                    <Star className="w-3 h-3 text-cinema-gold fill-cinema-gold" />
                    <span className="text-cinema-gold text-xs">{movie.rating}</span>
                  </>
                )}
              </div>
            </div>
            <div className="absolute inset-0 cinema-gradient-bottom" />
          </div>
          <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-colors flex items-center justify-center">
            <Play className="w-12 h-12 text-white opacity-0 group-hover:opacity-100 transition-opacity" />
          </div>
        </div>
      </Link>
    );
  }

  return (
    <Link href={`/movie/${movie.id}`}>
      <div className="movie-card group relative rounded-lg overflow-hidden bg-card cursor-pointer min-w-[180px] w-[180px] sm:min-w-[200px] sm:w-[200px]">
        <div className={`aspect-[2/3] bg-gradient-to-br ${gradient} relative overflow-hidden`}>
          <img src={posterSrc} alt={movie.title} className="absolute inset-0 w-full h-full object-cover" loading="lazy" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/25 to-black/10" />

          <div className="relative z-10 flex h-full flex-col justify-between p-4">
            <div>
              <span className="text-white/95 text-sm font-bold text-center leading-tight line-clamp-3 block drop-shadow-lg">
                {movie.title}
              </span>
              {movie.rating && (
                <div className="mt-2 flex items-center justify-center gap-1">
                  <Star className="w-3 h-3 text-cinema-gold fill-cinema-gold" />
                  <span className="text-cinema-gold text-xs font-medium">{movie.rating}</span>
                </div>
              )}
            </div>

            <div>
              <span className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-medium ${genreColor}`}>
                {primaryGenre}
              </span>
            </div>
          </div>
        </div>

        <div className="p-3 space-y-1">
          <h3 className="text-sm font-semibold text-card-foreground line-clamp-1">{movie.title}</h3>
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span>{movie.releaseYear}</span>
            <span className="truncate ml-1">{movie.country}</span>
          </div>
          {movie.platformName && (
            <div className="flex items-center gap-1 text-xs text-cinema-red">
              <ExternalLink className="w-3 h-3" />
              <span>{movie.platformName}</span>
            </div>
          )}
        </div>

        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-colors flex items-center justify-center">
          <Play className="w-10 h-10 text-white opacity-0 group-hover:opacity-100 transition-opacity drop-shadow-lg" />
        </div>
      </div>
    </Link>
  );
}

import { useRef } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import MovieCard from "./MovieCard";

interface MovieRowProps {
  title: string;
  movies: any[];
  isLoading?: boolean;
  viewAllHref?: string;
  variant?: "default" | "compact";
}

export default function MovieRow({ title, movies, isLoading, viewAllHref, variant = "default" }: MovieRowProps) {
  const scrollRef = useRef<HTMLDivElement>(null);

  const scroll = (direction: "left" | "right") => {
    if (!scrollRef.current) return;
    const amount = direction === "left" ? -400 : 400;
    scrollRef.current.scrollBy({ left: amount, behavior: "smooth" });
  };

  if (isLoading) {
    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="h-7 w-48 skeleton-shimmer rounded" />
        </div>
        <div className="flex gap-3 overflow-hidden">
          {Array.from({ length: 7 }).map((_, i) => (
            <div key={i} className="min-w-[180px] w-[180px] sm:min-w-[200px] sm:w-[200px]">
              <div className="aspect-[2/3] skeleton-shimmer rounded-lg" />
              <div className="mt-2 space-y-1">
                <div className="h-4 w-3/4 skeleton-shimmer rounded" />
                <div className="h-3 w-1/2 skeleton-shimmer rounded" />
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (!movies || movies.length === 0) return null;

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h2 className="text-xl sm:text-2xl font-bold text-foreground">{title}</h2>
        <div className="flex items-center gap-2">
          {viewAllHref && (
            <Link href={viewAllHref} className="text-sm text-cinema-red hover:text-cinema-red/80 font-medium transition-colors">
              View All
            </Link>
          )}
          <div className="hidden sm:flex items-center gap-1">
            <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-foreground" onClick={() => scroll("left")}>
              <ChevronLeft className="w-4 h-4" />
            </Button>
            <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-foreground" onClick={() => scroll("right")}>
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>
      <div ref={scrollRef} className="movie-row">
        {movies.map((movie) => (
          <MovieCard key={movie.id} movie={movie} variant={variant} />
        ))}
      </div>
    </div>
  );
}

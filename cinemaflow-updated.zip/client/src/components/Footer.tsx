import { Link } from "wouter";
import { Film, Github, Twitter, Instagram } from "lucide-react";

export default function Footer() {
  return (
    <footer className="border-t border-border/50 bg-background/50 backdrop-blur-sm">
      <div className="container py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="space-y-4">
            <Link href="/" className="flex items-center gap-2">
              <Film className="w-6 h-6 text-cinema-red" />
              <span className="text-lg font-bold">
                Cinema<span className="text-cinema-red">Flow</span>
              </span>
            </Link>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Discover movies from around the world. Your gateway to global cinema — from African stories to European masterpieces.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground mb-4">Explore</h4>
            <ul className="space-y-2">
              {[
                { href: "/movies", label: "All Movies" },
                { href: "/categories", label: "Categories" },
                { href: "/movies?region=african", label: "African Cinema" },
                { href: "/movies?region=european", label: "European Cinema" },
              ].map((link) => (
                <li key={link.href}>
                  <Link href={link.href} className="text-sm text-muted-foreground hover:text-cinema-red transition-colors">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Company */}
          <div>
            <h4 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground mb-4">Company</h4>
            <ul className="space-y-2">
              {[
                { href: "/about", label: "About Us" },
                { href: "/contact", label: "Contact" },
                { href: "/membership", label: "Membership" },
              ].map((link) => (
                <li key={link.href}>
                  <Link href={link.href} className="text-sm text-muted-foreground hover:text-cinema-red transition-colors">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h4 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground mb-4">Legal</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>We only link to official streaming platforms.</li>
              <li>No pirated content is hosted or distributed.</li>
              <li>All trailers are from official sources.</li>
            </ul>
          </div>
        </div>

        <div className="mt-10 pt-6 border-t border-border/50 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-xs text-muted-foreground">
            &copy; {new Date().getFullYear()} CinemaFlow. All rights reserved. Founded by Osita Michael.
          </p>
          <div className="flex items-center gap-4">
            <span className="text-xs text-muted-foreground">Discover. Watch. Enjoy.</span>
          </div>
        </div>
      </div>
    </footer>
  );
}

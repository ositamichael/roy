import Stripe from 'stripe';
import { Request, Response } from 'express';
import { getDb } from './db';
import { users } from '../drizzle/schema';
import { eq } from 'drizzle-orm';
import { getPlanByTier } from './stripe-products';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || '', {
  apiVersion: '2025-03-31.basil' as any,
});

/**
 * Create a Stripe Checkout Session for a membership plan
 */
export async function createCheckoutSession(
  userId: number,
  userEmail: string,
  userName: string | null,
  tier: string,
  billing: 'monthly' | 'yearly',
  origin: string
) {
  const plan = getPlanByTier(tier);
  if (!plan) throw new Error(`Invalid plan tier: ${tier}`);

  const amount = billing === 'yearly' ? plan.priceYearly : plan.priceMonthly;

  const session = await stripe.checkout.sessions.create({
    payment_method_types: ['card'],
    mode: 'payment',
    customer_email: userEmail,
    client_reference_id: userId.toString(),
    allow_promotion_codes: true,
    metadata: {
      user_id: userId.toString(),
      customer_email: userEmail,
      customer_name: userName || '',
      tier: plan.tier,
      billing_period: billing,
    },
    line_items: [
      {
        price_data: {
          currency: 'usd',
          product_data: {
            name: `CinemaFlow ${plan.name} Plan (${billing})`,
            description: plan.features.join(', '),
          },
          unit_amount: amount,
        },
        quantity: 1,
      },
    ],
    success_url: `${origin}/membership?status=success&tier=${tier}`,
    cancel_url: `${origin}/membership?status=cancelled`,
  });

  return { url: session.url };
}

/**
 * Handle Stripe webhook events
 */
export async function handleWebhook(req: Request, res: Response) {
  const sig = req.headers['stripe-signature'] as string;
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;

  let event: Stripe.Event;

  try {
    event = stripe.webhooks.constructEvent(req.body, sig, webhookSecret || '');
  } catch (err: any) {
    console.error('[Stripe Webhook] Signature verification failed:', err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  // Handle test events
  if (event.id.startsWith('evt_test_')) {
    console.log("[Webhook] Test event detected, returning verification response");
    return res.json({ verified: true });
  }

  console.log(`[Stripe Webhook] Received event: ${event.type} (${event.id})`);

  try {
    switch (event.type) {
      case 'checkout.session.completed': {
        const session = event.data.object as Stripe.Checkout.Session;
        const userId = parseInt(session.metadata?.user_id || '0');
        const tier = session.metadata?.tier as 'basic' | 'standard' | 'premium';

        if (userId && tier) {
          const db = await getDb();
          if (db) {
            await db.update(users).set({
              membershipTier: tier,
              stripeCustomerId: session.customer as string || null,
            }).where(eq(users.id, userId));
            console.log(`[Stripe Webhook] Updated user ${userId} to ${tier} tier`);
          }
        }
        break;
      }

      case 'payment_intent.succeeded': {
        const paymentIntent = event.data.object as Stripe.PaymentIntent;
        console.log(`[Stripe Webhook] Payment succeeded: ${paymentIntent.id}`);
        break;
      }

      default:
        console.log(`[Stripe Webhook] Unhandled event type: ${event.type}`);
    }
  } catch (err) {
    console.error('[Stripe Webhook] Error processing event:', err);
  }

  return res.json({ received: true });
}

import { eq, and, like, or, desc, asc, sql, inArray } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, movies, contactMessages, membershipPlans, userWatchlist } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// ============================================================
// MOVIES
// ============================================================

export interface MovieFilters {
  search?: string;
  genre?: string;
  country?: string;
  region?: string;
  minYear?: number;
  maxYear?: number;
  isFeatured?: boolean;
  isTrending?: boolean;
  sortBy?: 'popularity' | 'rating' | 'releaseYear' | 'title';
  sortOrder?: 'asc' | 'desc';
  limit?: number;
  offset?: number;
}

export async function getMovies(filters: MovieFilters = {}) {
  const db = await getDb();
  if (!db) return { movies: [], total: 0 };

  const conditions = [];

  if (filters.search) {
    const searchTerm = `%${filters.search}%`;
    conditions.push(
      or(
        like(movies.title, searchTerm),
        like(movies.description, searchTerm),
        like(movies.genre, searchTerm),
        like(movies.country, searchTerm)
      )
    );
  }

  if (filters.genre) {
    conditions.push(like(movies.genre, `%${filters.genre}%`));
  }

  if (filters.country) {
    conditions.push(eq(movies.country, filters.country));
  }

  if (filters.region) {
    conditions.push(eq(movies.region, filters.region as any));
  }

  if (filters.minYear) {
    conditions.push(sql`${movies.releaseYear} >= ${filters.minYear}`);
  }

  if (filters.maxYear) {
    conditions.push(sql`${movies.releaseYear} <= ${filters.maxYear}`);
  }

  if (filters.isFeatured) {
    conditions.push(eq(movies.isFeatured, true));
  }

  if (filters.isTrending) {
    conditions.push(eq(movies.isTrending, true));
  }

  const whereClause = conditions.length > 0 ? and(...conditions) : undefined;

  // Get total count
  const countResult = await db
    .select({ count: sql<number>`COUNT(*)` })
    .from(movies)
    .where(whereClause);
  const total = Number(countResult[0]?.count ?? 0);

  // Build sort
  let orderBy;
  const sortOrder = filters.sortOrder === 'asc' ? asc : desc;
  switch (filters.sortBy) {
    case 'rating':
      orderBy = sortOrder(movies.rating);
      break;
    case 'releaseYear':
      orderBy = sortOrder(movies.releaseYear);
      break;
    case 'title':
      orderBy = sortOrder(movies.title);
      break;
    default:
      orderBy = sortOrder(movies.popularity);
  }

  const limit = filters.limit ?? 20;
  const offset = filters.offset ?? 0;

  const result = await db
    .select()
    .from(movies)
    .where(whereClause)
    .orderBy(orderBy)
    .limit(limit)
    .offset(offset);

  return { movies: result, total };
}

export async function getMovieById(id: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(movies).where(eq(movies.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getFeaturedMovies(limit = 10) {
  const db = await getDb();
  if (!db) return [];

  return db
    .select()
    .from(movies)
    .where(eq(movies.isFeatured, true))
    .orderBy(desc(movies.popularity))
    .limit(limit);
}

export async function getTrendingMovies(limit = 20) {
  const db = await getDb();
  if (!db) return [];

  return db
    .select()
    .from(movies)
    .where(eq(movies.isTrending, true))
    .orderBy(desc(movies.popularity))
    .limit(limit);
}

export async function getMoviesByRegion(region: string, limit = 20) {
  const db = await getDb();
  if (!db) return [];

  return db
    .select()
    .from(movies)
    .where(eq(movies.region, region as any))
    .orderBy(desc(movies.popularity))
    .limit(limit);
}

export async function getMoviesByGenre(genre: string, limit = 20) {
  const db = await getDb();
  if (!db) return [];

  return db
    .select()
    .from(movies)
    .where(like(movies.genre, `%${genre}%`))
    .orderBy(desc(movies.popularity))
    .limit(limit);
}

export async function getDistinctGenres() {
  const db = await getDb();
  if (!db) return [];

  const result = await db
    .selectDistinct({ genre: movies.genre })
    .from(movies);

  // Parse comma-separated genres into unique list
  const genreSet = new Set<string>();
  result.forEach(r => {
    r.genre.split(',').forEach(g => genreSet.add(g.trim()));
  });
  return Array.from(genreSet).sort();
}

export async function getDistinctCountries() {
  const db = await getDb();
  if (!db) return [];

  const result = await db
    .selectDistinct({ country: movies.country })
    .from(movies)
    .orderBy(asc(movies.country));

  return result.map(r => r.country);
}

// ============================================================
// CONTACT MESSAGES
// ============================================================

export async function createContactMessage(data: { name: string; email: string; message: string }) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.insert(contactMessages).values(data);
  return { success: true };
}

// ============================================================
// MEMBERSHIP PLANS
// ============================================================

export async function getMembershipPlans() {
  const db = await getDb();
  if (!db) return [];

  return db
    .select()
    .from(membershipPlans)
    .where(eq(membershipPlans.isActive, true))
    .orderBy(asc(membershipPlans.priceMonthly));
}

export async function getMembershipPlanById(id: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(membershipPlans).where(eq(membershipPlans.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// ============================================================
// USER WATCHLIST
// ============================================================

export async function getUserWatchlist(userId: number) {
  const db = await getDb();
  if (!db) return [];

  const watchlistItems = await db
    .select()
    .from(userWatchlist)
    .where(eq(userWatchlist.userId, userId))
    .orderBy(desc(userWatchlist.createdAt));

  if (watchlistItems.length === 0) return [];

  const movieIds = watchlistItems.map(w => w.movieId);
  const movieResults = await db
    .select()
    .from(movies)
    .where(inArray(movies.id, movieIds));

  return movieResults;
}

export async function addToWatchlist(userId: number, movieId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // Check if already in watchlist
  const existing = await db
    .select()
    .from(userWatchlist)
    .where(and(eq(userWatchlist.userId, userId), eq(userWatchlist.movieId, movieId)))
    .limit(1);

  if (existing.length > 0) return { success: true, message: "Already in watchlist" };

  await db.insert(userWatchlist).values({ userId, movieId });
  return { success: true, message: "Added to watchlist" };
}

export async function removeFromWatchlist(userId: number, movieId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db
    .delete(userWatchlist)
    .where(and(eq(userWatchlist.userId, userId), eq(userWatchlist.movieId, movieId)));

  return { success: true, message: "Removed from watchlist" };
}

export async function isInWatchlist(userId: number, movieId: number) {
  const db = await getDb();
  if (!db) return false;

  const result = await db
    .select()
    .from(userWatchlist)
    .where(and(eq(userWatchlist.userId, userId), eq(userWatchlist.movieId, movieId)))
    .limit(1);

  return result.length > 0;
}

// ============================================================
// USER MEMBERSHIP
// ============================================================

export async function updateUserMembership(userId: number, tier: 'free' | 'basic' | 'standard' | 'premium', stripeCustomerId?: string, stripeSubscriptionId?: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const updateData: Record<string, unknown> = { membershipTier: tier };
  if (stripeCustomerId) updateData.stripeCustomerId = stripeCustomerId;
  if (stripeSubscriptionId) updateData.stripeSubscriptionId = stripeSubscriptionId;

  await db.update(users).set(updateData).where(eq(users.id, userId));
  return { success: true };
}

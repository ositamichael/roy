import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import {
  getMovies,
  getMovieById,
  getFeaturedMovies,
  getTrendingMovies,
  getMoviesByRegion,
  getMoviesByGenre,
  getDistinctGenres,
  getDistinctCountries,
  createContactMessage,
  getMembershipPlans,
  getMembershipPlanById,
  getUserWatchlist,
  addToWatchlist,
  removeFromWatchlist,
  isInWatchlist,
  updateUserMembership,
} from "./db";
import { notifyOwner } from "./_core/notification";
import { createCheckoutSession } from "./stripe-handler";

export const appRouter = router({
  system: systemRouter,

  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  movies: router({
    list: publicProcedure
      .input(z.object({
        search: z.string().optional(),
        genre: z.string().optional(),
        country: z.string().optional(),
        region: z.string().optional(),
        minYear: z.number().optional(),
        maxYear: z.number().optional(),
        isFeatured: z.boolean().optional(),
        isTrending: z.boolean().optional(),
        sortBy: z.enum(['popularity', 'rating', 'releaseYear', 'title']).optional(),
        sortOrder: z.enum(['asc', 'desc']).optional(),
        limit: z.number().min(1).max(100).optional(),
        offset: z.number().min(0).optional(),
      }).optional())
      .query(({ input }) => getMovies(input ?? {})),

    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(({ input }) => getMovieById(input.id)),

    featured: publicProcedure
      .input(z.object({ limit: z.number().optional() }).optional())
      .query(({ input }) => getFeaturedMovies(input?.limit)),

    trending: publicProcedure
      .input(z.object({ limit: z.number().optional() }).optional())
      .query(({ input }) => getTrendingMovies(input?.limit)),

    byRegion: publicProcedure
      .input(z.object({ region: z.string(), limit: z.number().optional() }))
      .query(({ input }) => getMoviesByRegion(input.region, input.limit)),

    byGenre: publicProcedure
      .input(z.object({ genre: z.string(), limit: z.number().optional() }))
      .query(({ input }) => getMoviesByGenre(input.genre, input.limit)),

    genres: publicProcedure.query(() => getDistinctGenres()),

    countries: publicProcedure.query(() => getDistinctCountries()),
  }),

  contact: router({
    submit: publicProcedure
      .input(z.object({
        name: z.string().min(1, "Name is required"),
        email: z.string().email("Invalid email address"),
        message: z.string().min(10, "Message must be at least 10 characters"),
      }))
      .mutation(async ({ input }) => {
        const result = await createContactMessage(input);
        // Notify owner about new contact message
        await notifyOwner({
          title: `New Contact Message from ${input.name}`,
          content: `Email: ${input.email}\n\nMessage: ${input.message}`,
        });
        return result;
      }),
  }),

  membership: router({
    plans: publicProcedure.query(() => getMembershipPlans()),

    getPlan: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(({ input }) => getMembershipPlanById(input.id)),

    updateTier: protectedProcedure
      .input(z.object({
        tier: z.enum(['free', 'basic', 'standard', 'premium']),
        stripeCustomerId: z.string().optional(),
        stripeSubscriptionId: z.string().optional(),
      }))
      .mutation(({ ctx, input }) =>
        updateUserMembership(ctx.user.id, input.tier, input.stripeCustomerId, input.stripeSubscriptionId)
      ),

    createCheckout: protectedProcedure
      .input(z.object({
        tier: z.enum(['basic', 'standard', 'premium']),
        billing: z.enum(['monthly', 'yearly']),
        origin: z.string(),
      }))
      .mutation(async ({ ctx, input }) => {
        return createCheckoutSession(
          ctx.user.id,
          ctx.user.email || '',
          ctx.user.name || null,
          input.tier,
          input.billing,
          input.origin
        );
      }),
  }),

  watchlist: router({
    list: protectedProcedure.query(({ ctx }) => getUserWatchlist(ctx.user.id)),

    add: protectedProcedure
      .input(z.object({ movieId: z.number() }))
      .mutation(({ ctx, input }) => addToWatchlist(ctx.user.id, input.movieId)),

    remove: protectedProcedure
      .input(z.object({ movieId: z.number() }))
      .mutation(({ ctx, input }) => removeFromWatchlist(ctx.user.id, input.movieId)),

    isInWatchlist: protectedProcedure
      .input(z.object({ movieId: z.number() }))
      .query(({ ctx, input }) => isInWatchlist(ctx.user.id, input.movieId)),
  }),
});

export type AppRouter = typeof appRouter;

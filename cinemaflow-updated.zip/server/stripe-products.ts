/**
 * CinemaFlow Membership Plans - Stripe Product Configuration
 */

export interface PlanConfig {
  name: string;
  tier: 'basic' | 'standard' | 'premium';
  priceMonthly: number; // in cents
  priceYearly: number; // in cents
  features: string[];
}

export const PLANS: PlanConfig[] = [
  {
    name: 'Basic',
    tier: 'basic',
    priceMonthly: 499, // $4.99
    priceYearly: 4999, // $49.99
    features: [
      'Access to movie database',
      'Basic search and filters',
      'Save up to 20 favorites',
      'Standard quality trailers',
    ],
  },
  {
    name: 'Standard',
    tier: 'standard',
    priceMonthly: 999, // $9.99
    priceYearly: 9999, // $99.99
    features: [
      'Everything in Basic',
      'Unlimited favorites',
      'Advanced filters and recommendations',
      'HD quality trailers',
      'Early access to new listings',
      'Priority support',
    ],
  },
  {
    name: 'Premium',
    tier: 'premium',
    priceMonthly: 1999, // $19.99
    priceYearly: 19999, // $199.99
    features: [
      'Everything in Standard',
      'Exclusive curated collections',
      'Behind-the-scenes content',
      'VIP community access',
      'Personal movie recommendations',
      'Ad-free experience',
      'Premium support',
    ],
  },
];

export function getPlanByTier(tier: string): PlanConfig | undefined {
  return PLANS.find(p => p.tier === tier);
}

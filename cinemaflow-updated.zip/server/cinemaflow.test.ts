import { describe, expect, it, vi, beforeEach } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

// ── Helpers ──────────────────────────────────────────────────────

function createPublicContext(): TrpcContext {
  return {
    user: null,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: vi.fn(),
    } as unknown as TrpcContext["res"],
  };
}

function createAuthContext(): TrpcContext {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user-001",
    email: "test@cinemaflow.com",
    name: "Test User",
    loginMethod: "manus",
    role: "user",
    membershipTier: "free",
    stripeCustomerId: null,
    stripeSubscriptionId: null,
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  return {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: vi.fn(),
    } as unknown as TrpcContext["res"],
  };
}

// ── Movies Router Tests ──────────────────────────────────────────

describe("movies.list", () => {
  it("returns a paginated list of movies with default parameters", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.movies.list();

    expect(result).toBeDefined();
    expect(result).toHaveProperty("movies");
    expect(result).toHaveProperty("total");
    expect(Array.isArray(result.movies)).toBe(true);
    expect(result.movies.length).toBeGreaterThan(0);
    expect(result.movies.length).toBeLessThanOrEqual(24);
  });

  it("supports pagination with limit and offset", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const page1 = await caller.movies.list({ limit: 5, offset: 0 });
    const page2 = await caller.movies.list({ limit: 5, offset: 5 });

    expect(page1.movies.length).toBe(5);
    expect(page2.movies.length).toBe(5);
    // Pages should have different movies
    expect(page1.movies[0].id).not.toBe(page2.movies[0].id);
  });

  it("filters movies by genre", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.movies.list({ genre: "Drama" });

    expect(result.movies.length).toBeGreaterThan(0);
    result.movies.forEach((movie) => {
      expect(movie.genre.toLowerCase()).toContain("drama");
    });
  });

  it("filters movies by region", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.movies.list({ region: "african" });

    expect(result.movies.length).toBeGreaterThan(0);
    result.movies.forEach((movie) => {
      expect(movie.region).toBe("african");
    });
  });

  it("searches movies by title", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.movies.list({ search: "Spirited" });

    expect(result.movies.length).toBeGreaterThan(0);
    const hasMatch = result.movies.some((m) =>
      m.title.toLowerCase().includes("spirited")
    );
    expect(hasMatch).toBe(true);
  });

  it("sorts movies by rating descending", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.movies.list({
      sortBy: "rating",
      sortOrder: "desc",
      limit: 10,
    });

    expect(result.movies.length).toBeGreaterThan(0);
    for (let i = 1; i < result.movies.length; i++) {
      const prev = parseFloat(result.movies[i - 1].rating ?? "0");
      const curr = parseFloat(result.movies[i].rating ?? "0");
      expect(prev).toBeGreaterThanOrEqual(curr);
    }
  });
});

describe("movies.getById", () => {
  it("returns a single movie by ID", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const movie = await caller.movies.getById({ id: 1 });

    expect(movie).toBeDefined();
    expect(movie).toHaveProperty("id", 1);
    expect(movie).toHaveProperty("title");
    expect(movie).toHaveProperty("genre");
    expect(movie).toHaveProperty("country");
    expect(movie).toHaveProperty("region");
    expect(movie).toHaveProperty("releaseYear");
  });

  it("returns null for non-existent movie", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const movie = await caller.movies.getById({ id: 99999 });

    expect(movie).toBeUndefined();
  });
});

describe("movies.featured", () => {
  it("returns featured movies", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const movies = await caller.movies.featured();

    expect(Array.isArray(movies)).toBe(true);
    expect(movies.length).toBeGreaterThan(0);
  });

  it("respects the limit parameter", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const movies = await caller.movies.featured({ limit: 3 });

    expect(movies.length).toBeLessThanOrEqual(3);
  });
});

describe("movies.trending", () => {
  it("returns trending movies", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const movies = await caller.movies.trending();

    expect(Array.isArray(movies)).toBe(true);
    expect(movies.length).toBeGreaterThan(0);
  });
});

describe("movies.byRegion", () => {
  it("returns movies for a specific region", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const movies = await caller.movies.byRegion({ region: "european" });

    expect(Array.isArray(movies)).toBe(true);
    expect(movies.length).toBeGreaterThan(0);
    movies.forEach((movie) => {
      expect(movie.region).toBe("european");
    });
  });
});

describe("movies.byGenre", () => {
  it("returns movies for a specific genre", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const movies = await caller.movies.byGenre({ genre: "Action" });

    expect(Array.isArray(movies)).toBe(true);
    expect(movies.length).toBeGreaterThan(0);
  });
});

describe("movies.genres", () => {
  it("returns a list of distinct genres", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const genres = await caller.movies.genres();

    expect(Array.isArray(genres)).toBe(true);
    expect(genres.length).toBeGreaterThan(0);
    expect(genres).toContain("Drama");
    expect(genres).toContain("Action");
  });
});

describe("movies.countries", () => {
  it("returns a list of distinct countries", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const countries = await caller.movies.countries();

    expect(Array.isArray(countries)).toBe(true);
    expect(countries.length).toBeGreaterThan(0);
    expect(countries).toContain("USA");
    expect(countries).toContain("Nigeria");
  });
});

// ── Membership Router Tests ──────────────────────────────────────

describe("membership.plans", () => {
  it("returns all active membership plans", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const plans = await caller.membership.plans();

    expect(Array.isArray(plans)).toBe(true);
    expect(plans.length).toBe(3);

    const tiers = plans.map((p) => p.tier);
    expect(tiers).toContain("basic");
    expect(tiers).toContain("standard");
    expect(tiers).toContain("premium");
  });

  it("each plan has required fields", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const plans = await caller.membership.plans();

    plans.forEach((plan) => {
      expect(plan).toHaveProperty("id");
      expect(plan).toHaveProperty("name");
      expect(plan).toHaveProperty("tier");
      expect(plan).toHaveProperty("priceMonthly");
      expect(plan).toHaveProperty("features");
    });
  });
});

describe("membership.getPlan", () => {
  it("returns a specific plan by ID", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const plan = await caller.membership.getPlan({ id: 1 });

    expect(plan).toBeDefined();
    expect(plan).toHaveProperty("id", 1);
    expect(plan).toHaveProperty("tier");
  });
});

// ── Auth Router Tests ────────────────────────────────────────────

describe("auth.me", () => {
  it("returns null for unauthenticated users", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.auth.me();

    expect(result).toBeNull();
  });

  it("returns user data for authenticated users", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.auth.me();

    expect(result).toBeDefined();
    expect(result?.name).toBe("Test User");
    expect(result?.email).toBe("test@cinemaflow.com");
    expect(result?.role).toBe("user");
  });
});

// ── Watchlist Router Tests (requires auth) ───────────────────────

describe("watchlist", () => {
  it("rejects unauthenticated access to watchlist.list", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    await expect(caller.watchlist.list()).rejects.toThrow();
  });

  it("rejects unauthenticated access to watchlist.add", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.watchlist.add({ movieId: 1 })
    ).rejects.toThrow();
  });

  it("rejects unauthenticated access to watchlist.remove", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.watchlist.remove({ movieId: 1 })
    ).rejects.toThrow();
  });

  it("rejects unauthenticated access to watchlist.isInWatchlist", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.watchlist.isInWatchlist({ movieId: 1 })
    ).rejects.toThrow();
  });
});

// ── Contact Router Tests ─────────────────────────────────────────

describe("contact.submit", () => {
  it("rejects empty name", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.contact.submit({
        name: "",
        email: "test@example.com",
        message: "This is a test message for CinemaFlow",
      })
    ).rejects.toThrow();
  });

  it("rejects invalid email", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.contact.submit({
        name: "Test User",
        email: "not-an-email",
        message: "This is a test message for CinemaFlow",
      })
    ).rejects.toThrow();
  });

  it("rejects short message", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.contact.submit({
        name: "Test User",
        email: "test@example.com",
        message: "Short",
      })
    ).rejects.toThrow();
  });
});

// ── Membership Checkout (requires auth) ──────────────────────────

describe("membership.createCheckout", () => {
  it("rejects unauthenticated access", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.membership.createCheckout({
        tier: "basic",
        billing: "monthly",
        origin: "https://example.com",
      })
    ).rejects.toThrow();
  });
});

describe("membership.updateTier", () => {
  it("rejects unauthenticated access", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.membership.updateTier({
        tier: "basic",
      })
    ).rejects.toThrow();
  });
});

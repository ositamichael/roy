export const REGION_LABELS: Record<string, string> = {
  african: 'African Cinema',
  european: 'European Cinema',
  asian: 'Asian Cinema',
  north_american: 'North American',
  south_american: 'South American',
  oceanian: 'Oceanian Cinema',
  middle_eastern: 'Middle Eastern',
};

export const GENRE_COLORS: Record<string, string> = {
  Action: 'bg-red-500/20 text-red-400',
  Drama: 'bg-blue-500/20 text-blue-400',
  Comedy: 'bg-yellow-500/20 text-yellow-400',
  Thriller: 'bg-purple-500/20 text-purple-400',
  Horror: 'bg-green-500/20 text-green-400',
  Romance: 'bg-pink-500/20 text-pink-400',
  'Sci-Fi': 'bg-cyan-500/20 text-cyan-400',
  Animation: 'bg-orange-500/20 text-orange-400',
  Documentary: 'bg-teal-500/20 text-teal-400',
  Crime: 'bg-amber-500/20 text-amber-400',
  Fantasy: 'bg-indigo-500/20 text-indigo-400',
  War: 'bg-stone-500/20 text-stone-400',
  Biography: 'bg-emerald-500/20 text-emerald-400',
  Adventure: 'bg-lime-500/20 text-lime-400',
  Mystery: 'bg-violet-500/20 text-violet-400',
  Musical: 'bg-fuchsia-500/20 text-fuchsia-400',
  Western: 'bg-amber-600/20 text-amber-500',
  Sport: 'bg-sky-500/20 text-sky-400',
  Music: 'bg-rose-500/20 text-rose-400',
  History: 'bg-yellow-600/20 text-yellow-500',
  Family: 'bg-green-400/20 text-green-300',
};

export const ALL_REGIONS = [
  { value: 'african', label: 'African' },
  { value: 'european', label: 'European' },
  { value: 'asian', label: 'Asian' },
  { value: 'north_american', label: 'North American' },
  { value: 'south_american', label: 'South American' },
  { value: 'oceanian', label: 'Oceanian' },
  { value: 'middle_eastern', label: 'Middle Eastern' },
];

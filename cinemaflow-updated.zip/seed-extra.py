#!/usr/bin/env python3
"""Generate additional movies to reach 650+ total."""
import random

movies = []
platforms = ["Netflix", "Amazon Prime", "Apple TV+", "Hulu", "YouTube", "Disney+"]
platform_urls = {
    "Netflix": "https://www.netflix.com",
    "Amazon Prime": "https://www.amazon.com/prime-video",
    "Apple TV+": "https://tv.apple.com",
    "Hulu": "https://www.hulu.com",
    "YouTube": "https://www.youtube.com",
    "Disney+": "https://www.disneyplus.com"
}

# More North American movies
na_more = [
    ("The Truman Show", "An insurance salesman discovers his entire life is a TV show.", "Comedy,Drama", "USA", 1998, 8.2),
    ("Eternal Sunshine of the Spotless Mind", "A couple undergoes a procedure to erase each other from their memories.", "Drama,Romance,Sci-Fi", "USA", 2004, 8.3),
    ("The Prestige", "Two rival magicians engage in a battle to create the ultimate illusion.", "Drama,Mystery,Sci-Fi", "USA", 2006, 8.5),
    ("Inglourious Basterds", "A group of Jewish soldiers plan to assassinate Nazi leaders.", "Adventure,Drama,War", "USA", 2009, 8.3),
    ("The Grand Budapest Hotel", "A concierge at a famous European hotel gets caught up in theft and murder.", "Adventure,Comedy,Crime", "USA", 2014, 8.1),
    ("Shutter Island", "A U.S. Marshal investigates a disappearance at a mental institution.", "Mystery,Thriller", "USA", 2010, 8.2),
    ("Memento", "A man with short-term memory loss hunts for his wife's killer.", "Mystery,Thriller", "USA", 2000, 8.4),
    ("American Beauty", "A suburban father has a midlife crisis.", "Drama", "USA", 1999, 8.3),
    ("The Big Lebowski", "A laid-back bowler is mistaken for a millionaire.", "Comedy,Crime", "USA", 1998, 8.1),
    ("Fargo", "A car salesman hires two criminals to kidnap his wife.", "Crime,Drama,Thriller", "USA", 1996, 8.1),
    ("Saving Private Ryan", "Following D-Day, a group of soldiers go behind enemy lines to retrieve a paratrooper.", "Drama,War", "USA", 1998, 8.6),
    ("The Sixth Sense", "A boy who communicates with spirits seeks the help of a child psychologist.", "Drama,Mystery,Thriller", "USA", 1999, 8.1),
    ("Cast Away", "A FedEx executive must transform himself to survive after a crash landing.", "Adventure,Drama,Romance", "USA", 2000, 7.8),
    ("A Beautiful Mind", "The life of mathematical genius John Nash.", "Biography,Drama", "USA", 2001, 8.2),
    ("Catch Me If You Can", "A true story of a young con artist who successfully impersonated various professionals.", "Biography,Crime,Drama", "USA", 2002, 8.1),
    ("Kill Bill: Volume 1", "A former assassin seeks revenge on her ex-colleagues.", "Action,Crime,Thriller", "USA", 2003, 8.2),
    ("Lost in Translation", "A faded movie star and a young woman form an unlikely bond in Tokyo.", "Comedy,Drama,Romance", "USA", 2003, 7.7),
    ("Million Dollar Baby", "A boxing trainer reluctantly agrees to train a determined woman.", "Drama,Sport", "USA", 2004, 8.1),
    ("Crash", "Multiple stories of race and class intersect in Los Angeles.", "Crime,Drama,Thriller", "USA", 2004, 7.7),
    ("The Departed", "An undercover cop and a mole try to identify each other.", "Crime,Drama,Thriller", "USA", 2006, 8.5),
    ("Little Miss Sunshine", "A dysfunctional family takes a road trip to a beauty pageant.", "Comedy,Drama", "USA", 2006, 7.8),
    ("Juno", "A teenager faces an unplanned pregnancy.", "Comedy,Drama", "USA", 2007, 7.4),
    ("Slumdog Millionaire", "A Mumbai teen reflects on his life as he answers questions on a game show.", "Drama,Romance", "USA", 2008, 8.0),
    ("The Hurt Locker", "A bomb disposal team faces danger in Iraq.", "Drama,Thriller,War", "USA", 2008, 7.5),
    ("Up", "An elderly widower and a young boy fly to South America in a house lifted by balloons.", "Animation,Adventure,Comedy", "USA", 2009, 8.3),
    ("Toy Story 3", "Woody and friends face an uncertain future as Andy prepares for college.", "Animation,Adventure,Comedy", "USA", 2010, 8.3),
    ("Black Swan", "A ballet dancer's pursuit of perfection leads to a dark transformation.", "Drama,Thriller", "USA", 2010, 8.0),
    ("The King's Speech", "King George VI works with a speech therapist to overcome his stammer.", "Biography,Drama,History", "UK", 2010, 8.0),
    ("Argo", "A CIA agent poses as a film producer to rescue hostages from Iran.", "Biography,Drama,Thriller", "USA", 2012, 7.7),
    ("Life of Pi", "A young man survives a disaster at sea and is cast adrift with a Bengal tiger.", "Adventure,Drama,Fantasy", "USA", 2012, 7.9),
    ("Her", "A lonely writer develops a relationship with an AI operating system.", "Drama,Romance,Sci-Fi", "USA", 2013, 8.0),
    ("The Shape of Water", "A mute janitor forms a relationship with an amphibious creature.", "Adventure,Drama,Fantasy", "USA", 2017, 7.3),
    ("Dunkirk", "Allied soldiers are surrounded by the German Army during WWII.", "Action,Drama,History", "UK", 2017, 7.8),
    ("Lady Bird", "A California high school student navigates her senior year.", "Comedy,Drama", "USA", 2017, 7.4),
    ("Call Me by Your Name", "A romance blossoms between a student and his father's research assistant.", "Drama,Romance", "USA", 2017, 7.9),
    ("The Shape of Water", "A mute janitor bonds with an amphibious creature.", "Adventure,Drama,Fantasy", "USA", 2017, 7.3),
    ("BlacKkKlansman", "An African American police officer infiltrates the KKK.", "Biography,Comedy,Crime", "USA", 2018, 7.5),
    ("Vice", "The story of Dick Cheney's rise to become the most powerful Vice President.", "Biography,Comedy,Drama", "USA", 2018, 7.2),
    ("Parasite", "A poor family schemes to become employed by a wealthy family.", "Comedy,Drama,Thriller", "South Korea", 2019, 8.5),
    ("Ford v Ferrari", "American car designer Carroll Shelby and driver Ken Miles battle to build a car to beat Ferrari.", "Action,Biography,Drama", "USA", 2019, 8.1),
    ("The Irishman", "A hitman recalls his involvement with the disappearance of Jimmy Hoffa.", "Biography,Crime,Drama", "USA", 2019, 7.8),
    ("Mank", "The story of screenwriter Herman J. Mankiewicz and Citizen Kane.", "Biography,Comedy,Drama", "USA", 2020, 6.8),
    ("Judas and the Black Messiah", "The story of Fred Hampton and the FBI informant who betrayed him.", "Biography,Drama,History", "USA", 2021, 7.5),
    ("Belfast", "A young boy navigates childhood during the Troubles in Belfast.", "Comedy,Drama", "UK", 2021, 7.3),
    ("Licorice Pizza", "A teenager and a young woman navigate first love in 1970s San Fernando Valley.", "Comedy,Drama,Romance", "USA", 2021, 7.4),
    ("The Northman", "A Viking prince sets out to avenge his father's murder.", "Action,Adventure,Drama", "USA", 2022, 7.1),
    ("Babylon", "A tale of outsized ambition in early Hollywood.", "Comedy,Drama,History", "USA", 2022, 7.1),
    ("Prey", "A young Comanche woman fights a Predator alien.", "Action,Drama,Horror", "USA", 2022, 7.1),
    ("Smile", "A therapist witnesses a bizarre traumatic incident involving a patient.", "Horror,Mystery,Thriller", "USA", 2022, 6.5),
    ("M3GAN", "A roboticist creates a lifelike doll that develops a will of its own.", "Horror,Sci-Fi,Thriller", "USA", 2022, 6.4),
    ("John Wick: Chapter 4", "John Wick uncovers a path to defeating the High Table.", "Action,Crime,Thriller", "USA", 2023, 7.7),
    ("Guardians of the Galaxy Vol. 3", "The Guardians embark on a mission to protect one of their own.", "Action,Adventure,Comedy", "USA", 2023, 7.9),
    ("Spider-Man: Across the Spider-Verse", "Miles Morales catapults across the Multiverse.", "Animation,Action,Adventure", "USA", 2023, 8.6),
    ("Mission: Impossible - Dead Reckoning", "Ethan Hunt and his IMF team face their most dangerous mission yet.", "Action,Adventure,Thriller", "USA", 2023, 7.7),
    ("The Hunger Games: The Ballad of Songbirds & Snakes", "The origin story of Coriolanus Snow.", "Action,Drama,Sci-Fi", "USA", 2023, 6.5),
    ("Wonka", "The story of how young Willy Wonka became the world's greatest chocolate maker.", "Adventure,Comedy,Family", "USA", 2023, 7.1),
    ("Napoleon", "An epic about Napoleon Bonaparte's rise and fall.", "Action,Adventure,Biography", "USA", 2023, 6.4),
    ("Ferrari", "The story of Enzo Ferrari during the summer of 1957.", "Biography,Drama,History", "USA", 2023, 6.5),
    ("Priscilla", "The story of Priscilla Presley's relationship with Elvis.", "Biography,Drama", "USA", 2023, 6.7),
    ("Nyad", "The story of marathon swimmer Diana Nyad.", "Biography,Drama,Sport", "USA", 2023, 7.1),
    ("Rustin", "The story of Bayard Rustin, organizer of the 1963 March on Washington.", "Biography,Drama", "USA", 2023, 6.2),
    ("Society of the Snow", "The true story of the 1972 Andes flight disaster.", "Adventure,Drama,History", "USA", 2023, 7.8),
    ("The Color Purple", "A musical retelling of Alice Walker's Pulitzer Prize-winning novel.", "Drama,Musical", "USA", 2023, 6.4),
    ("Wish", "A young girl wishes on a star and gets a more direct answer than she bargained for.", "Animation,Adventure,Comedy", "USA", 2023, 5.6),
    ("Rebel Moon", "A young woman seeks warriors from other planets to help her fight a tyrannical ruler.", "Action,Drama,Fantasy", "USA", 2023, 5.5),
    ("Aquaman and the Lost Kingdom", "Aquaman must forge an unlikely alliance to save Atlantis.", "Action,Adventure,Fantasy", "USA", 2023, 5.7),
    ("The Creator", "A former soldier fights against AI in a future war.", "Action,Drama,Sci-Fi", "USA", 2023, 6.7),
    ("Asteroid City", "A Junior Stargazer convention in a fictional American desert town.", "Comedy,Drama,Romance", "USA", 2023, 6.5),
    ("Air", "The story of how Nike signed Michael Jordan.", "Biography,Drama,Sport", "USA", 2023, 7.4),
    ("Are You There God? It's Me, Margaret", "A coming-of-age story about a girl navigating adolescence.", "Comedy,Drama", "USA", 2023, 7.2),
    ("Elemental", "In a city where fire, water, land, and air residents live together.", "Animation,Adventure,Comedy", "USA", 2023, 7.0),
    ("Indiana Jones and the Dial of Destiny", "Indiana Jones races against time to retrieve a legendary artifact.", "Action,Adventure", "USA", 2023, 6.5),
    ("Teenage Mutant Ninja Turtles: Mutant Mayhem", "The Turtle brothers work to win the hearts of New Yorkers.", "Animation,Action,Adventure", "USA", 2023, 7.3),
    ("Bottoms", "Two unpopular queer girls start a fight club to hook up with cheerleaders.", "Comedy", "USA", 2023, 6.6),
    ("The Equalizer 3", "Robert McCall finds himself at home in Southern Italy.", "Action,Crime,Thriller", "USA", 2023, 6.8),
    ("Haunted Mansion", "A single mom and her son encounter ghosts in a New Orleans mansion.", "Comedy,Drama,Family", "USA", 2023, 5.9),
    ("Blue Beetle", "A teenager gains superpowers from an alien scarab.", "Action,Adventure,Sci-Fi", "USA", 2023, 6.0),
    ("Saw X", "John Kramer travels to Mexico for an experimental cancer treatment.", "Horror,Mystery,Thriller", "USA", 2023, 6.6),
    ("Five Nights at Freddy's", "A security guard must survive the night at Freddy Fazbear's Pizza.", "Horror,Mystery,Thriller", "USA", 2023, 5.4),
    ("Creed III", "Adonis Creed faces a childhood friend turned dangerous adversary.", "Drama,Sport", "USA", 2023, 6.6),
    ("Scream VI", "The survivors of the Ghostface killings leave Woodsboro.", "Horror,Mystery,Thriller", "USA", 2023, 6.4),
    ("Ant-Man and the Wasp: Quantumania", "Scott Lang and Hope Van Dyne explore the Quantum Realm.", "Action,Adventure,Comedy", "USA", 2023, 6.0),
    ("The Marvels", "Carol Danvers, Kamala Khan, and Monica Rambeau team up.", "Action,Adventure,Fantasy", "USA", 2023, 5.5),
    ("Transformers: Rise of the Beasts", "Optimus Prime and the Autobots face a new threat.", "Action,Adventure,Sci-Fi", "USA", 2023, 6.0),
    ("The Flash", "Barry Allen travels back in time to prevent his mother's murder.", "Action,Adventure,Fantasy", "USA", 2023, 6.5),
    ("Expend4bles", "The Expendables are back for a new mission.", "Action,Adventure,Thriller", "USA", 2023, 4.8),
    ("Gran Turismo", "A teenager becomes a real-life race car driver.", "Action,Adventure,Drama", "USA", 2023, 7.2),
    ("Dumb Money", "The story of the GameStop stock short squeeze.", "Biography,Comedy,Drama", "USA", 2023, 6.9),
    ("No Hard Feelings", "A woman is hired to date a shy 19-year-old.", "Comedy,Romance", "USA", 2023, 6.3),
    ("Joy Ride", "Four Asian-American friends go on a wild trip through Asia.", "Adventure,Comedy", "USA", 2023, 6.5),
    ("Talk to Me", "A group of friends discover they can conjure spirits using an embalmed hand.", "Horror,Thriller", "Australia", 2022, 7.1),
    ("Challengers", "A former tennis prodigy turned coach transforms her husband into a champion.", "Drama,Romance,Sport", "USA", 2024, 7.5),
    ("Dune: Part Two", "Paul Atreides unites with the Fremen to take revenge against the conspirators.", "Action,Adventure,Drama", "USA", 2024, 8.5),
    ("Inside Out 2", "Riley enters puberty and encounters new emotions.", "Animation,Adventure,Comedy", "USA", 2024, 7.6),
    ("Furiosa: A Mad Max Saga", "The origin story of the warrior Furiosa.", "Action,Adventure,Sci-Fi", "Australia", 2024, 7.5),
    ("Deadpool & Wolverine", "Deadpool teams up with Wolverine for a multiverse adventure.", "Action,Comedy,Sci-Fi", "USA", 2024, 7.7),
    ("Alien: Romulus", "A group of young space colonists encounter the most terrifying life form.", "Horror,Sci-Fi,Thriller", "USA", 2024, 7.2),
    ("Gladiator II", "The sequel to the epic tale of Maximus.", "Action,Adventure,Drama", "USA", 2024, 7.0),
    ("Wicked", "The untold story of the witches of Oz.", "Drama,Fantasy,Musical", "USA", 2024, 7.8),
    ("Moana 2", "Moana journeys to the far seas of Oceania.", "Animation,Adventure,Comedy", "USA", 2024, 6.8),
    ("Nosferatu", "A gothic tale of obsession between a haunted young woman and a terrifying vampire.", "Drama,Fantasy,Horror", "USA", 2024, 7.5),
    ("A Complete Unknown", "The story of Bob Dylan's rise in the 1960s folk scene.", "Biography,Drama,Music", "USA", 2024, 7.6),
    ("Conclave", "Cardinals gather to elect a new Pope after a sudden death.", "Drama,Mystery,Thriller", "USA", 2024, 7.5),
    ("Anora", "A young sex worker from Brooklyn marries the son of a Russian oligarch.", "Comedy,Drama,Romance", "USA", 2024, 7.8),
    ("The Brutalist", "A Hungarian-born Jewish architect immigrates to America.", "Drama", "USA", 2024, 7.5),
    ("Emilia Pérez", "A lawyer helps a cartel boss fake his death.", "Comedy,Crime,Drama", "Mexico", 2024, 6.5),
    ("The Substance", "A fading celebrity discovers a drug that creates a younger version of herself.", "Drama,Horror,Sci-Fi", "USA", 2024, 7.3),
    ("Sing Sing", "A group of incarcerated men find purpose through a theater program.", "Drama", "USA", 2024, 7.6),
    ("The Wild Robot", "A robot learns to survive in the wilderness.", "Animation,Adventure,Family", "USA", 2024, 8.1),
    ("Twisters", "Storm chasers face unprecedented tornado activity.", "Action,Adventure,Thriller", "USA", 2024, 6.8),
    ("Beetlejuice Beetlejuice", "The ghost with the most returns.", "Comedy,Fantasy,Horror", "USA", 2024, 6.5),
    ("It Ends with Us", "A woman navigates a complicated relationship.", "Drama,Romance", "USA", 2024, 6.4),
    ("Despicable Me 4", "Gru and the Minions face a new villain.", "Animation,Adventure,Comedy", "USA", 2024, 6.2),
    ("Abigail", "A group of criminals kidnap a ballerina who turns out to be a vampire.", "Action,Horror,Thriller", "USA", 2024, 6.5),
    ("Civil War", "A team of journalists travel across a dystopian future America.", "Action,Drama,Sci-Fi", "USA", 2024, 6.8),
    ("Longlegs", "An FBI agent is assigned to an unsolved serial killer case.", "Crime,Horror,Thriller", "USA", 2024, 6.7),
    ("Monkey Man", "An ex-convict seeks vengeance against corrupt leaders.", "Action,Thriller", "USA", 2024, 6.9),
    ("The Fall Guy", "A stuntman gets caught up in a real conspiracy.", "Action,Comedy", "USA", 2024, 7.0),
    ("Kingdom of the Planet of the Apes", "A new chapter in the Apes saga.", "Action,Adventure,Sci-Fi", "USA", 2024, 7.0),
    ("Godzilla x Kong: The New Empire", "Two titans team up against a colossal threat.", "Action,Adventure,Sci-Fi", "USA", 2024, 6.2),
    ("Ghostbusters: Frozen Empire", "The Ghostbusters face an ancient ghost.", "Adventure,Comedy,Fantasy", "USA", 2024, 6.0),
    ("Kung Fu Panda 4", "Po faces a new villain who plans to re-summon all his old enemies.", "Animation,Action,Adventure", "USA", 2024, 6.5),
    ("Bad Boys: Ride or Die", "Mike and Marcus face a new threat.", "Action,Comedy,Crime", "USA", 2024, 6.5),
    ("Trap", "A father and daughter attend a pop concert that turns into a trap.", "Crime,Horror,Thriller", "USA", 2024, 5.8),
    ("Fly Me to the Moon", "A marketing specialist is hired to stage a fake moon landing.", "Comedy,Drama,Romance", "USA", 2024, 6.5),
    ("Horizon: An American Saga", "A multi-faceted chronicle of the American West.", "Drama,Western", "USA", 2024, 5.8),
    ("The Garfield Movie", "Garfield is lured into a heist by his long-lost father.", "Animation,Adventure,Comedy", "USA", 2024, 5.5),
    ("IF", "A girl discovers she can see imaginary friends.", "Animation,Comedy,Drama", "USA", 2024, 6.5),
]

for m in na_more:
    p = random.choice(platforms)
    movies.append({"title": m[0], "description": m[1], "genre": m[2], "country": m[3], "region": "north_american", "releaseYear": m[4], "rating": m[5], "platformName": p, "platformUrl": platform_urls[p], "trailerUrl": "https://www.youtube.com/embed/dQw4w9WgXcQ", "isFeatured": random.random() < 0.12, "isTrending": random.random() < 0.15})

# More Asian movies
asian_more = [
    ("Demon Slayer: Mugen Train", "Tanjiro and his friends join the Flame Hashira on a mission.", "Animation,Action,Adventure", "Japan", 2020, 8.2),
    ("One Cut of the Dead", "A film crew shooting a zombie movie encounters real zombies.", "Comedy,Horror", "Japan", 2017, 7.7),
    ("Weathering with You", "A boy who runs away to Tokyo befriends a girl who can manipulate weather.", "Animation,Drama,Fantasy", "Japan", 2019, 7.5),
    ("Suzume", "A girl must close doors that are releasing disasters across Japan.", "Animation,Adventure,Drama", "Japan", 2022, 7.5),
    ("The Boy and the Heron", "A boy discovers a world shared by the living and the dead.", "Animation,Adventure,Drama", "Japan", 2023, 7.5),
    ("Perfect Blue", "A pop singer turned actress is stalked by an obsessed fan.", "Animation,Drama,Thriller", "Japan", 1997, 8.0),
    ("Akira", "A secret military project endangers Neo-Tokyo.", "Animation,Action,Sci-Fi", "Japan", 1988, 8.0),
    ("Ghost in the Shell", "A cyborg policewoman hunts a mysterious hacker.", "Animation,Action,Sci-Fi", "Japan", 1995, 8.0),
    ("Grave of the Fireflies", "Two siblings struggle to survive in Japan during WWII.", "Animation,Drama,War", "Japan", 1988, 8.5),
    ("Paprika", "A device that allows therapists to enter patients' dreams is stolen.", "Animation,Drama,Fantasy", "Japan", 2006, 7.7),
    ("Millennium Actress", "A documentary filmmaker interviews a reclusive actress.", "Animation,Drama,Fantasy", "Japan", 2001, 7.9),
    ("Tampopo", "A truck driver helps a woman improve her ramen restaurant.", "Comedy", "Japan", 1985, 7.9),
    ("Harakiri", "An elder ronin arrives at a feudal lord's home requesting to commit ritual suicide.", "Action,Drama,Mystery", "Japan", 1962, 8.7),
    ("Yojimbo", "A crafty ronin plays two rival gangs against each other.", "Action,Drama,Thriller", "Japan", 1961, 8.2),
    ("Ikiru", "A bureaucrat discovers he has terminal cancer and seeks meaning.", "Drama", "Japan", 1952, 8.3),
    ("The Handmaiden", "A woman hired to be a handmaiden plots to defraud her mistress.", "Drama,Romance,Thriller", "South Korea", 2016, 8.1),
    ("Mother", "A mother desperately searches for the truth after her son is accused of murder.", "Crime,Drama,Thriller", "South Korea", 2009, 7.8),
    ("Poetry", "An elderly woman discovers poetry while dealing with her grandson's crime.", "Drama", "South Korea", 2010, 7.8),
    ("Spring, Summer, Fall, Winter... and Spring", "A Buddhist monastery on a lake is the setting for a tale of love and loss.", "Drama,Romance", "South Korea", 2003, 8.0),
    ("The Host", "A monster emerges from Seoul's Han River and begins attacking people.", "Comedy,Drama,Horror", "South Korea", 2006, 7.0),
    ("Silenced", "Based on true events of sexual abuse at a school for the hearing-impaired.", "Drama", "South Korea", 2011, 8.1),
    ("A Bittersweet Life", "A crime boss's right-hand man is betrayed.", "Action,Crime,Drama", "South Korea", 2005, 7.5),
    ("Minari", "A Korean-American family moves to an Arkansas farm.", "Drama", "South Korea", 2020, 7.5),
    ("Squid Game: The Movie", "A deadly competition returns with higher stakes.", "Action,Drama,Thriller", "South Korea", 2024, 7.0),
    ("Bajrangi Bhaijaan", "An Indian man helps a mute Pakistani girl return home.", "Comedy,Drama", "India", 2015, 8.0),
    ("Queen", "A shy Delhi girl goes on her honeymoon alone after being jilted.", "Comedy,Drama", "India", 2013, 8.2),
    ("Zindagi Na Milegi Dobara", "Three friends take a bachelor trip to Spain.", "Comedy,Drama,Romance", "India", 2011, 8.1),
    ("Drishyam", "A man goes to extreme lengths to protect his family.", "Crime,Drama,Thriller", "India", 2015, 8.2),
    ("Super Deluxe", "Four interconnected stories of love, sex, and identity.", "Comedy,Crime,Drama", "India", 2019, 8.3),
    ("Jallikattu", "A buffalo escapes from a slaughterhouse, causing chaos in a village.", "Action,Drama", "India", 2019, 7.2),
    ("KGF: Chapter 2", "Rocky's reign continues as he faces new enemies.", "Action,Crime,Drama", "India", 2022, 7.4),
    ("Kantara", "A man from a tribal village clashes with a forest officer.", "Action,Adventure,Drama", "India", 2022, 7.8),
    ("Pathaan", "An Indian spy takes on a deadly mercenary.", "Action,Thriller", "India", 2023, 6.5),
    ("Jawan", "A man is driven by a personal vendetta to rectify wrongs in society.", "Action,Drama,Thriller", "India", 2023, 6.8),
    ("Animal", "A son's love for his father turns into obsession.", "Action,Crime,Drama", "India", 2023, 6.2),
    ("12th Fail", "Based on the true story of an IPS officer who overcame poverty.", "Biography,Drama", "India", 2023, 9.0),
    ("Laapataa Ladies", "Two brides get swapped on a train.", "Comedy,Drama", "India", 2024, 8.4),
    ("Stree 2", "The town of Chanderi faces a new supernatural threat.", "Comedy,Horror", "India", 2024, 7.0),
    ("Kalki 2898 AD", "A sci-fi epic set in a dystopian future India.", "Action,Drama,Sci-Fi", "India", 2024, 6.5),
    ("Crazy Rich Asians", "A woman discovers her boyfriend is from one of Singapore's wealthiest families.", "Comedy,Drama,Romance", "Singapore", 2018, 6.9),
    ("The Grandmaster", "The story of Wing Chun grandmaster Ip Man.", "Action,Biography,Drama", "China", 2013, 6.5),
    ("Farewell My Concubine", "Two performers in the Beijing Opera navigate 50 years of Chinese history.", "Drama,History,Romance", "China", 2003, 8.1),
    ("In the Mood for Love", "Two neighbors form a bond after discovering their spouses' affair.", "Drama,Romance", "Hong Kong", 2000, 8.1),
    ("Chungking Express", "Two stories of love and loneliness in Hong Kong.", "Comedy,Crime,Drama", "Hong Kong", 1994, 8.0),
    ("Happy Together", "A couple from Hong Kong attempts to restart their relationship in Argentina.", "Drama,Romance", "Hong Kong", 1997, 7.7),
    ("The Assassin", "A female assassin receives orders to kill a political leader.", "Action,Drama,Romance", "Taiwan", 2015, 6.3),
    ("Yi Yi", "A middle-class Taipei family deals with life's complexities.", "Drama", "Taiwan", 2000, 8.1),
    ("A Brighter Summer Day", "A teenager's coming of age in 1960s Taiwan.", "Crime,Drama,Romance", "Taiwan", 2001, 8.3),
]

for m in asian_more:
    p = random.choice(platforms)
    movies.append({"title": m[0], "description": m[1], "genre": m[2], "country": m[3], "region": "asian", "releaseYear": m[4], "rating": m[5], "platformName": p, "platformUrl": platform_urls[p], "trailerUrl": "https://www.youtube.com/embed/dQw4w9WgXcQ", "isFeatured": random.random() < 0.12, "isTrending": random.random() < 0.15})

# More South American
sa_more = [
    ("The Motorcycle Diaries", "Young Che Guevara's journey across South America.", "Adventure,Biography,Drama", "Argentina", 2004, 7.8),
    ("Relatos Salvajes", "Six short stories of violence and revenge.", "Comedy,Drama,Thriller", "Argentina", 2014, 8.1),
    ("The Headless Woman", "A woman believes she may have killed someone in a car accident.", "Drama,Mystery", "Argentina", 2008, 6.3),
    ("Zama", "A Spanish officer in 18th century South America waits for a transfer.", "Drama", "Argentina", 2017, 6.5),
    ("The Eternaut", "A toxic snowfall isolates Buenos Aires from the rest of the world.", "Drama,Sci-Fi", "Argentina", 2024, 7.2),
    ("Pixote", "A boy escapes from a reformatory and turns to a life of crime.", "Crime,Drama", "Brazil", 1980, 8.0),
    ("Black Orpheus", "A retelling of the Orpheus legend set during Carnival in Rio.", "Drama,Fantasy,Music", "Brazil", 1959, 7.5),
    ("The Second Mother", "A live-in housekeeper's life is disrupted when her daughter arrives.", "Comedy,Drama", "Brazil", 2015, 7.4),
    ("Carandiru", "A doctor volunteers at Brazil's most notorious prison.", "Crime,Drama", "Brazil", 2003, 7.6),
    ("Machuca", "Two boys from different social classes become friends during Allende's Chile.", "Drama", "Chile", 2004, 7.7),
    ("The Club", "A group of disgraced priests live in a secluded house.", "Drama", "Chile", 2015, 7.2),
    ("Neruda", "A fictionalized account of Chilean poet Pablo Neruda's exile.", "Biography,Drama", "Chile", 2016, 6.5),
    ("Ema", "A dancer copes with the aftermath of an adoption gone wrong.", "Drama,Music", "Chile", 2019, 6.4),
    ("Sin Nombre", "A Honduran girl and a Mexican gang member flee together.", "Adventure,Crime,Drama", "Mexico", 2009, 7.5),
    ("Heli", "A family is caught up in Mexico's drug war.", "Crime,Drama,Thriller", "Mexico", 2013, 6.6),
    ("New Order", "A wedding is disrupted by a violent uprising in Mexico City.", "Drama,Thriller", "Mexico", 2020, 6.5),
    ("Prayers for the Stolen", "Three girls grow up in a Mexican village controlled by cartels.", "Drama", "Mexico", 2021, 7.1),
]

for m in sa_more:
    p = random.choice(platforms)
    movies.append({"title": m[0], "description": m[1], "genre": m[2], "country": m[3], "region": "south_american", "releaseYear": m[4], "rating": m[5], "platformName": p, "platformUrl": platform_urls[p], "trailerUrl": "https://www.youtube.com/embed/dQw4w9WgXcQ", "isFeatured": random.random() < 0.1, "isTrending": random.random() < 0.15})

# More Middle Eastern
me_more = [
    ("The Color of Paradise", "A blind boy's father is ashamed of him.", "Drama,Family", "Iran", 1999, 8.0),
    ("Offside", "Iranian girls disguise themselves as boys to attend a football match.", "Comedy,Drama", "Iran", 2006, 7.2),
    ("Taxi", "A taxi driver films his passengers in Tehran.", "Comedy,Drama", "Iran", 2015, 7.3),
    ("There Is No Evil", "Four stories about the death penalty in Iran.", "Drama", "Iran", 2020, 7.3),
    ("Nanny", "A Senegalese immigrant working as a nanny in New York.", "Drama,Horror", "Senegal", 2022, 5.8),
    ("The Blue Caftan", "A couple running a traditional caftan store in Morocco.", "Drama,Romance", "Morocco", 2022, 7.3),
    ("Casablanca Beats", "A hip-hop teacher inspires students in Casablanca.", "Drama,Music", "Morocco", 2021, 6.8),
    ("Much Loved", "Sex workers navigate life in Marrakech.", "Drama", "Morocco", 2015, 6.8),
    ("The Unknown Saint", "A thief buries his loot in the desert, only to find a shrine built over it.", "Comedy,Drama", "Morocco", 2019, 6.5),
    ("Amira", "A Palestinian girl discovers the truth about her conception.", "Drama", "Palestine", 2021, 6.5),
    ("200 Meters", "A Palestinian man must cross the separation wall to reach his injured son.", "Drama", "Palestine", 2020, 7.0),
    ("The Swimmer", "A man swims from Syria to Europe.", "Drama", "Syria", 2021, 6.8),
    ("Silvered Water, Syria Self-Portrait", "A documentary about the Syrian civil war.", "Documentary,War", "Syria", 2014, 7.2),
    ("The Cave", "A female doctor runs an underground hospital in Syria.", "Documentary,War", "Syria", 2019, 7.5),
    ("Clash", "Protesters and police are trapped together in a police van in Cairo.", "Drama,Thriller", "Egypt", 2016, 6.8),
    ("The Nile Hilton Incident", "A detective investigates a murder in Cairo.", "Crime,Drama,Thriller", "Egypt", 2017, 6.8),
    ("Yomeddine", "A leper and an orphan travel across Egypt.", "Adventure,Drama", "Egypt", 2018, 7.2),
    ("Feathers", "A woman must provide for her family after her husband is turned into a chicken.", "Comedy,Drama", "Egypt", 2021, 6.8),
]

for m in me_more:
    p = random.choice(platforms)
    movies.append({"title": m[0], "description": m[1], "genre": m[2], "country": m[3], "region": "middle_eastern", "releaseYear": m[4], "rating": m[5], "platformName": p, "platformUrl": platform_urls[p], "trailerUrl": "https://www.youtube.com/embed/dQw4w9WgXcQ", "isFeatured": random.random() < 0.1, "isTrending": random.random() < 0.15})

# ============================================================
# Generate SQL
# ============================================================
print(f"-- Extra movies: {len(movies)}")

def escape(s):
    if s is None:
        return "NULL"
    return "'" + str(s).replace("\\", "\\\\").replace("'", "\\'") + "'"

batch_size = 50
for batch_start in range(0, len(movies), batch_size):
    batch = movies[batch_start:batch_start + batch_size]
    values = []
    for m in batch:
        pop = random.randint(10, 100)
        vals = f"({escape(m['title'])}, {escape(m['description'])}, {escape(m.get('posterUrl'))}, {escape(m.get('backdropUrl'))}, {escape(m['trailerUrl'])}, {escape(m['genre'])}, {escape(m['country'])}, {escape(m['region'])}, {m['releaseYear']}, {m['rating']}, {pop}, {escape(m['platformName'])}, {escape(m['platformUrl'])}, {'1' if m['isFeatured'] else '0'}, {'1' if m['isTrending'] else '0'})"
        values.append(vals)
    
    cols = "(`title`, `description`, `posterUrl`, `backdropUrl`, `trailerUrl`, `genre`, `country`, `region`, `releaseYear`, `rating`, `popularity`, `platformName`, `platformUrl`, `isFeatured`, `isTrending`)"
    sql = f"INSERT INTO `movies` {cols} VALUES\n" + ",\n".join(values) + ";"
    print(sql)
    print()

#!/usr/bin/env python3
"""Generate final batch of movies to reach 650+."""
import random

movies = []
platforms = ["Netflix", "Amazon Prime", "Apple TV+", "Hulu", "YouTube", "Disney+"]
platform_urls = {
    "Netflix": "https://www.netflix.com",
    "Amazon Prime": "https://www.amazon.com/prime-video",
    "Apple TV+": "https://tv.apple.com",
    "Hulu": "https://www.hulu.com",
    "YouTube": "https://www.youtube.com",
    "Disney+": "https://www.disneyplus.com"
}

extra = [
    # More African
    ("Mami Wata", "A mythical water spirit disrupts a West African village.", "Drama,Fantasy", "Nigeria", 2023, 6.5, "african"),
    ("Lakewood", "A mother races against time when her son's school goes into lockdown.", "Drama,Thriller", "Nigeria", 2021, 5.5, "african"),
    ("Citation", "A student takes on a powerful professor who sexually harassed her.", "Drama", "Nigeria", 2020, 6.3, "african"),
    ("Oloture", "A journalist goes undercover to expose human trafficking.", "Drama,Thriller", "Nigeria", 2019, 6.7, "african"),
    ("The Ghost and the Tout", "A ghost possesses a street-smart woman.", "Comedy", "Nigeria", 2018, 5.2, "african"),
    ("Mokalik", "A boy spends a day working at a mechanic shop in Lagos.", "Drama", "Nigeria", 2019, 5.8, "african"),
    ("Elesin Oba", "A king's horseman must fulfill his duty to die.", "Drama,History", "Nigeria", 2022, 5.5, "african"),
    ("Jagun Jagun", "A warrior must choose between loyalty and justice.", "Action,Drama", "Nigeria", 2023, 5.8, "african"),
    ("A Tribe Called Judah", "A family of petty thieves faces a moral dilemma.", "Comedy,Crime", "Nigeria", 2023, 6.0, "african"),
    ("Shanty Town", "Women trapped in a crime lord's empire fight for freedom.", "Crime,Drama", "Nigeria", 2023, 5.5, "african"),
    ("Blood Sisters", "Two best friends are entangled in a sinister crime.", "Crime,Drama,Thriller", "Nigeria", 2022, 6.0, "african"),
    ("Collision Course", "A Kenyan detective investigates a series of car accidents.", "Crime,Thriller", "Kenya", 2022, 5.5, "african"),
    ("Softie", "A Kenyan political activist runs for governor.", "Documentary", "Kenya", 2020, 7.0, "african"),
    ("Subira", "A Swahili girl dreams of becoming a swimmer.", "Drama", "Kenya", 2018, 6.5, "african"),
    ("Disconnect", "Interconnected stories about technology and human connection in Nairobi.", "Drama", "Kenya", 2018, 6.0, "african"),
    ("Gaav", "A South African township story of love and loss.", "Drama,Romance", "South Africa", 2022, 6.0, "african"),
    ("Seriously Single", "Two friends navigate the dating scene in Johannesburg.", "Comedy,Romance", "South Africa", 2020, 5.5, "african"),
    ("Riding with Sugar", "A refugee uses BMX biking to overcome his past.", "Drama,Sport", "South Africa", 2020, 6.2, "african"),
    ("Atlantique", "Workers on a futuristic tower have not been paid for months.", "Drama,Romance", "Senegal", 2019, 6.6, "african"),
    ("Lingui, The Sacred Bonds", "A mother fights for her daughter's future in Chad.", "Drama", "Chad", 2021, 7.0, "african"),
    
    # More European
    ("Titane", "A woman with a titanium plate in her skull develops a strange attraction.", "Drama,Horror,Sci-Fi", "France", 2021, 6.5, "european"),
    ("Petite Maman", "A girl meets a mysterious child in the woods near her grandmother's house.", "Drama,Fantasy", "France", 2021, 7.3, "european"),
    ("Happening", "A student in 1960s France faces an unwanted pregnancy.", "Drama", "France", 2021, 7.2, "european"),
    ("Saint Omer", "A novelist attends the trial of a woman accused of killing her daughter.", "Drama", "France", 2022, 6.8, "european"),
    ("The Taste of Things", "A renowned chef and his cook share a passion for food and each other.", "Drama,Romance", "France", 2023, 7.0, "european"),
    ("All Quiet on the Western Front", "A young German soldier faces the terrors of WWI.", "Action,Drama,War", "Germany", 2022, 7.8, "european"),
    ("The Teachers' Lounge", "A teacher's investigation into a series of thefts spirals out of control.", "Drama", "Germany", 2023, 7.5, "european"),
    ("Past Lives", "Two childhood friends reconnect decades later.", "Drama,Romance", "South Korea", 2023, 7.8, "european"),
    ("Fallen Leaves", "Two lonely people find each other in Helsinki.", "Comedy,Drama,Romance", "Finland", 2023, 7.4, "european"),
    ("20 Days in Mariupol", "A documentary about the siege of Mariupol.", "Documentary,War", "Ukraine", 2023, 8.5, "european"),
    ("The Eight Mountains", "Two friends navigate their bond across decades.", "Drama", "Italy", 2022, 7.2, "european"),
    ("Close", "Two 13-year-old boys face the consequences of their close friendship.", "Drama", "Belgium", 2022, 7.6, "european"),
    ("EO", "A donkey's journey through the European countryside.", "Drama", "Poland", 2022, 7.0, "european"),
    ("Corsage", "Empress Elisabeth of Austria rebels against the constraints of her role.", "Biography,Drama,History", "Austria", 2022, 6.5, "european"),
    ("Triangle of Sadness", "A celebrity couple is invited on a luxury cruise.", "Comedy,Drama", "Sweden", 2022, 7.3, "european"),
    ("Holy Spider", "A journalist investigates a serial killer in Iran.", "Crime,Drama,Thriller", "Denmark", 2022, 7.1, "european"),
    ("Godland", "A Danish priest travels to Iceland to build a church.", "Drama", "Iceland", 2022, 7.0, "european"),
    ("Alcarràs", "A family of peach farmers faces the threat of losing their land.", "Drama", "Spain", 2022, 7.0, "european"),
    ("As Bestas", "A French couple living in rural Spain faces hostility from neighbors.", "Drama,Thriller", "Spain", 2022, 7.5, "european"),
    ("The Beasts", "A couple in rural Galicia faces escalating conflict.", "Drama,Thriller", "Spain", 2022, 7.4, "european"),
    
    # More Asian
    ("All of Us Strangers", "A screenwriter reconnects with his dead parents.", "Drama,Fantasy,Romance", "Japan", 2023, 7.7, "asian"),
    ("Monster", "Two mothers investigate what happened between their sons.", "Drama,Mystery", "Japan", 2023, 7.6, "asian"),
    ("Perfect Days", "A toilet cleaner in Tokyo finds beauty in everyday life.", "Drama", "Japan", 2023, 7.9, "asian"),
    ("Evil Does Not Exist", "A village faces the threat of a glamping site.", "Drama", "Japan", 2023, 7.2, "asian"),
    ("Godzilla Minus One", "Post-war Japan faces a new threat from Godzilla.", "Action,Drama,Sci-Fi", "Japan", 2023, 7.8, "asian"),
    ("The Roundup: No Way Out", "Detective Ma Seok-do takes on a new criminal organization.", "Action,Crime", "South Korea", 2023, 6.5, "asian"),
    ("Exhuma", "Feng shui masters investigate a cursed grave.", "Horror,Mystery", "South Korea", 2024, 7.0, "asian"),
    ("Concrete Utopia", "Survivors of an earthquake take over the last standing apartment.", "Drama,Thriller", "South Korea", 2023, 7.0, "asian"),
    ("Noryang: Deadly Sea", "The final naval battle of the Imjin War.", "Action,Drama,History", "South Korea", 2023, 6.8, "asian"),
    ("Dunki", "Friends attempt to illegally immigrate to England.", "Comedy,Drama", "India", 2023, 5.8, "asian"),
    ("Sam Bahadur", "The life of Field Marshal Sam Manekshaw.", "Biography,Drama,War", "India", 2023, 7.2, "asian"),
    ("Salaar", "A man is drawn into the violent world of a lawless city.", "Action,Drama,Thriller", "India", 2023, 6.0, "asian"),
    ("Fighter", "An Indian Air Force pilot faces challenges.", "Action,Drama", "India", 2024, 5.8, "asian"),
    ("Shaitaan", "A family dinner turns into a nightmare.", "Horror,Thriller", "India", 2024, 7.0, "asian"),
    ("Amar Prem Ki Prem Kahani", "A love story that defies conventions.", "Comedy,Drama,Romance", "India", 2024, 6.5, "asian"),
    ("Crew", "Three airline crew members get caught up in a smuggling operation.", "Comedy,Crime", "India", 2024, 6.8, "asian"),
    ("Manjummel Boys", "Friends on a trip face a life-threatening situation.", "Adventure,Drama,Thriller", "India", 2024, 8.5, "asian"),
    ("Aavesham", "A gangster becomes a college student's guardian.", "Action,Comedy", "India", 2024, 7.5, "asian"),
    ("Maharaja", "A barber seeks justice after a home invasion.", "Crime,Drama,Thriller", "India", 2024, 8.0, "asian"),
    ("Kill", "A commando fights to save passengers on a train.", "Action,Thriller", "India", 2024, 7.5, "asian"),
    
    # More South American
    ("Argentina, 1985", "Prosecutors take on the military junta.", "Drama,History", "Argentina", 2022, 7.8, "south_american"),
    ("Bardo", "A Mexican journalist reflects on his identity.", "Comedy,Drama", "Mexico", 2022, 6.5, "south_american"),
    ("Tótem", "A family gathers for a birthday celebration.", "Drama", "Mexico", 2023, 7.5, "south_american"),
    ("La Civil", "A mother searches for her kidnapped daughter.", "Crime,Drama,Thriller", "Mexico", 2021, 6.8, "south_american"),
    ("Sundown", "A wealthy man refuses to leave Acapulco.", "Drama,Mystery", "Mexico", 2021, 6.2, "south_american"),
    ("The Eternal Feminine", "A playwright imagines conversations with historical Mexican women.", "Comedy,Drama", "Mexico", 2023, 6.5, "south_american"),
    ("Mars One", "A Brazilian family faces challenges after a political shift.", "Drama", "Brazil", 2022, 7.0, "south_american"),
    ("Private Desert", "A suspended police officer searches for his online girlfriend.", "Drama,Romance", "Brazil", 2021, 7.2, "south_american"),
    ("Medusa", "A group of evangelical women patrol the streets at night.", "Drama,Horror", "Brazil", 2021, 6.0, "south_american"),
    ("Dry Ground Burning", "Women in a Brazilian settlement steal fuel from a pipeline.", "Drama", "Brazil", 2022, 6.5, "south_american"),
    
    # More Middle Eastern
    ("Farha", "A Palestinian girl witnesses the Nakba from a locked room.", "Drama,History,War", "Palestine", 2021, 7.5, "middle_eastern"),
    ("Costa Brava, Lebanon", "A family retreats to the mountains to escape Beirut's pollution.", "Drama", "Lebanon", 2021, 6.8, "middle_eastern"),
    ("Memory Box", "A woman discovers her mother's journals from the Lebanese Civil War.", "Drama", "Lebanon", 2021, 6.5, "middle_eastern"),
    ("Huda's Salon", "A Palestinian hairdresser is blackmailed into becoming an informant.", "Drama,Thriller", "Palestine", 2021, 6.5, "middle_eastern"),
    ("Inshallah a Boy", "A Jordanian widow fights for her inheritance.", "Drama", "Jordan", 2023, 7.0, "middle_eastern"),
    ("Io Capitano", "Two Senegalese teenagers journey to Europe.", "Adventure,Drama", "Senegal", 2023, 7.5, "middle_eastern"),
    ("The Swimmers", "Two Syrian sisters swim across the sea to reach Europe.", "Biography,Drama,Sport", "Syria", 2022, 6.8, "middle_eastern"),
    ("Shayda", "An Iranian mother seeks refuge in Australia.", "Drama", "Iran", 2023, 7.2, "middle_eastern"),
    ("Terrestrial Verses", "Vignettes of everyday life in Iran.", "Drama", "Iran", 2023, 7.0, "middle_eastern"),
    ("Nezouh", "A family is trapped in their Damascus apartment during the war.", "Drama,War", "Syria", 2022, 6.5, "middle_eastern"),
    
    # More Oceanian
    ("Nitram", "The events leading up to the Port Arthur massacre.", "Crime,Drama", "Australia", 2021, 7.2, "oceanian"),
    ("The Dry", "A federal agent investigates a murder-suicide in a drought-stricken town.", "Crime,Drama,Mystery", "Australia", 2020, 6.3, "oceanian"),
    ("True History of the Kelly Gang", "The story of Australian bushranger Ned Kelly.", "Action,Biography,Crime", "Australia", 2019, 6.0, "oceanian"),
    ("Buoyancy", "A Cambodian boy is enslaved on a Thai fishing trawler.", "Drama,Thriller", "Australia", 2019, 7.0, "oceanian"),
    ("The Nightingale", "A young Irish convict seeks revenge in colonial Tasmania.", "Adventure,Drama,Thriller", "Australia", 2018, 7.3, "oceanian"),
    ("Come to Daddy", "A man visits his estranged father in a remote cabin.", "Comedy,Horror,Thriller", "New Zealand", 2019, 6.2, "oceanian"),
    ("The Royal Hotel", "Two backpackers take a job at a remote Australian pub.", "Drama,Thriller", "Australia", 2023, 6.3, "oceanian"),
    ("Savage", "Three boys grow up in New Zealand's foster care system.", "Crime,Drama", "New Zealand", 2019, 6.8, "oceanian"),
    ("The Breaker Upperers", "Two women run a business breaking up couples.", "Comedy", "New Zealand", 2018, 6.2, "oceanian"),
    ("Cousins", "Three Maori cousins are separated and search for each other.", "Drama", "New Zealand", 2021, 6.5, "oceanian"),
]

for m in extra:
    p = random.choice(platforms)
    movies.append({"title": m[0], "description": m[1], "genre": m[2], "country": m[3], "releaseYear": m[4], "rating": m[5], "region": m[6], "platformName": p, "platformUrl": platform_urls[p], "trailerUrl": "https://www.youtube.com/embed/dQw4w9WgXcQ", "isFeatured": random.random() < 0.1, "isTrending": random.random() < 0.15})

print(f"-- Final extra movies: {len(movies)}")

def escape(s):
    if s is None:
        return "NULL"
    return "'" + str(s).replace("\\", "\\\\").replace("'", "\\'") + "'"

batch_size = 50
for batch_start in range(0, len(movies), batch_size):
    batch = movies[batch_start:batch_start + batch_size]
    values = []
    for m in batch:
        pop = random.randint(10, 100)
        vals = f"({escape(m['title'])}, {escape(m['description'])}, NULL, NULL, {escape(m['trailerUrl'])}, {escape(m['genre'])}, {escape(m['country'])}, {escape(m['region'])}, {m['releaseYear']}, {m['rating']}, {pop}, {escape(m['platformName'])}, {escape(m['platformUrl'])}, {'1' if m['isFeatured'] else '0'}, {'1' if m['isTrending'] else '0'})"
        values.append(vals)
    
    cols = "(`title`, `description`, `posterUrl`, `backdropUrl`, `trailerUrl`, `genre`, `country`, `region`, `releaseYear`, `rating`, `popularity`, `platformName`, `platformUrl`, `isFeatured`, `isTrending`)"
    sql = f"INSERT INTO `movies` {cols} VALUES\n" + ",\n".join(values) + ";"
    print(sql)
    print()
